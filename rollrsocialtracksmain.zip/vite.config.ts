import { defineConfig } from "vite"
import react from "@vitejs/plugin-react-swc"
import path from "path"
import { componentTagger } from "lovable-tagger"

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
  },
  plugins: [react(), mode === "development" && componentTagger()].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  // Добавим конфигурацию для переменных окружения
  define: {
    "import.meta.env.URL": JSON.stringify(process.env.URL),
    "import.meta.env.API_Key_Anon": JSON.stringify(process.env.API_Key_Anon),
    "import.meta.env.API_K": JSON.stringify(process.env.API_K),
    "import.meta.env.service_role": JSON.stringify(process.env.service_role),
    "import.meta.env.JWT_Secret": JSON.stringify(process.env.JWT_Secret),
    "import.meta.env.JWT_S": JSON.stringify(process.env.JWT_S),
  },
}))
