"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { createClient } from "@supabase/supabase-js"
import { useToast } from "@/components/ui/use-toast"

// Создаем клиент Supabase с использованием переменных окружения
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "https://example.supabase.co",
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "your-anon-key",
)

// Создаем контекст для Supabase
const SupabaseContext = createContext<any>(null)

// Хук для использования Supabase в компонентах
export const useSupabase = () => {
  const context = useContext(SupabaseContext)
  if (context === null) {
    throw new Error("useSupabase must be used within a SupabaseProvider")
  }
  return context
}

// Провайдер для Supabase
export function SupabaseProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<any>(null)
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    // Получаем текущую сессию при загрузке
    const getSession = async () => {
      try {
        const { data, error } = await supabase.auth.getSession()
        if (error) {
          console.error("Error getting session:", error)
          return
        }

        setSession(data.session)
        setUser(data.session?.user || null)
      } catch (error) {
        console.error("Unexpected error getting session:", error)
      } finally {
        setLoading(false)
      }
    }

    getSession()

    // Подписываемся на изменения аутентификации
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, newSession) => {
      setSession(newSession)
      setUser(newSession?.user || null)
      setLoading(false)

      if (event === "SIGNED_IN") {
        toast({
          title: "Успешный вход",
          description: "Вы успешно вошли в систему",
        })
      }

      if (event === "SIGNED_OUT") {
        toast({
          title: "Выход из системы",
          description: "Вы вышли из системы",
        })
      }
    })

    // Отписываемся при размонтировании
    return () => {
      authListener.subscription.unsubscribe()
    }
  }, [toast])

  const value = {
    supabase,
    session,
    user,
    loading,
  }

  return <SupabaseContext.Provider value={value}>{children}</SupabaseContext.Provider>
}
