"use client"

import React from "react"
import { StatusBar } from "expo-status-bar"
import { SafeAreaProvider } from "react-native-safe-area-context"
import { NavigationContainer } from "@react-navigation/native"
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs"
import { createNativeStackNavigator } from "@react-navigation/native-stack"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { GestureHandlerRootView } from "react-native-gesture-handler"
import { useFonts } from "expo-font"
import * as SplashScreen from "expo-splash-screen"
import { ThemeProvider } from "./src/contexts/ThemeContext"
import { AuthProvider } from "./src/contexts/AuthContext"
import { UserDataProvider } from "./src/contexts/UserDataContext"
import { ToastProvider } from "./src/contexts/ToastContext"
import { BottomSheetModalProvider } from "@gorhom/bottom-sheet"

// Screens
import AuthScreen from "./src/screens/AuthScreen"
import FeedScreen from "./src/screens/FeedScreen"
import MapScreen from "./src/screens/MapScreen"
import ProfileScreen from "./src/screens/ProfileScreen"
import MessagesScreen from "./src/screens/MessagesScreen"
import ChatDetailScreen from "./src/screens/ChatDetailScreen"
import PostDetailScreen from "./src/screens/PostDetailScreen"
import CreatePostScreen from "./src/screens/CreatePostScreen"
import UserProfileScreen from "./src/screens/UserProfileScreen"
import EditProfileScreen from "./src/screens/EditProfileScreen"
import ActivityDetailScreen from "./src/screens/ActivityDetailScreen"
import SettingsScreen from "./src/screens/SettingsScreen"
import NotFoundScreen from "./src/screens/NotFoundScreen"

// Navigation
import TabBar from "./src/components/navigation/TabBar"
import type { RootStackParamList, MainTabParamList } from "./src/types/navigation"

// Utilities
import { useAuth } from "./src/hooks/useAuth"
import Toast from "./src/components/ui/Toast"

// Keep splash screen visible while loading fonts
SplashScreen.preventAutoHideAsync()

// Create navigation stacks
const Stack = createNativeStackNavigator<RootStackParamList>()
const Tab = createBottomTabNavigator<MainTabParamList>()

// Create query client for React Query
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      refetchOnWindowFocus: false,
    },
  },
})

// Main tab navigator
function MainTabs() {
  return (
    <Tab.Navigator
      tabBar={(props) => <TabBar {...props} />}
      screenOptions={{
        headerShown: false,
      }}
    >
      <Tab.Screen name="Feed" component={FeedScreen} />
      <Tab.Screen name="Map" component={MapScreen} />
      <Tab.Screen name="Create" component={CreatePostScreen} />
      <Tab.Screen name="Messages" component={MessagesScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  )
}

// Root component
export default function App() {
  // Load fonts
  const [fontsLoaded] = useFonts({
    "Inter-Regular": require("./assets/fonts/Inter-Regular.ttf"),
    "Inter-Medium": require("./assets/fonts/Inter-Medium.ttf"),
    "Inter-SemiBold": require("./assets/fonts/Inter-SemiBold.ttf"),
    "Inter-Bold": require("./assets/fonts/Inter-Bold.ttf"),
  })

  // Handle app loading
  const onLayoutRootView = React.useCallback(async () => {
    if (fontsLoaded) {
      await SplashScreen.hideAsync()
    }
  }, [fontsLoaded])

  if (!fontsLoaded) {
    return null
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }} onLayout={onLayoutRootView}>
      <QueryClientProvider client={queryClient}>
        <SafeAreaProvider>
          <ThemeProvider>
            <AuthProvider>
              <UserDataProvider>
                <ToastProvider>
                  <BottomSheetModalProvider>
                    <NavigationContainer>
                      <RootNavigator />
                    </NavigationContainer>
                    <Toast />
                    <StatusBar style="auto" />
                  </BottomSheetModalProvider>
                </ToastProvider>
              </UserDataProvider>
            </AuthProvider>
          </ThemeProvider>
        </SafeAreaProvider>
      </QueryClientProvider>
    </GestureHandlerRootView>
  )
}

// Root navigator with authentication flow
function RootNavigator() {
  const { user, isLoading } = useAuth()

  if (isLoading) {
    return null // Or a loading screen
  }

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {user ? (
        <>
          <Stack.Screen name="Main" component={MainTabs} />
          <Stack.Screen name="PostDetail" component={PostDetailScreen} />
          <Stack.Screen name="ChatDetail" component={ChatDetailScreen} />
          <Stack.Screen name="UserProfile" component={UserProfileScreen} />
          <Stack.Screen name="EditProfile" component={EditProfileScreen} />
          <Stack.Screen name="ActivityDetail" component={ActivityDetailScreen} />
          <Stack.Screen name="Settings" component={SettingsScreen} />
          <Stack.Screen name="NotFound" component={NotFoundScreen} />
        </>
      ) : (
        <Stack.Screen name="Auth" component={AuthScreen} />
      )}
    </Stack.Navigator>
  )
}
