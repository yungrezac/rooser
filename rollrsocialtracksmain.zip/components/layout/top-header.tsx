"use client"

import type React from "react"

import { useRouter } from "next/navigation"
import { ChevronLeft } from "lucide-react"
import { Button } from "@/components/ui/button"

interface TopHeaderProps {
  title: string
  showBackButton?: boolean
  rightElement?: React.ReactNode
}

export function TopHeader({ title, showBackButton = false, rightElement }: TopHeaderProps) {
  const router = useRouter()

  return (
    <div className="sticky top-0 z-40 w-full bg-background/80 backdrop-blur-sm border-b border-border">
      <div className="flex h-14 items-center justify-between px-4">
        <div className="flex items-center">
          {showBackButton && (
            <Button variant="ghost" size="icon" onClick={() => router.back()} className="mr-2">
              <ChevronLeft className="h-5 w-5" />
            </Button>
          )}
          <h1 className="text-lg font-semibold">{title}</h1>
        </div>
        {rightElement}
      </div>
    </div>
  )
}
