"use client"

import { useRouter, usePathname } from "next/navigation"
import { Home, Search, Map, User, MessageSquare } from "lucide-react"
import { cn } from "@/lib/utils"

export function BottomNav() {
  const router = useRouter()
  const pathname = usePathname()

  const navItems = [
    {
      label: "Главная",
      icon: Home,
      href: "/feed",
    },
    {
      label: "Поиск",
      icon: Search,
      href: "/explore",
    },
    {
      label: "Карта",
      icon: Map,
      href: "/map",
    },
    {
      label: "Сообщения",
      icon: MessageSquare,
      href: "/messages",
    },
    {
      label: "Профиль",
      icon: User,
      href: "/profile",
    },
  ]

  return (
    <div className="bottom-nav bg-background border-t border-border">
      <div className="grid grid-cols-5 h-14">
        {navItems.map((item) => {
          const isActive = pathname === item.href

          return (
            <button
              key={item.href}
              className={cn(
                "flex flex-col items-center justify-center",
                "transition-colors",
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground",
              )}
              onClick={() => router.push(item.href)}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-xs mt-1">{item.label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
