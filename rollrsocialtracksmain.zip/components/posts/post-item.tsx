"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { formatDistanceToNow } from "date-fns"
import { ru } from "date-fns/locale"
import { Heart, MessageCircle, Share2, MoreHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface PostItemProps {
  post: {
    id: string
    created_at: string
    content: string
    image_url?: string
    user_id: string
    likes_count: number
    comments_count: number
    user: {
      id: string
      username: string
      avatar_url?: string
      full_name?: string
    }
  }
}

export function PostItem({ post }: PostItemProps) {
  const router = useRouter()
  const [liked, setLiked] = useState(false)
  const [likesCount, setLikesCount] = useState(post.likes_count)

  const handleLike = () => {
    if (liked) {
      setLikesCount(likesCount - 1)
    } else {
      setLikesCount(likesCount + 1)
    }
    setLiked(!liked)
  }

  const handleProfileClick = () => {
    router.push(`/user/${post.user.id}`)
  }

  const handlePostClick = () => {
    router.push(`/post/${post.id}`)
  }

  const formattedDate = formatDistanceToNow(new Date(post.created_at), {
    addSuffix: true,
    locale: ru,
  })

  return (
    <Card className="post-item border-x-0 rounded-none">
      <CardHeader className="p-4 pb-2">
        <div className="flex justify-between">
          <div className="flex items-center space-x-3" onClick={handleProfileClick}>
            <div className="avatar-container">
              <Image
                src={post.user.avatar_url || "/placeholder.svg?height=40&width=40&query=avatar default"}
                alt={post.user.username}
                width={40}
                height={40}
                className="rounded-full"
              />
            </div>
            <div>
              <p className="font-medium">{post.user.full_name || post.user.username}</p>
              <p className="text-xs text-muted-foreground">
                @{post.user.username} · {formattedDate}
              </p>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreHorizontal className="h-4 w-4" />
                <span className="sr-only">Меню</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Сохранить</DropdownMenuItem>
              <DropdownMenuItem>Пожаловаться</DropdownMenuItem>
              <DropdownMenuItem>Скрыть</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-2" onClick={handlePostClick}>
        <p className="mb-3">{post.content}</p>
        {post.image_url && (
          <div className="relative h-64 w-full rounded-md overflow-hidden mb-2">
            <Image src={post.image_url || "/placeholder.svg"} alt="Post image" fill className="object-cover" />
          </div>
        )}
      </CardContent>
      <CardFooter className="p-2 flex justify-between">
        <Button
          variant="ghost"
          size="sm"
          className={`flex items-center space-x-1 ${liked ? "text-red-500" : ""}`}
          onClick={handleLike}
        >
          <Heart className={`h-4 w-4 ${liked ? "fill-current" : ""}`} />
          <span>{likesCount}</span>
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="flex items-center space-x-1"
          onClick={() => router.push(`/post/${post.id}`)}
        >
          <MessageCircle className="h-4 w-4" />
          <span>{post.comments_count}</span>
        </Button>
        <Button variant="ghost" size="sm" className="flex items-center space-x-1">
          <Share2 className="h-4 w-4" />
          <span>Поделиться</span>
        </Button>
      </CardFooter>
    </Card>
  )
}
