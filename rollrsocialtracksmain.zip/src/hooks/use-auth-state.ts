"use client"

import { useState, useEffect } from "react"
import type { User } from "@supabase/supabase-js"
import { supabase } from "@/integrations/supabase/client"

export interface AuthState {
  user: User | null
  isLoading: boolean
  error: Error | null
}

export function useAuthState() {
  const [state, setState] = useState<AuthState>({
    user: null,
    isLoading: true,
    error: null,
  })

  // Effect для инициализации и настройки авторизации
  useEffect(() => {
    let mounted = true

    // Устанавливаем слушатель изменений авторизации
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      console.log("Auth state changed:", event)

      // Обновляем только если компонент смонтирован
      if (mounted) {
        if (session?.user) {
          setState({
            user: session.user,
            isLoading: false,
            error: null,
          })
        } else if (event === "SIGNED_OUT") {
          setState({
            user: null,
            isLoading: false,
            error: null,
          })
        }
      }
    })

    // Получаем текущую сессию
    async function getInitialSession() {
      try {
        setState((state) => ({ ...state, isLoading: true }))

        const { data, error } = await supabase.auth.getSession()

        if (error) throw error

        if (mounted) {
          setState({
            user: data.session?.user || null,
            isLoading: false,
            error: null,
          })
        }
      } catch (error: any) {
        console.error("Error getting initial session:", error)

        if (mounted) {
          setState({
            user: null,
            isLoading: false,
            error,
          })
        }
      }
    }

    // Инициализируем получение сессии
    getInitialSession()

    // Очистка при размонтировании
    return () => {
      mounted = false
      subscription.unsubscribe()
    }
  }, [])

  return state
}
