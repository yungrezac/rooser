"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/integrations/supabase/client"
import type { Activity } from "@/types"
import { useToast } from "@/hooks/use-toast"

export function useActivity(activityId: string | undefined) {
  const [activity, setActivity] = useState<Activity | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    if (!activityId) {
      setIsLoading(false)
      return
    }

    let activityChannel: any

    async function fetchActivity() {
      try {
        setIsLoading(true)
        setError(null)

        const { data, error } = await supabase
          .from("activities")
          .select(`
            *,
            user:user_id(id, username, name, avatar_url, followers, following),
            route:route_id(id, name, distance, points)
          `)
          .eq("id", activityId)
          .single()

        if (error) throw error

        if (!data) {
          setError("Активность не найдена")
          setActivity(null)
          return
        }

        // Transform data to Activity type
        const activityData: Activity = {
          id: data.id,
          user: {
            id: data.user.id,
            name: data.user.name || data.user.username,
            username: data.user.username,
            avatar: data.user.avatar_url || "",
            followers: data.user.followers || 0,
            following: data.user.following || 0,
          },
          type: data.type,
          distance: data.distance,
          duration: data.duration,
          avgSpeed: data.avg_speed,
          elevation: data.elevation || 0,
          timestamp: data.timestamp,
          route: data.route
            ? {
                id: data.route.id,
                name: data.route.name,
                distance: data.route.distance,
                points: data.route.points,
              }
            : undefined,
        }

        setActivity(activityData)

        // Set up realtime subscription
        activityChannel = supabase
          .channel(`activity-${activityId}`)
          .on(
            "postgres_changes",
            { event: "UPDATE", schema: "public", table: "activities", filter: `id=eq.${activityId}` },
            async (payload) => {
              console.log("Activity updated:", payload)

              // Refetch full activity data with relations
              const { data: updatedData } = await supabase
                .from("activities")
                .select(`
                  *,
                  user:user_id(id, username, name, avatar_url, followers, following),
                  route:route_id(id, name, distance, points)
                `)
                .eq("id", activityId)
                .single()

              if (updatedData) {
                // Transform data to Activity type
                const updatedActivityData: Activity = {
                  id: updatedData.id,
                  user: {
                    id: updatedData.user.id,
                    name: updatedData.user.name || updatedData.user.username,
                    username: updatedData.user.username,
                    avatar: updatedData.user.avatar_url || "",
                    followers: updatedData.user.followers || 0,
                    following: updatedData.user.following || 0,
                  },
                  type: updatedData.type,
                  distance: updatedData.distance,
                  duration: updatedData.duration,
                  avgSpeed: updatedData.avg_speed,
                  elevation: updatedData.elevation || 0,
                  timestamp: updatedData.timestamp,
                  route: updatedData.route
                    ? {
                        id: updatedData.route.id,
                        name: updatedData.route.name,
                        distance: updatedData.route.distance,
                        points: updatedData.route.points,
                      }
                    : undefined,
                }

                setActivity(updatedActivityData)
              }
            },
          )
          .subscribe()
      } catch (error: any) {
        console.error("Ошибка при загрузке активности:", error)
        setError(error.message || "Не удалось загрузить активность")
        toast({
          title: "Ошибка загрузки",
          description: error.message || "Не удалось загрузить данные активности",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchActivity()

    // Cleanup function
    return () => {
      if (activityChannel) supabase.removeChannel(activityChannel)
    }
  }, [activityId, toast])

  return { activity, isLoading, error }
}
