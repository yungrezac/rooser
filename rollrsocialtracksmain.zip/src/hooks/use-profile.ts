"use client"

import { useState, useEffect, useCallback } from "react"
import { supabase } from "@/integrations/supabase/client"
import type { User } from "@supabase/supabase-js"

export function useProfile(user: User | null) {
  const [profile, setProfile] = useState<any | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const loadUserProfile = useCallback(async (userId: string) => {
    if (!userId) return

    try {
      setIsLoading(true)
      const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).single()

      if (error) {
        console.error("Ошибка загрузки профиля:", error)
        return
      }

      setProfile(data)
    } catch (error) {
      console.error("Ошибка загрузки профиля:", error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    if (user?.id) {
      loadUserProfile(user.id)

      // Set up Realtime subscription for profile updates
      const channel = supabase
        .channel(`profile-changes-${user.id}`)
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "profiles",
            filter: `id=eq.${user.id}`,
          },
          (payload) => {
            console.log("Profile updated:", payload)
            setProfile(payload.new)
          },
        )
        .subscribe()

      return () => {
        supabase.removeChannel(channel)
      }
    } else {
      setProfile(null)
    }
  }, [user?.id, loadUserProfile])

  return {
    profile,
    isLoading,
    loadUserProfile,
  }
}
