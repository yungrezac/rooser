"use client"

import { useState } from "react"
import { supabase } from "@/integrations/supabase/client"
import { useToast } from "@/hooks/use-toast"

export function useAuthOperations() {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const signUp = async (email: string, password: string, userData: Record<string, any>) => {
    setIsLoading(true)
    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            username: userData.username,
            name: userData.name,
            avatar_url: userData.avatarUrl,
          },
          emailRedirectTo: `${window.location.origin}/auth`,
        },
      })

      if (error) throw error

      toast({
        title: "Аккаунт создан",
        description: "Проверьте электронную почту для подтверждения регистрации",
      })

      return { error: null }
    } catch (error: any) {
      toast({
        title: "Ошибка регистрации",
        description: error.message,
        variant: "destructive",
      })
      return { error }
    } finally {
      setIsLoading(false)
    }
  }

  const signIn = async (email: string, password: string) => {
    setIsLoading(true)
    try {
      const { error, data } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) throw error

      toast({
        title: "Вход выполнен успешно",
        description: `Добро пожаловать${data.user?.user_metadata?.name ? ", " + data.user.user_metadata.name : ""}!`,
      })

      return { error: null, data }
    } catch (error: any) {
      toast({
        title: "Ошибка входа",
        description: error.message,
        variant: "destructive",
      })
      return { error, data: null }
    } finally {
      setIsLoading(false)
    }
  }

  const signOut = async () => {
    setIsLoading(true)
    try {
      await supabase.auth.signOut()

      toast({
        title: "Выход выполнен",
        description: "Вы успешно вышли из системы",
      })
      return { error: null }
    } catch (error: any) {
      toast({
        title: "Ошибка выхода",
        description: error.message,
        variant: "destructive",
      })
      return { error }
    } finally {
      setIsLoading(false)
    }
  }

  const updateProfile = async (userId: string, userData: Record<string, any>) => {
    if (!userId) return { error: new Error("User ID is required") }

    setIsLoading(true)
    try {
      // Обновление метаданных пользователя в auth
      const { error: authError } = await supabase.auth.updateUser({
        data: userData,
      })

      if (authError) throw authError

      // Обновление данных профиля в таблице profiles
      const { error: profileError } = await supabase.from("profiles").update(userData).eq("id", userId)

      if (profileError) throw profileError

      toast({
        title: "Профиль обновлен",
        description: "Данные профиля успешно обновлены",
      })
      return { error: null }
    } catch (error: any) {
      toast({
        title: "Ошибка обновления профиля",
        description: error.message,
        variant: "destructive",
      })
      return { error }
    } finally {
      setIsLoading(false)
    }
  }

  return {
    signUp,
    signIn,
    signOut,
    updateProfile,
    isOperationLoading: isLoading,
  }
}
