"use client"

import { useState, useEffect } from "react"
import type { RealtimeChannel } from "@supabase/supabase-js"
import { supabase } from "@/integrations/supabase/client"

type EventType = "INSERT" | "UPDATE" | "DELETE" | "*"

export function useRealtime<T = any>(
  tableName: string,
  eventTypes: EventType | EventType[] = "*",
  initialData: T[] = [],
) {
  const [data, setData] = useState<T[]>(initialData)
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    // Set up initial data fetch
    const fetchInitialData = async () => {
      try {
        setLoading(true)
        const { data: tableData, error: tableError } = await supabase.from(tableName).select("*")

        if (tableError) throw tableError

        setData(tableData || [])
      } catch (err: any) {
        console.error(`Error fetching initial data from ${tableName}:`, err)
        setError(err)
      } finally {
        setLoading(false)
      }
    }

    fetchInitialData()

    // Set up realtime subscription
    const channelName = `realtime-${tableName}-${Math.random().toString(36).substring(2, 9)}`
    let channel: RealtimeChannel

    // Handle multiple event types
    const events = Array.isArray(eventTypes) ? eventTypes : [eventTypes]

    channel = supabase.channel(channelName)

    // Add listeners for each event type
    events.forEach((eventType) => {
      channel = channel.on(
        "postgres_changes",
        {
          event: eventType,
          schema: "public",
          table: tableName,
        },
        (payload) => {
          console.log(`Realtime ${eventType} on ${tableName}:`, payload)

          if (eventType === "INSERT" || payload.eventType === "INSERT") {
            setData((currentData) => [...currentData, payload.new as T])
          } else if (eventType === "UPDATE" || payload.eventType === "UPDATE") {
            setData((currentData) =>
              currentData.map((item) =>
                // @ts-ignore - we don't know the shape of T
                item.id === payload.new.id ? (payload.new as T) : item,
              ),
            )
          } else if (eventType === "DELETE" || payload.eventType === "DELETE") {
            setData((currentData) =>
              currentData.filter(
                (item) =>
                  // @ts-ignore - we don't know the shape of T
                  item.id !== payload.old.id,
              ),
            )
          }
        },
      )
    })

    // Subscribe to the channel
    channel.subscribe((status) => {
      if (status !== "SUBSCRIBED") {
        console.error(`Failed to subscribe to ${channelName}:`, status)
      } else {
        console.log(`Subscribed to ${channelName}`)
      }
    })

    // Cleanup function
    return () => {
      supabase.removeChannel(channel)
    }
  }, [tableName, eventTypes])

  return { data, loading, error }
}
