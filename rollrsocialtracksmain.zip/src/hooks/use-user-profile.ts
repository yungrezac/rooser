"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/integrations/supabase/client"
import { useAuth } from "@/contexts/AuthContext"
import { useToast } from "./use-toast"

export function useUserProfile(userId?: string) {
  const { user, profile: authProfile } = useAuth()
  const { toast } = useToast()
  const [profile, setProfile] = useState<any>(null)
  const [posts, setPosts] = useState<any[]>([])
  const [activities, setActivities] = useState<any[]>([])
  const [isFollowing, setIsFollowing] = useState<boolean>(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isError, setIsError] = useState(false)

  useEffect(() => {
    const targetId = userId || user?.id

    if (!targetId) return

    // If requesting current user's profile and it already exists in AuthContext
    if (targetId === user?.id && authProfile) {
      setProfile(authProfile)
    }

    // Set up multiple channels for different tables
    let profileChannel: any
    let postsChannel: any
    let activitiesChannel: any
    let followsChannel: any

    const fetchUserProfile = async () => {
      try {
        setIsLoading(true)
        setIsError(false)

        // Get user profile
        const { data, error } = await supabase.from("profiles").select("*").eq("id", targetId).single()

        if (error) throw error
        setProfile(data)

        // Get user posts with images
        const { data: postsData, error: postsError } = await supabase
          .from("posts")
          .select(`
            *,
            user:profiles(id, username, name, avatar_url),
            images:post_images(image_url)
          `)
          .eq("user_id", targetId)
          .order("created_at", { ascending: false })

        if (postsError) throw postsError
        setPosts(postsData || [])

        // Get user activities
        const { data: activitiesData, error: activitiesError } = await supabase
          .from("activities")
          .select(`
            *,
            post:posts(id, content)
          `)
          .eq("user_id", targetId)
          .order("created_at", { ascending: false })

        if (activitiesError) throw activitiesError
        setActivities(activitiesData || [])

        // Check if current user is following the profile
        if (user && targetId !== user.id) {
          const { data: followData, error: followError } = await supabase
            .from("follows")
            .select("*")
            .eq("follower_id", user.id)
            .eq("following_id", targetId)
            .single()

          if (!followError) {
            setIsFollowing(!!followData)
          }
        }

        // Set up realtime subscriptions
        profileChannel = supabase
          .channel(`profile-${targetId}`)
          .on(
            "postgres_changes",
            { event: "*", schema: "public", table: "profiles", filter: `id=eq.${targetId}` },
            (payload) => {
              console.log("Profile updated:", payload)
              if (payload.eventType === "UPDATE") {
                setProfile(payload.new)
              }
            },
          )
          .subscribe()

        postsChannel = supabase
          .channel(`posts-${targetId}`)
          .on(
            "postgres_changes",
            { event: "*", schema: "public", table: "posts", filter: `user_id=eq.${targetId}` },
            async (payload) => {
              console.log("Posts updated:", payload)

              if (payload.eventType === "INSERT") {
                // Fetch the complete post with relationships
                const { data } = await supabase
                  .from("posts")
                  .select(`
                    *,
                    user:profiles(id, username, name, avatar_url),
                    images:post_images(image_url)
                  `)
                  .eq("id", payload.new.id)
                  .single()

                if (data) {
                  setPosts((current) => [data, ...current])
                }
              } else if (payload.eventType === "UPDATE") {
                setPosts((current) =>
                  current.map((post) => (post.id === payload.new.id ? { ...post, ...payload.new } : post)),
                )
              } else if (payload.eventType === "DELETE") {
                setPosts((current) => current.filter((post) => post.id !== payload.old.id))
              }
            },
          )
          .subscribe()

        activitiesChannel = supabase
          .channel(`activities-${targetId}`)
          .on(
            "postgres_changes",
            { event: "*", schema: "public", table: "activities", filter: `user_id=eq.${targetId}` },
            (payload) => {
              console.log("Activities updated:", payload)

              if (payload.eventType === "INSERT") {
                setActivities((current) => [payload.new, ...current])
              } else if (payload.eventType === "UPDATE") {
                setActivities((current) =>
                  current.map((activity) => (activity.id === payload.new.id ? payload.new : activity)),
                )
              } else if (payload.eventType === "DELETE") {
                setActivities((current) => current.filter((activity) => activity.id !== payload.old.id))
              }
            },
          )
          .subscribe()

        if (user && targetId !== user.id) {
          followsChannel = supabase
            .channel(`follows-${user.id}-${targetId}`)
            .on(
              "postgres_changes",
              {
                event: "*",
                schema: "public",
                table: "follows",
                filter: `follower_id=eq.${user.id} AND following_id=eq.${targetId}`,
              },
              (payload) => {
                console.log("Follow status updated:", payload)

                if (payload.eventType === "INSERT") {
                  setIsFollowing(true)
                  setProfile((prev) => ({
                    ...prev,
                    followers: (prev.followers || 0) + 1,
                  }))
                } else if (payload.eventType === "DELETE") {
                  setIsFollowing(false)
                  setProfile((prev) => ({
                    ...prev,
                    followers: Math.max((prev.followers || 1) - 1, 0),
                  }))
                }
              },
            )
            .subscribe()
        }
      } catch (error) {
        console.error("Ошибка при загрузке профиля:", error)
        setIsError(true)
        toast({
          title: "Ошибка загрузки данных",
          description: "Не удалось загрузить профиль пользователя",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchUserProfile()

    // Cleanup function
    return () => {
      if (profileChannel) supabase.removeChannel(profileChannel)
      if (postsChannel) supabase.removeChannel(postsChannel)
      if (activitiesChannel) supabase.removeChannel(activitiesChannel)
      if (followsChannel) supabase.removeChannel(followsChannel)
    }
  }, [userId, user, authProfile, toast])

  // Function to toggle follow/unfollow
  const toggleFollow = async () => {
    if (!user || !profile) return

    try {
      if (isFollowing) {
        // Unfollow
        await supabase.from("follows").delete().match({ follower_id: user.id, following_id: profile.id })
      } else {
        // Follow
        await supabase.from("follows").insert({ follower_id: user.id, following_id: profile.id })
      }

      // The state will be updated via the realtime subscription
      // No need to set isFollowing here
    } catch (error) {
      console.error("Ошибка при изменении подписки:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось изменить подписку",
        variant: "destructive",
      })
    }
  }

  return {
    profile,
    posts,
    activities,
    isFollowing,
    toggleFollow,
    isLoading,
    isError,
    setProfile,
    setPosts,
  }
}
