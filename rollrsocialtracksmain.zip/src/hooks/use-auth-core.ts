"use client"

import { useState, useEffect, useCallback } from "react"
import type { Session, User } from "@supabase/supabase-js"
import { supabase } from "@/integrations/supabase/client"

type AuthState = {
  user: User | null
  session: Session | null
  isLoading: boolean
  error: Error | null
}

export function useAuthCore() {
  const [state, setState] = useState<AuthState>({
    user: null,
    session: null,
    isLoading: true,
    error: null,
  })

  const refreshSession = useCallback(async () => {
    try {
      const { data, error } = await supabase.auth.refreshSession()
      if (error) {
        console.error("Error refreshing session:", error)
        return null
      }

      if (data && data.session) {
        setState((prev) => ({
          ...prev,
          user: data.user,
          session: data.session,
          isLoading: false,
        }))
        return data.session
      }
      return null
    } catch (error) {
      console.error("Error in refreshSession:", error)
      return null
    }
  }, [])

  useEffect(() => {
    let mounted = true

    // First set up the auth state listener
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      console.log("Auth state changed:", event)

      if (mounted) {
        setState((prev) => ({
          ...prev,
          user: session?.user || null,
          session,
          isLoading: false,
        }))
      }
    })

    // Then get the initial session
    const getInitialSession = async () => {
      try {
        setState((prev) => ({ ...prev, isLoading: true }))

        const { data, error } = await supabase.auth.getSession()

        if (error) throw error

        if (mounted) {
          setState({
            user: data.session?.user || null,
            session: data.session,
            isLoading: false,
            error: null,
          })
        }
      } catch (error: any) {
        console.error("Error getting initial session:", error)

        if (mounted) {
          setState({
            user: null,
            session: null,
            isLoading: false,
            error,
          })
        }
      }
    }

    getInitialSession()

    // Set up periodic session refresh to keep the session alive
    const refreshIntervalId = setInterval(
      () => {
        if (state.session) {
          refreshSession().catch(console.error)
        }
      },
      4 * 60 * 1000,
    ) // Refresh every 4 minutes (Supabase token expires in 60 minutes)

    return () => {
      mounted = false
      subscription.unsubscribe()
      clearInterval(refreshIntervalId)
    }
  }, [refreshSession])

  return {
    ...state,
    refreshSession,
  }
}
