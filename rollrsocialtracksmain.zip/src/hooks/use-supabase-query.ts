"use client"

import { useState, useEffect } from "react"
import type { PostgrestFilterBuilder } from "@supabase/postgrest-js"
import { useAuth } from "@/contexts/AuthContext"

type QueryOptions<T> = {
  key: string
  query: () => PostgrestFilterBuilder<any>
  enabled?: boolean
  initialData?: T
  onSuccess?: (data: T) => void
  onError?: (error: Error) => void
  refetchInterval?: number
  refetchOnWindowFocus?: boolean
}

export function useSupabaseQuery<T>({
  key,
  query,
  enabled = true,
  initialData,
  onSuccess,
  onError,
  refetchInterval,
  refetchOnWindowFocus = true,
}: QueryOptions<T>) {
  const [data, setData] = useState<T | undefined>(initialData)
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const [error, setError] = useState<Error | null>(null)
  const { user } = useAuth()

  // Создаем уникальный ключ для запроса, который включает ID пользователя
  const queryKey = user ? `${key}-${user.id}` : key

  const fetchData = async () => {
    if (!enabled) {
      setIsLoading(false)
      return
    }

    try {
      setIsLoading(true)
      const { data: result, error: queryError } = await query()

      if (queryError) throw queryError

      setData(result as T)
      setError(null)
      onSuccess?.(result as T)
    } catch (err) {
      console.error(`Ошибка запроса ${queryKey}:`, err)
      setError(err as Error)
      onError?.(err as Error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchData()

    // Настраиваем интервал обновления, если указан
    let intervalId: NodeJS.Timeout | undefined
    if (refetchInterval && enabled) {
      intervalId = setInterval(fetchData, refetchInterval)
    }

    // Настраиваем обновление при фокусе окна
    const handleFocus = () => {
      if (refetchOnWindowFocus && enabled) {
        fetchData()
      }
    }

    window.addEventListener("focus", handleFocus)

    return () => {
      if (intervalId) clearInterval(intervalId)
      window.removeEventListener("focus", handleFocus)
    }
  }, [queryKey, enabled, refetchInterval, refetchOnWindowFocus])

  return {
    data,
    isLoading,
    error,
    refetch: fetchData,
  }
}
