"use client"

import { useState, useEffect } from "react"
import type { Chat } from "@/types"
import { supabase } from "@/integrations/supabase/client"
import { useToast } from "./use-toast"

export function useChats(userId?: string) {
  const [chats, setChats] = useState<Chat[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    if (!userId) {
      setChats([])
      setIsLoading(false)
      return
    }

    // Channels for realtime updates
    let chatsChannel: any
    let messagesChannel: any
    let participantsChannel: any

    const fetchChats = async () => {
      setIsLoading(true)
      setError(null)

      try {
        // Get all chat participants for this user
        const { data: chatParticipants, error: participantsError } = await supabase
          .from("chat_participants")
          .select("chat_id")
          .eq("user_id", userId)

        if (participantsError) throw participantsError

        if (!chatParticipants || chatParticipants.length === 0) {
          setChats([])
          setIsLoading(false)
          return
        }

        const chatIds = chatParticipants.map((p) => p.chat_id)

        // Get all chats that the user is part of
        const { data: chatData, error: chatsError } = await supabase
          .from("chats")
          .select(`
            id,
            chat_participants!inner(user_id),
            messages(id, content, created_at, read, sender_id)
          `)
          .in("id", chatIds)
          .order("created_at", { foreignTable: "messages", ascending: false })

        if (chatsError) throw chatsError

        if (!chatData) {
          setChats([])
          setIsLoading(false)
          return
        }

        // For each chat, get the other user's profile
        const processedChats = await Promise.all(
          chatData.map(async (chat) => {
            // Find the other participant(s)
            const otherParticipants = chat.chat_participants.filter((p: any) => p.user_id !== userId)

            if (otherParticipants.length === 0) {
              return null // Skip chats with no other participants
            }

            const otherUserId = otherParticipants[0].user_id

            // Get other user's profile
            const { data: userData, error: userError } = await supabase
              .from("profiles")
              .select("*")
              .eq("id", otherUserId)
              .single()

            if (userError) {
              console.error("Error fetching user data:", userError)
              return null
            }

            // Find the last message
            const messages = chat.messages || []
            const lastMessage = messages[0] || {
              content: "Нет сообщений",
              created_at: new Date().toISOString(),
              read: true,
            }

            // Count unread messages
            const unreadCount = messages.filter((m: any) => m.sender_id !== userId && !m.read).length

            // Format date for display
            const messageDate = new Date(lastMessage.created_at)
            const now = new Date()

            const isToday = messageDate.toDateString() === now.toDateString()

            const formattedDate = isToday
              ? messageDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
              : messageDate.toLocaleDateString()

            // Convert the chat to our Chat type
            return {
              id: chat.id,
              user: {
                id: userData.id,
                name: userData.name || "Unknown",
                username: userData.username || "unknown",
                avatar: userData.avatar_url || "/placeholder.svg",
                bio: userData.bio,
                following: userData.following || 0,
                followers: userData.followers || 0,
              },
              lastMessage: lastMessage.content,
              timestamp: lastMessage.created_at,
              unread: unreadCount,
              // Additional fields for compatibility
              userName: userData.name || "Unknown",
              userHandle: userData.username || "unknown",
              avatarUrl: userData.avatar_url || "/placeholder.svg",
              lastMessageTime: messageDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
              lastMessageDate: formattedDate,
              unreadCount: unreadCount,
            }
          }),
        )

        const filteredChats = processedChats.filter(Boolean) as Chat[]
        setChats(filteredChats)

        // Set up realtime subscriptions
        chatsChannel = supabase
          .channel("chats-updates")
          .on("postgres_changes", { event: "INSERT", schema: "public", table: "chats" }, async (payload) => {
            // Check if this chat involves the current user
            const { data } = await supabase
              .from("chat_participants")
              .select("user_id")
              .eq("chat_id", payload.new.id)
              .eq("user_id", userId)
              .single()

            if (data) {
              // Refetch all chats to get the proper structure
              fetchChats()
            }
          })
          .subscribe()

        messagesChannel = supabase
          .channel("messages-updates")
          .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, async (payload) => {
            // Check if the message belongs to one of the user's chats
            if (chatIds.includes(payload.new.chat_id)) {
              // Find the chat this message belongs to
              const chatIndex = filteredChats.findIndex((chat) => chat.id === payload.new.chat_id)

              if (chatIndex >= 0) {
                // Update the chat with the new message
                const updatedChat = { ...filteredChats[chatIndex] }
                updatedChat.lastMessage = payload.new.content
                updatedChat.timestamp = payload.new.created_at

                // Format date for display
                const messageDate = new Date(payload.new.created_at)
                const now = new Date()

                const isToday = messageDate.toDateString() === now.toDateString()

                const formattedDate = isToday
                  ? messageDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
                  : messageDate.toLocaleDateString()

                updatedChat.lastMessageTime = messageDate.toLocaleTimeString([], {
                  hour: "2-digit",
                  minute: "2-digit",
                })
                updatedChat.lastMessageDate = formattedDate

                // Update unread count if message is from the other user
                if (payload.new.sender_id !== userId) {
                  updatedChat.unread = (updatedChat.unread || 0) + 1
                  updatedChat.unreadCount = updatedChat.unread
                }

                // Move this chat to the top of the list
                setChats((current) => [updatedChat, ...current.filter((chat) => chat.id !== payload.new.chat_id)])
              }
            }
          })
          .subscribe()

        participantsChannel = supabase
          .channel("participants-updates")
          .on(
            "postgres_changes",
            { event: "INSERT", schema: "public", table: "chat_participants" },
            async (payload) => {
              // If this is a new participation for the current user
              if (payload.new.user_id === userId) {
                fetchChats()
              }
            },
          )
          .subscribe()
      } catch (err: any) {
        console.error("Error fetching chats:", err)
        setError(err)
        toast({
          title: "Ошибка при загрузке чатов",
          description: err.message,
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchChats()

    // Cleanup function
    return () => {
      if (chatsChannel) supabase.removeChannel(chatsChannel)
      if (messagesChannel) supabase.removeChannel(messagesChannel)
      if (participantsChannel) supabase.removeChannel(participantsChannel)
    }
  }, [userId, toast])

  return {
    chats,
    isLoading,
    error,
  }
}
