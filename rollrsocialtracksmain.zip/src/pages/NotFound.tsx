"use client"

import { useLocation } from "react-router-dom"
import { useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Link } from "react-router-dom"

const NotFound = () => {
  const location = useLocation()

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname)
  }, [location.pathname])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="text-center p-6 bg-white rounded-lg shadow-lg">
        <h1 className="text-5xl font-bold mb-4 bg-gradient-rllr bg-clip-text text-transparent">404</h1>
        <p className="text-xl text-gray-600 mb-6">Упс! Страница не найдена</p>
        <Button asChild>
          <Link to="/" className="rllr-btn rllr-btn-primary">
            Вернуться на главную
          </Link>
        </Button>
      </div>
    </div>
  )
}

export default NotFound
