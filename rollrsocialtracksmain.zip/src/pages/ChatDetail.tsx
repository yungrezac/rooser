"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { ArrowLeft, Send } from "lucide-react"
import { demoChats, demoMessages, currentUser } from "@/data/demoData"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import type { Message } from "@/types"

export default function ChatDetail() {
  const { chatId } = useParams<{ chatId: string }>()
  const navigate = useNavigate()
  const [input, setInput] = useState("")
  const [messages, setMessages] = useState<Message[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Получение данных чата
  const chat = demoChats.find((c) => c.id === chatId)

  // Загрузка сообщений
  useEffect(() => {
    if (chatId && demoMessages[chatId]) {
      setMessages(demoMessages[chatId])
    }
  }, [chatId])

  // Прокрутка к последнему сообщению
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Если чат не найден
  if (!chat) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <p className="text-gray-500">Чат не найден</p>
        <Button variant="link" onClick={() => navigate("/messages")}>
          Вернуться к списку чатов
        </Button>
      </div>
    )
  }

  // Форматирование времени
  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  // Отправка нового сообщения
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const newMessage: Message = {
      id: `m${Date.now()}`,
      senderId: currentUser.id,
      content: input,
      timestamp: new Date().toISOString(),
      read: false,
    }

    setMessages((prev) => [...prev, newMessage])
    setInput("")
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] -mx-4">
      {/* Шапка чата */}
      <div className="flex items-center gap-3 px-4 py-2 border-b bg-white">
        <button onClick={() => navigate("/messages")}>
          <ArrowLeft className="w-5 h-5" />
        </button>
        <img src={chat.user.avatar} alt={chat.user.name} className="w-10 h-10 rounded-full object-cover" />
        <div>
          <h3 className="font-medium">{chat.user.name}</h3>
          <p className="text-xs text-gray-500">@{chat.user.username}</p>
        </div>
      </div>

      {/* Список сообщений */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.map((message) => {
          const isMyMessage = message.senderId === currentUser.id

          return (
            <div key={message.id} className={`flex ${isMyMessage ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                  isMyMessage ? "bg-rllr-purple text-white rounded-br-none" : "bg-gray-100 rounded-bl-none"
                }`}
              >
                <p>{message.content}</p>
                <p className={`text-xs mt-1 text-right ${isMyMessage ? "text-gray-200" : "text-gray-500"}`}>
                  {formatTime(message.timestamp)}
                </p>
              </div>
            </div>
          )
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Форма отправки сообщения */}
      <form onSubmit={handleSendMessage} className="px-4 py-3 bg-white border-t flex items-center gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Написать сообщение..."
          className="flex-1"
        />
        <Button type="submit" disabled={!input.trim()} className="bg-rllr-purple hover:bg-rllr-blue">
          <Send className="w-5 h-5" />
        </Button>
      </form>
    </div>
  )
}
