"use client"
import { useAuth } from "@/contexts/AuthContext"
import { useChats } from "@/hooks/use-chats"
import ChatList from "@/components/chat/ChatList"
import { Skeleton } from "@/components/ui/skeleton"

export default function Messages() {
  const { user } = useAuth()
  const { chats, isLoading } = useChats(user?.id)

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-16 w-full" />
      </div>
    )
  }

  if (chats.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] text-gray-500">
        <p className="mb-2">У вас пока нет сообщений</p>
        <p className="text-sm">Перейдите в профиль пользователя, чтобы начать чат</p>
      </div>
    )
  }

  return <ChatList chats={chats} isLoading={isLoading} />
}
