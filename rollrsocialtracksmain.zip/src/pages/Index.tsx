// Этот файл перенаправляет на Feed
import Feed from "./Feed"

const Index = () => {
  return <Feed />
}

export default Index
