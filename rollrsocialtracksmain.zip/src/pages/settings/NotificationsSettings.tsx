"use client"

import { useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { useIsMobile } from "@/hooks/use-mobile"

export default function NotificationsSettings() {
  const { toast } = useToast()
  const isMobile = useIsMobile()
  const [settings, setSettings] = useState({
    activityNotifications: true,
    messageNotifications: true,
    followerNotifications: true,
    commentNotifications: true,
    likeNotifications: false,
    emailNotifications: false,
  })

  const handleToggle = (key: keyof typeof settings) => {
    setSettings((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const handleSave = () => {
    toast({
      title: "Настройки сохранены",
      description: "Настройки уведомлений успешно сохранены",
    })
  }

  return (
    <div>
      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Уведомления приложения</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Активность друзей</p>
              <p className="text-sm text-gray-500">Уведомления о новой активности</p>
            </div>
            <Switch
              checked={settings.activityNotifications}
              onCheckedChange={() => handleToggle("activityNotifications")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Сообщения</p>
              <p className="text-sm text-gray-500">Уведомления о новых сообщениях</p>
            </div>
            <Switch
              checked={settings.messageNotifications}
              onCheckedChange={() => handleToggle("messageNotifications")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Новые подписчики</p>
              <p className="text-sm text-gray-500">Уведомления о новых подписчиках</p>
            </div>
            <Switch
              checked={settings.followerNotifications}
              onCheckedChange={() => handleToggle("followerNotifications")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Комментарии</p>
              <p className="text-sm text-gray-500">Уведомления о новых комментариях</p>
            </div>
            <Switch
              checked={settings.commentNotifications}
              onCheckedChange={() => handleToggle("commentNotifications")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Лайки</p>
              <p className="text-sm text-gray-500">Уведомления о новых лайках</p>
            </div>
            <Switch checked={settings.likeNotifications} onCheckedChange={() => handleToggle("likeNotifications")} />
          </div>
        </div>
      </div>

      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Уведомления по email</h2>
        <div className="flex items-center justify-between">
          <div>
            <p className="font-medium">Email уведомления</p>
            <p className="text-sm text-gray-500">Получать уведомления на email</p>
          </div>
          <Switch checked={settings.emailNotifications} onCheckedChange={() => handleToggle("emailNotifications")} />
        </div>
      </div>

      <Button onClick={handleSave} size={isMobile ? "mobile" : "default"} className="w-full">
        Сохранить
      </Button>
    </div>
  )
}
