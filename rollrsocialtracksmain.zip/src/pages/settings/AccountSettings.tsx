"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useToast } from "@/hooks/use-toast"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { useAuth } from "@/contexts/AuthContext"
import { supabase } from "@/integrations/supabase/client"
import { uploadAvatar } from "@/integrations/supabase/storage"

export default function AccountSettings() {
  const { toast } = useToast()
  const { user, profile, updateProfile } = useAuth()
  const [isLoading, setIsLoading] = useState(true)
  const [avatarFile, setAvatarFile] = useState<File | null>(null)
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    email: "",
    username: "",
    name: "",
    country: "",
    city: "",
    bio: "",
    experience: "",
    style: "",
    model: "",
    phone: "",
    twoFactorEnabled: false,
    passwordChanged: false,
    newPassword: "",
    confirmPassword: "",
  })

  useEffect(() => {
    if (!user || !profile) return

    // Загружаем данные из профиля пользователя
    setFormData((prev) => ({
      ...prev,
      email: user.email || "",
      username: profile.username || "",
      name: profile.name || "",
      country: profile.country || "",
      city: profile.city || "",
      bio: profile.bio || "",
      experience: profile.experience || "",
      style: profile.style || "",
      model: profile.model || "",
      phone: user.phone || "",
    }))

    setAvatarPreview(profile.avatar_url || null)
    setIsLoading(false)
  }, [user, profile])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleCheckboxChange = (checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      twoFactorEnabled: checked,
    }))

    toast({
      title: checked ? "2FA включена" : "2FA отключена",
      description: checked ? "Двухфакторная аутентификация успешно включена" : "Двухфакторная аутентификация отключена",
    })
  }

  const toggleChangePassword = () => {
    setFormData((prev) => ({
      ...prev,
      passwordChanged: !prev.passwordChanged,
      newPassword: "",
      confirmPassword: "",
    }))
  }

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setAvatarFile(file)

      // Предварительный просмотр загруженного изображения
      const reader = new FileReader()
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSave = async () => {
    if (!user) return

    try {
      setIsLoading(true)

      // Если выбран новый аватар, загружаем его
      let avatarUrl = profile?.avatar_url
      if (avatarFile) {
        const uploadedUrl = await uploadAvatar(avatarFile)
        if (uploadedUrl) {
          avatarUrl = uploadedUrl
        } else {
          toast({
            title: "Ошибка",
            description: "Не удалось загрузить аватар",
            variant: "destructive",
          })
        }
      }

      if (formData.passwordChanged) {
        if (formData.newPassword !== formData.confirmPassword) {
          toast({
            title: "Ошибка",
            description: "Пароли не совпадают",
            variant: "destructive",
          })
          return
        }

        // Обновление пароля
        if (formData.newPassword) {
          const { error } = await supabase.auth.updateUser({
            password: formData.newPassword,
          })

          if (error) throw error
        }
      }

      // Обновление email (в реальном приложении потребуется подтверждение)
      if (formData.email !== user.email) {
        const { error } = await supabase.auth.updateUser({
          email: formData.email,
        })

        if (error) throw error
      }

      // Обновляем профиль пользователя
      await updateProfile({
        username: formData.username,
        name: formData.name,
        country: formData.country,
        city: formData.city,
        bio: formData.bio,
        experience: formData.experience,
        style: formData.style,
        model: formData.model,
        avatar_url: avatarUrl,
      })

      toast({
        title: "Настройки сохранены",
        description: "Настройки аккаунта успешно обновлены",
      })

      // Сбрасываем флаг изменения пароля
      setFormData((prev) => ({
        ...prev,
        passwordChanged: false,
        newPassword: "",
        confirmPassword: "",
      }))

      // Сбрасываем выбранный файл аватара
      setAvatarFile(null)
    } catch (error: any) {
      console.error("Ошибка обновления аккаунта:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось обновить настройки аккаунта",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin h-8 w-8 border-4 border-rllr-purple border-t-transparent rounded-full"></div>
      </div>
    )
  }

  return (
    <div>
      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Фото профиля</h2>
        <div className="flex items-center space-x-4">
          <div className="relative h-24 w-24 rounded-full overflow-hidden bg-gray-100">
            {avatarPreview ? (
              <img src={avatarPreview} alt="Аватар" className="h-full w-full object-cover" />
            ) : (
              <div className="flex items-center justify-center h-full w-full text-gray-400">Нет фото</div>
            )}
          </div>
          <div>
            <Input id="avatar" type="file" accept="image/*" onChange={handleAvatarChange} className="mb-2" />
            <p className="text-xs text-gray-500">Рекомендуемый размер: 250x250 пикселей, JPG или PNG</p>
          </div>
        </div>
      </div>

      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Основная информация</h2>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" name="email" type="email" value={formData.email} onChange={handleInputChange} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="username">Имя пользователя</Label>
            <Input id="username" name="username" value={formData.username} onChange={handleInputChange} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Имя</Label>
            <Input id="name" name="name" value={formData.name} onChange={handleInputChange} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Телефон</Label>
            <Input id="phone" name="phone" type="tel" value={formData.phone} onChange={handleInputChange} />
          </div>
        </div>
      </div>

      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Информация о катании</h2>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="experience">Опыт катания</Label>
            <Input
              id="experience"
              name="experience"
              value={formData.experience}
              onChange={handleInputChange}
              placeholder="Например: 2 года"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="style">Стиль катания</Label>
            <Input
              id="style"
              name="style"
              value={formData.style}
              onChange={handleInputChange}
              placeholder="Например: Фрискейт, Слалом, Агрессив"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="model">Модель роликов</Label>
            <Input
              id="model"
              name="model"
              value={formData.model}
              onChange={handleInputChange}
              placeholder="Например: Flying Eagle F5S"
            />
          </div>
        </div>
      </div>

      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">О себе</h2>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="bio">Биография</Label>
            <Input
              id="bio"
              name="bio"
              value={formData.bio}
              onChange={handleInputChange}
              placeholder="Расскажите о себе..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="country">Страна</Label>
            <Input id="country" name="country" value={formData.country} onChange={handleInputChange} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="city">Город</Label>
            <Input id="city" name="city" value={formData.city} onChange={handleInputChange} />
          </div>
        </div>
      </div>

      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Безопасность</h2>
        <div className="space-y-4">
          <div className="flex items-top space-x-2">
            <Checkbox id="twoFactor" checked={formData.twoFactorEnabled} onCheckedChange={handleCheckboxChange} />
            <div className="space-y-1">
              <Label htmlFor="twoFactor" className="font-medium">
                Двухфакторная аутентификация
              </Label>
              <p className="text-sm text-gray-500">
                Повысьте безопасность аккаунта с помощью дополнительного уровня защиты
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <Button type="button" variant="outline" onClick={toggleChangePassword}>
                {formData.passwordChanged ? "Отменить" : "Изменить пароль"}
              </Button>
            </div>

            {formData.passwordChanged && (
              <div className="space-y-3 pt-2">
                <div className="space-y-2">
                  <Label htmlFor="newPassword">Новый пароль</Label>
                  <Input
                    id="newPassword"
                    name="newPassword"
                    type="password"
                    value={formData.newPassword}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Повторите пароль</Label>
                  <Input
                    id="confirmPassword"
                    name="confirmPassword"
                    type="password"
                    value={formData.confirmPassword}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <Button onClick={handleSave} className="w-full" disabled={isLoading}>
        {isLoading ? "Сохранение..." : "Сохранить"}
      </Button>
    </div>
  )
}
