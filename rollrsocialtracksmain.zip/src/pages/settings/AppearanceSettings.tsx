"use client"

import { useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { Moon, Sun, Smartphone } from "lucide-react"

export default function AppearanceSettings() {
  const { toast } = useToast()
  const [settings, setSettings] = useState({
    theme: "system",
    fontSize: "medium",
    compactMode: false,
    highContrastMode: false,
    animationsEnabled: true,
    mapStyle: "standard",
  })

  const handleThemeChange = (value: string) => {
    setSettings((prev) => ({ ...prev, theme: value }))
  }

  const handleFontSizeChange = (value: string) => {
    setSettings((prev) => ({ ...prev, fontSize: value }))
  }

  const handleToggle = (key: "compactMode" | "highContrastMode" | "animationsEnabled") => {
    setSettings((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const handleMapStyleChange = (value: string) => {
    setSettings((prev) => ({ ...prev, mapStyle: value }))
  }

  const handleSave = () => {
    toast({
      title: "Настройки сохранены",
      description: "Настройки внешнего вида успешно сохранены",
    })
  }

  return (
    <div>
      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Тема</h2>
        <ToggleGroup
          type="single"
          value={settings.theme}
          onValueChange={handleThemeChange}
          className="justify-between w-full"
        >
          <ToggleGroupItem value="light" className="flex-1">
            <Sun className="w-4 h-4 mr-2" />
            Светлая
          </ToggleGroupItem>
          <ToggleGroupItem value="dark" className="flex-1">
            <Moon className="w-4 h-4 mr-2" />
            Тёмная
          </ToggleGroupItem>
          <ToggleGroupItem value="system" className="flex-1">
            <Smartphone className="w-4 h-4 mr-2" />
            Системная
          </ToggleGroupItem>
        </ToggleGroup>
      </div>

      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Размер шрифта</h2>
        <RadioGroup value={settings.fontSize} onValueChange={handleFontSizeChange} className="space-y-2">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="small" id="small" />
            <Label htmlFor="small" className="text-sm">
              Маленький
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="medium" id="medium" />
            <Label htmlFor="medium" className="text-base">
              Средний
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="large" id="large" />
            <Label htmlFor="large" className="text-lg">
              Большой
            </Label>
          </div>
        </RadioGroup>
      </div>

      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Дополнительно</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Компактный режим</p>
              <p className="text-sm text-gray-500">Более плотное отображение контента</p>
            </div>
            <Switch checked={settings.compactMode} onCheckedChange={() => handleToggle("compactMode")} />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Высокая контрастность</p>
              <p className="text-sm text-gray-500">Повышенная контрастность интерфейса</p>
            </div>
            <Switch checked={settings.highContrastMode} onCheckedChange={() => handleToggle("highContrastMode")} />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Анимации</p>
              <p className="text-sm text-gray-500">Включить анимацию интерфейса</p>
            </div>
            <Switch checked={settings.animationsEnabled} onCheckedChange={() => handleToggle("animationsEnabled")} />
          </div>
        </div>
      </div>

      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Стиль карты</h2>
        <RadioGroup value={settings.mapStyle} onValueChange={handleMapStyleChange} className="space-y-2">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="standard" id="standard" />
            <Label htmlFor="standard">Стандартный</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="satellite" id="satellite" />
            <Label htmlFor="satellite">Спутник</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="terrain" id="terrain" />
            <Label htmlFor="terrain">Рельеф</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="dark" id="dark" />
            <Label htmlFor="dark">Тёмный</Label>
          </div>
        </RadioGroup>
      </div>

      <Button onClick={handleSave} className="w-full">
        Сохранить
      </Button>
    </div>
  )
}
