"use client"

import { useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function PrivacySettings() {
  const { toast } = useToast()
  const [settings, setSettings] = useState({
    privateProfile: false,
    locationSharing: "friends",
    activityVisibility: "public",
    allowTagging: true,
    showOnlineStatus: true,
  })

  const handleBooleanToggle = (key: "privateProfile" | "allowTagging" | "showOnlineStatus") => {
    setSettings((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const handleSelectChange = (key: "locationSharing" | "activityVisibility", value: string) => {
    setSettings((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  const handleSave = () => {
    toast({
      title: "Настройки сохранены",
      description: "Настройки приватности успешно сохранены",
    })
  }

  return (
    <div>
      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Приватность профиля</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Приватный профиль</p>
              <p className="text-sm text-gray-500">Только подписчики могут видеть ваш профиль</p>
            </div>
            <Switch checked={settings.privateProfile} onCheckedChange={() => handleBooleanToggle("privateProfile")} />
          </div>

          <div className="space-y-2">
            <p className="font-medium">Доступ к местоположению</p>
            <p className="text-sm text-gray-500">Кто может видеть ваше местоположение</p>
            <Select
              value={settings.locationSharing}
              onValueChange={(value) => handleSelectChange("locationSharing", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Выберите настройку" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="public">Все пользователи</SelectItem>
                <SelectItem value="friends">Только друзья</SelectItem>
                <SelectItem value="none">Никто</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <p className="font-medium">Видимость активности</p>
            <p className="text-sm text-gray-500">Кто может видеть вашу активность</p>
            <Select
              value={settings.activityVisibility}
              onValueChange={(value) => handleSelectChange("activityVisibility", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Выберите настройку" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="public">Все пользователи</SelectItem>
                <SelectItem value="friends">Только друзья</SelectItem>
                <SelectItem value="private">Только я</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Разрешить отметки</p>
              <p className="text-sm text-gray-500">Пользователи могут отмечать вас в постах</p>
            </div>
            <Switch checked={settings.allowTagging} onCheckedChange={() => handleBooleanToggle("allowTagging")} />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Показывать онлайн-статус</p>
              <p className="text-sm text-gray-500">Другие пользователи видят когда вы онлайн</p>
            </div>
            <Switch
              checked={settings.showOnlineStatus}
              onCheckedChange={() => handleBooleanToggle("showOnlineStatus")}
            />
          </div>
        </div>
      </div>

      <div className="rllr-card mb-4">
        <h2 className="font-medium mb-4">Управление данными</h2>
        <div className="space-y-3">
          <Button variant="outline" className="w-full justify-start">
            Экспорт данных
          </Button>
          <Button variant="outline" className="w-full justify-start">
            Удалить историю активности
          </Button>
          <Button variant="destructive" className="w-full justify-start">
            Удалить аккаунт
          </Button>
        </div>
      </div>

      <Button onClick={handleSave} className="w-full">
        Сохранить
      </Button>
    </div>
  )
}
