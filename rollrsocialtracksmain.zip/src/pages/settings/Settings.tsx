"use client"
import { useNavigate } from "react-router-dom"
import { Bell, UserCog, Smartphone, Lock, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import { useIsMobile } from "@/hooks/use-mobile"
import { useAuth } from "@/contexts/AuthContext"

export default function Settings() {
  const navigate = useNavigate()
  const { toast } = useToast()
  const isMobile = useIsMobile()
  const { signOut } = useAuth()

  const handleLogout = async () => {
    try {
      await signOut()
      navigate("/auth")
    } catch (error) {
      console.error("Ошибка при выходе:", error)
      toast({
        title: "Ошибка выхода",
        description: "Произошла ошибка при выходе из системы",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="animate-fade-in">
      <h1 className="text-xl font-bold mb-6">Настройки</h1>

      <div className="space-y-6">
        <div>
          <h2 className="text-sm uppercase text-gray-500 font-medium mb-2">Профиль и предпочтения</h2>
          <div className="space-y-2">
            <Button
              variant="outline"
              size={isMobile ? "mobile" : "default"}
              className="w-full justify-start"
              onClick={() => navigate("/settings/notifications")}
            >
              <Bell className={isMobile ? "w-3.5 h-3.5 mr-1.5" : "mr-2 h-4 w-4"} />
              Уведомления
            </Button>
            <Button
              variant="outline"
              size={isMobile ? "mobile" : "default"}
              className="w-full justify-start"
              onClick={() => navigate("/settings/privacy")}
            >
              <Lock className={isMobile ? "w-3.5 h-3.5 mr-1.5" : "mr-2 h-4 w-4"} />
              Приватность
            </Button>
            <Button
              variant="outline"
              size={isMobile ? "mobile" : "default"}
              className="w-full justify-start"
              onClick={() => navigate("/settings/appearance")}
            >
              <Smartphone className={isMobile ? "w-3.5 h-3.5 mr-1.5" : "mr-2 h-4 w-4"} />
              Внешний вид
            </Button>
            <Button
              variant="outline"
              size={isMobile ? "mobile" : "default"}
              className="w-full justify-start"
              onClick={() => navigate("/settings/account")}
            >
              <UserCog className={isMobile ? "w-3.5 h-3.5 mr-1.5" : "mr-2 h-4 w-4"} />
              Аккаунт
            </Button>
          </div>
        </div>

        <div>
          <h2 className="text-sm uppercase text-gray-500 font-medium mb-2">Дополнительно</h2>
          <div className="space-y-2">
            <Button
              variant="outline"
              size={isMobile ? "mobile" : "default"}
              className="w-full justify-start"
              onClick={() => window.open("https://rllr.app/help", "_blank")}
            >
              Помощь и поддержка
            </Button>
            <Button
              variant="outline"
              size={isMobile ? "mobile" : "default"}
              className="w-full justify-start"
              onClick={() => window.open("https://rllr.app/terms", "_blank")}
            >
              Условия использования
            </Button>
            <Button
              variant="outline"
              size={isMobile ? "mobile" : "default"}
              className="w-full justify-start"
              onClick={() => window.open("https://rllr.app/privacy", "_blank")}
            >
              Политика конфиденциальности
            </Button>
          </div>
        </div>

        <Separator />

        <Button variant="destructive" size={isMobile ? "mobile" : "default"} className="w-full" onClick={handleLogout}>
          <LogOut className={isMobile ? "w-3.5 h-3.5 mr-1.5" : "mr-2 h-4 w-4"} />
          Выйти
        </Button>
      </div>
    </div>
  )
}
