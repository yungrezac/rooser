"use client"

import { useState, useEffect } from "react"
import { useParams, useNavigate } from "react-router-dom"
import ActivityDetailComponent from "@/components/activities/ActivityDetail"
import type { Activity } from "@/types"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Heart, MessageSquare, Share2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/integrations/supabase/client"
import { useAuth } from "@/contexts/AuthContext"

export default function ActivityDetail() {
  const { activityId } = useParams<{ activityId: string }>()
  const navigate = useNavigate()
  const { toast } = useToast()
  const { user } = useAuth()

  const [activity, setActivity] = useState<Activity | null>(null)
  const [similarActivities, setSimilarActivities] = useState<Activity[]>([])
  const [liked, setLiked] = useState(false)
  const [likes, setLikes] = useState(0)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchActivity() {
      if (!activityId) {
        setIsLoading(false)
        return
      }

      try {
        setIsLoading(true)
        setError(null)

        const { data, error } = await supabase
          .from("activities")
          .select(`
            *,
            route:routes(*),
            user:profiles(id, name, username, avatar_url)
          `)
          .eq("id", activityId)
          .single()

        if (error) {
          console.error("Ошибка при загрузке активности:", error)
          setError(error.message)
          return
        }

        if (data) {
          // Преобразуем данные из БД в формат типа Activity
          const formattedActivity: Activity = {
            id: data.id,
            type: data.type,
            distance: data.distance,
            duration: data.duration,
            avgSpeed: data.avg_speed,
            elevation: data.elevation || 0,
            timestamp: data.timestamp,
            created_at: data.created_at,
            user: data.user
              ? {
                  id: data.user.id,
                  name: data.user.name || data.user.username,
                  username: data.user.username,
                  avatar: data.user.avatar_url || "",
                  followers: 0,
                  following: 0,
                }
              : undefined,
            route: data.route
              ? {
                  id: data.route.id,
                  name: data.route.name,
                  distance: data.route.distance,
                  points: data.route.points,
                  isPublic: data.route.is_public,
                  timestamp: data.route.created_at,
                  created_at: data.route.created_at,
                }
              : undefined,
          }

          setActivity(formattedActivity)

          // Загрузка похожих активностей этого же типа
          fetchSimilarActivities(data.type, data.id)
        }
      } catch (err: any) {
        console.error("Ошибка при загрузке активности:", err)
        setError(err.message || "Произошла неизвестная ошибка")
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить активность",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    async function fetchSimilarActivities(type: string, currentId: string) {
      try {
        const { data, error } = await supabase
          .from("activities")
          .select(`
            *,
            user:profiles(id, name, username, avatar_url)
          `)
          .eq("type", type)
          .neq("id", currentId)
          .limit(4)

        if (error) {
          console.error("Ошибка при загрузке похожих активностей:", error)
          return
        }

        if (data) {
          const formattedActivities: Activity[] = data.map((item) => ({
            id: item.id,
            type: item.type,
            distance: item.distance,
            duration: item.duration,
            avgSpeed: item.avg_speed,
            elevation: item.elevation || 0,
            timestamp: item.timestamp || item.created_at,
            created_at: item.created_at,
            user: item.user
              ? {
                  id: item.user.id,
                  name: item.user.name || item.user.username,
                  username: item.user.username,
                  avatar: item.user.avatar_url || "",
                  followers: 0,
                  following: 0,
                }
              : undefined,
          }))

          setSimilarActivities(formattedActivities)
        }
      } catch (err) {
        console.error("Ошибка при загрузке похожих активностей:", err)
      }
    }

    fetchActivity()
  }, [activityId, toast])

  const handleLike = () => {
    if (!user) {
      toast({
        title: "Требуется авторизация",
        description: "Пожалуйста, войдите в систему чтобы поставить лайк",
        variant: "destructive",
      })
      return
    }

    setLiked(!liked)
    setLikes((prev) => (liked ? prev - 1 : prev + 1))

    toast({
      title: liked ? "Лайк удален" : "Лайк добавлен",
      description: liked ? "Вы убрали лайк с активности" : "Вы поставили лайк активности",
    })
  }

  const handleShare = () => {
    toast({
      title: "Поделиться активностью",
      description: "Функция доступна в полной версии приложения",
    })
  }

  const handleComment = () => {
    toast({
      title: "Комментировать",
      description: "Функция доступна в полной версии приложения",
    })
  }

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        <div className="h-8 bg-gray-200 rounded w-1/3"></div>
        <div className="h-40 bg-gray-200 rounded"></div>
        <div className="grid grid-cols-2 gap-3">
          <div className="h-20 bg-gray-200 rounded"></div>
          <div className="h-20 bg-gray-200 rounded"></div>
          <div className="h-20 bg-gray-200 rounded"></div>
          <div className="h-20 bg-gray-200 rounded"></div>
        </div>
      </div>
    )
  }

  if (error || !activity) {
    return (
      <div className="flex flex-col items-center justify-center h-[50vh]">
        <p className="text-gray-500 mb-4">{error || "Активность не найдена"}</p>
        <Button variant="outline" onClick={() => navigate(-1)}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Вернуться назад
        </Button>
      </div>
    )
  }

  return (
    <div className="animate-fade-in pb-6">
      {/* Кнопка назад */}
      <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate(-1)}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        Назад
      </Button>

      {/* Детали активности */}
      <ActivityDetailComponent activity={activity} />

      {/* Действия с активностью */}
      <div className="flex justify-between mt-6 p-4 bg-white rounded-lg shadow-sm">
        <Button variant="ghost" className="flex items-center gap-2" onClick={handleLike}>
          <Heart className={cn("w-5 h-5", liked ? "fill-rllr-orange text-rllr-orange" : "")} />
          <span>{likes}</span>
        </Button>

        <Button variant="ghost" className="flex items-center gap-2" onClick={handleComment}>
          <MessageSquare className="w-5 h-5" />
          <span>Комментарии</span>
        </Button>

        <Button variant="ghost" className="flex items-center gap-2" onClick={handleShare}>
          <Share2 className="w-5 h-5" />
          <span>Поделиться</span>
        </Button>
      </div>

      {/* Другие активности того же типа */}
      {similarActivities.length > 0 && (
        <div className="mt-6">
          <h3 className="font-medium mb-3">Похожие активности</h3>
          <div className="grid grid-cols-2 gap-2">
            {similarActivities.map((a) => (
              <div
                key={a.id}
                className="bg-white p-3 rounded-lg shadow-sm cursor-pointer"
                onClick={() => navigate(`/activity/${a.id}`)}
              >
                <div className="flex items-center justify-between">
                  <p className="font-medium">{a.type === "skating" ? "Катание" : "Ролики"}</p>
                  <p className="text-sm text-rllr-purple">{a.distance} км</p>
                </div>
                <p className="text-xs text-gray-500">
                  {new Date(a.timestamp || a.created_at || "").toLocaleDateString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
