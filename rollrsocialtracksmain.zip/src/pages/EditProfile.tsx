"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { useForm } from "react-hook-form"
import { ChevronLeft, Flag, MapPin, Clock, Star, Box, Camera } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { useAuth } from "@/contexts/AuthContext"
import { supabase } from "@/integrations/supabase/client"

interface ProfileFormValues {
  name: string
  username: string
  bio: string
  country: string
  city: string
  experience: string
  style: string
  model: string
  avatar?: FileList
}

export default function EditProfile() {
  const navigate = useNavigate()
  const { toast } = useToast()
  const { user, updateProfile } = useAuth()
  const [avatar, setAvatar] = useState<File | null>(null)
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const form = useForm<ProfileFormValues>({
    defaultValues: {
      name: "",
      username: "",
      bio: "",
      country: "",
      city: "",
      experience: "",
      style: "",
      model: "",
    },
  })

  // Загрузка профиля пользователя
  useEffect(() => {
    if (!user) return

    const loadProfile = async () => {
      try {
        setIsLoading(true)

        const { data, error } = await supabase.from("profiles").select("*").eq("id", user.id).single()

        if (error) throw error

        if (data) {
          form.reset({
            name: data.name || "",
            username: data.username || "",
            bio: data.bio || "",
            country: data.country || "",
            city: data.city || "",
            experience: data.experience || "",
            style: data.style || "",
            model: data.model || "",
          })

          setAvatarUrl(data.avatar_url)
        }
      } catch (error) {
        console.error("Ошибка при загрузке профиля:", error)
        toast({
          title: "Ошибка загрузки профиля",
          description: "Не удалось загрузить данные профиля",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadProfile()
  }, [user, form, toast])

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setAvatar(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setAvatarUrl(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const uploadAvatar = async () => {
    try {
      if (!avatar || !user) return null

      const fileExt = avatar.name.split(".").pop()
      const fileName = `${user.id}-${Math.random().toString(36).substring(2, 15)}.${fileExt}`
      const filePath = `avatars/${fileName}`

      const { error: uploadError } = await supabase.storage.from("profiles").upload(filePath, avatar)

      if (uploadError) throw uploadError

      const { data } = await supabase.storage.from("profiles").getPublicUrl(filePath)

      return data.publicUrl
    } catch (error) {
      console.error("Ошибка загрузки аватара:", error)
      return null
    }
  }

  const onSubmit = async (data: ProfileFormValues) => {
    if (!user) return

    try {
      setIsLoading(true)

      let avatarUrl = null
      if (avatar) {
        avatarUrl = await uploadAvatar()
      }

      const profileData = {
        ...data,
        ...(avatarUrl && { avatar_url: avatarUrl }),
        updated_at: new Date(),
      }

      // Обновляем профиль пользователя
      const { error } = await supabase.from("profiles").update(profileData).eq("id", user.id)

      if (error) throw error

      // Обновляем метаданные пользователя в auth
      await updateProfile({
        name: data.name,
        username: data.username,
        avatar_url: avatarUrl,
      })

      toast({
        title: "Профиль обновлен",
        description: "Изменения успешно сохранены",
      })

      navigate("/profile")
    } catch (error: any) {
      console.error("Ошибка при обновлении профиля:", error)
      toast({
        title: "Ошибка обновления профиля",
        description: error.message || "Не удалось обновить профиль",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin h-8 w-8 border-4 border-rllr-purple border-t-transparent rounded-full"></div>
      </div>
    )
  }

  return (
    <div className="animate-fade-in pb-6">
      <div className="flex items-center mb-6">
        <Button variant="ghost" size="sm" onClick={() => navigate("/profile")} className="mr-2">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-xl font-bold">Редактировать профиль</h1>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Avatar Upload */}
          <div className="flex flex-col items-center">
            <div className="relative mb-4">
              <img
                src={avatarUrl || "/placeholder.svg"}
                alt="Avatar Preview"
                className="w-24 h-24 rounded-full object-cover"
              />
              <label
                htmlFor="avatar-upload"
                className="absolute bottom-0 right-0 bg-primary text-white p-1.5 rounded-full cursor-pointer"
              >
                <Camera className="w-4 h-4" />
                <span className="sr-only">Upload photo</span>
              </label>
              <input id="avatar-upload" type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
            </div>
            <p className="text-sm text-gray-500">Нажмите на значок для изменения фото</p>
          </div>

          {/* Basic Info */}
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Имя</FormLabel>
                  <FormControl>
                    <Input placeholder="Ваше полное имя" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Имя пользователя</FormLabel>
                  <FormControl>
                    <Input placeholder="Ваш никнейм" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="bio"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>О себе</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Расскажите о себе" className="min-h-[100px]" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Additional Info */}
          <div className="space-y-4">
            <h3 className="font-medium text-lg">Дополнительная информация</h3>

            <FormField
              control={form.control}
              name="country"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <Flag className="w-4 h-4" /> Страна
                  </FormLabel>
                  <FormControl>
                    <Input placeholder="Ваша страна" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" /> Город
                  </FormLabel>
                  <FormControl>
                    <Input placeholder="Ваш город" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="experience"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <Clock className="w-4 h-4" /> Стаж катания
                  </FormLabel>
                  <FormControl>
                    <Input placeholder="Сколько вы катаетесь" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="style"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <Star className="w-4 h-4" /> Стиль катания
                  </FormLabel>
                  <FormControl>
                    <Input placeholder="Фрискейт, фристайл, слалом и т.д." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="model"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <Box className="w-4 h-4" /> Модель роликов
                  </FormLabel>
                  <FormControl>
                    <Input placeholder="На чем катаетесь" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => navigate("/profile")}>
              Отмена
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Сохранение..." : "Сохранить"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  )
}
