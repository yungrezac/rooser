"use client"

import { useState, useEffect } from "react"
import { Link, useNavigate } from "react-router-dom"
import { ActivitySquare, Calendar, Edit, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import FollowSuggestions from "@/components/profile/FollowSuggestions"
import AchievementsList from "@/components/profile/AchievementsList"
import type { User, Achievement, Activity, Post } from "@/types"
import { useToast } from "@/hooks/use-toast"
import { getUserAchievements, updateUserAchievements } from "@/services/achievementService"
import SettingsPopup from "@/components/profile/SettingsPopup"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/contexts/AuthContext"
import { supabase } from "@/integrations/supabase/client"

export default function Profile() {
  const [suggestedUsers, setSuggestedUsers] = useState<User[]>([])
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("posts")
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const navigate = useNavigate()
  const { user } = useAuth()
  const [userProfile, setUserProfile] = useState<any>(null)
  const [posts, setPosts] = useState<Post[]>([])
  const [activities, setActivities] = useState<Activity[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [stats, setStats] = useState({
    totalActivities: 0,
    totalDistance: 0,
    totalDuration: 0,
    totalElevation: 0,
  })

  // Загрузка профиля пользователя и связанных данных
  useEffect(() => {
    if (!user) return

    const fetchUserData = async () => {
      try {
        setIsLoading(true)

        // Загружаем профиль пользователя
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", user.id)
          .single()

        if (profileError) throw profileError
        setUserProfile(profileData)

        // Загружаем посты пользователя
        const { data: postsData, error: postsError } = await supabase
          .from("posts")
          .select(`
            *,
            user:profiles(id, username, name, avatar_url),
            images:post_images(image_url)
          `)
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })

        if (postsError) throw postsError

        const formattedPosts = postsData.map((post: any) => ({
          id: post.id,
          content: post.content,
          timestamp: post.created_at,
          likes: post.likes || 0,
          comments: post.comments || 0,
          user: {
            id: post.user.id,
            name: post.user.name || post.user.username,
            username: post.user.username,
            avatar: post.user.avatar_url,
            followers: 0,
            following: 0,
          },
          images: post.images?.map((img: any) => img.image_url) || [],
          liked: false,
        }))

        setPosts(formattedPosts)

        // Загружаем активности пользователя
        const { data: activitiesData, error: activitiesError } = await supabase
          .from("activities")
          .select(`
            *,
            route:routes(*)
          `)
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })

        if (activitiesError) throw activitiesError

        const formattedActivities = activitiesData.map((activity: any) => ({
          id: activity.id,
          type: activity.type,
          distance: activity.distance,
          duration: activity.duration,
          avgSpeed: activity.avg_speed,
          elevation: activity.elevation || 0,
          timestamp: activity.timestamp || activity.created_at,
          route: activity.route
            ? {
                id: activity.route.id,
                name: activity.route.name,
                distance: activity.route.distance,
                points: activity.route.points,
                isPublic: activity.route.is_public,
              }
            : undefined,
          user: {
            id: user.id,
            name: profileData.name || profileData.username,
            username: profileData.username,
            avatar: profileData.avatar_url,
            followers: profileData.followers || 0,
            following: profileData.following || 0,
          },
        }))

        setActivities(formattedActivities)

        // Рассчитываем статистику
        const totalActivities = formattedActivities.length
        const totalDistance = formattedActivities.reduce((sum, act) => sum + act.distance, 0)
        const totalDuration = formattedActivities.reduce((sum, act) => sum + act.duration, 0)
        const totalElevation = formattedActivities.reduce((sum, act) => sum + (act.elevation || 0), 0)

        setStats({
          totalActivities,
          totalDistance,
          totalDuration,
          totalElevation,
        })

        // Загружаем достижения пользователя
        const userAchievements = await getUserAchievements(user.id)
        setAchievements(userAchievements)

        // Обновляем достижения пользователя на основе текущей статистики
        await updateUserAchievements(user.id)

        // Загружаем рекомендуемых пользователей
        await fetchSuggestedUsers()
      } catch (error: any) {
        console.error("Ошибка при загрузке данных профиля:", error)
        toast({
          title: "Ошибка загрузки данных",
          description: error.message || "Не удалось загрузить данные профиля",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchUserData()
  }, [user, toast])

  // Загрузка рекомендуемых пользователей
  const fetchSuggestedUsers = async () => {
    if (!user) return

    try {
      // Получаем пользователей, на которых мы не подписаны
      const { data, error } = await supabase.from("profiles").select("*").neq("id", user.id).limit(5)

      if (error) throw error

      if (data) {
        // Проверяем, на кого из них мы уже подписаны
        const { data: followingData, error: followingError } = await supabase
          .from("follows")
          .select("following_id")
          .eq("follower_id", user.id)

        if (followingError) throw followingError

        const followingIds = new Set(followingData?.map((f) => f.following_id) || [])

        const formattedUsers: User[] = data.map((profile) => ({
          id: profile.id,
          name: profile.name || profile.username,
          username: profile.username,
          avatar: profile.avatar_url,
          followers: profile.followers || 0,
          following: profile.following || 0,
          isFollowing: followingIds.has(profile.id),
        }))

        setSuggestedUsers(formattedUsers)
      }
    } catch (error) {
      console.error("Ошибка при загрузке рекомендуемых пользователей:", error)
    }
  }

  // Функция подписки/отписки от пользователя
  const handleFollow = async (userId: string) => {
    if (!user) return

    try {
      const targetUser = suggestedUsers.find((u) => u.id === userId)
      if (!targetUser) return

      if (targetUser.isFollowing) {
        // Отписываемся
        await supabase.from("follows").delete().match({ follower_id: user.id, following_id: userId })
      } else {
        // Подписываемся
        await supabase.from("follows").insert({ follower_id: user.id, following_id: userId })
      }

      // Обновляем UI оптимистично
      setSuggestedUsers((prevUsers) =>
        prevUsers.map((u) =>
          u.id === userId
            ? {
                ...u,
                isFollowing: !u.isFollowing,
                followers: u.isFollowing ? u.followers - 1 : u.followers + 1,
              }
            : u,
        ),
      )

      toast({
        title: targetUser.isFollowing ? "Отписка" : "Подписка",
        description: targetUser.isFollowing
          ? `Вы отписались от ${targetUser.username}`
          : `Вы подписались на ${targetUser.username}`,
      })
    } catch (error: any) {
      console.error("Ошибка при изменении подписки:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось изменить подписку",
        variant: "destructive",
      })
    }
  }

  if (!user || !userProfile) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin h-8 w-8 border-4 border-rllr-purple border-t-transparent rounded-full"></div>
      </div>
    )
  }

  return (
    <div className="animate-fade-in pb-6 space-y-6">
      {/* Верхняя секция профиля */}
      <Card className="ios-card overflow-hidden">
        <div className="relative h-24 bg-gradient-rllr">
          <div className="absolute -bottom-16 left-4">
            <Avatar className="w-24 h-24 rounded-full border-4 border-white shadow-md">
              <AvatarImage src={userProfile.avatar_url || "/placeholder.svg"} alt={userProfile.name} />
              <AvatarFallback>
                {userProfile.name?.substring(0, 2).toUpperCase() || userProfile.username?.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
          </div>

          <div className="absolute top-3 right-3 flex gap-2">
            <SettingsPopup />
            <Button
              variant="subtle"
              size="sm"
              className="gap-1 bg-white/30 backdrop-blur-md text-white border-white/30"
              onClick={() => navigate("/profile/edit")}
            >
              <Edit className="w-4 h-4" />
              <span className="hidden sm:inline">Редактировать</span>
            </Button>
          </div>
        </div>

        <CardContent className="pt-20 pb-4 px-4">
          <div className="mb-3">
            <h1 className="text-xl font-bold">{userProfile.name || userProfile.username}</h1>
            <p className="text-gray-600 text-sm">@{userProfile.username}</p>
          </div>

          {userProfile.bio && <p className="text-gray-700 text-sm mb-4">{userProfile.bio}</p>}

          <div className="flex gap-4 bg-gray-50 p-3 rounded-xl text-center">
            <div className="flex-1">
              <p className="font-bold text-lg">{posts.length}</p>
              <p className="text-xs text-gray-500">публикаций</p>
            </div>
            <div className="flex-1 border-x border-gray-200">
              <p className="font-bold text-lg">{userProfile.followers || 0}</p>
              <p className="text-xs text-gray-500">подписчиков</p>
            </div>
            <div className="flex-1">
              <p className="font-bold text-lg">{userProfile.following || 0}</p>
              <p className="text-xs text-gray-500">подписок</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Табы с контентом */}
      <div className="bg-white rounded-2xl ios-shadow">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="px-4 pt-4">
            <TabsList className="w-full grid grid-cols-4 mb-4 bg-gray-100 p-1 rounded-xl gap-1">
              <TabsTrigger
                value="posts"
                className="data-[state=active]:bg-white data-[state=active]:text-rllr-purple data-[state=active]:shadow-sm rounded-lg"
              >
                Посты
              </TabsTrigger>
              <TabsTrigger
                value="activities"
                className="data-[state=active]:bg-white data-[state=active]:text-rllr-purple data-[state=active]:shadow-sm rounded-lg"
              >
                Активность
              </TabsTrigger>
              <TabsTrigger
                value="stats"
                className="data-[state=active]:bg-white data-[state=active]:text-rllr-purple data-[state=active]:shadow-sm rounded-lg"
              >
                Статистика
              </TabsTrigger>
              <TabsTrigger
                value="friends"
                className="data-[state=active]:bg-white data-[state=active]:text-rllr-purple data-[state=active]:shadow-sm rounded-lg"
              >
                Друзья
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Содержимое таба Посты */}
          <TabsContent value="posts" className="animate-fade-in p-4">
            {posts.length > 0 ? (
              <div className="grid grid-cols-2 gap-2">
                {posts.map((post) => (
                  <Link key={post.id} to={`/post/${post.id}`} className="block hover-scale">
                    <div className="aspect-square rounded-xl overflow-hidden bg-gray-100 hover:opacity-90 transition-opacity shadow-sm">
                      {post.images && post.images.length > 0 ? (
                        <img
                          src={post.images[0] || "/placeholder.svg"}
                          alt="Post"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center p-4 text-center">
                          <p className="text-sm text-gray-500">{post.content?.substring(0, 40)}...</p>
                        </div>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8">
                <p className="text-gray-500 mb-4">У вас пока нет публикаций</p>
                <Button onClick={() => navigate("/create")} variant="default">
                  Создать пост
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Содержимое таба Активности */}
          <TabsContent value="activities" className="animate-fade-in p-4">
            <div className="space-y-3">
              {activities.length > 0 ? (
                activities.map((activity) => (
                  <div
                    key={activity.id}
                    className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm hover-scale"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="p-2 rounded-full bg-blue-100">
                          <ActivitySquare className="w-5 h-5 text-rllr-blue" />
                        </div>
                        <div>
                          <h3 className="font-medium">{activity.type === "skating" ? "Катание" : "Ролики"}</h3>
                          <p className="text-xs text-gray-500 flex items-center">
                            <Calendar className="w-3 h-3 mr-1" />
                            {new Date(activity.timestamp).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <Badge variant="default" className="bg-gradient-rllr">
                        {activity.distance} км
                      </Badge>
                    </div>

                    {activity.route && (
                      <div>
                        <p className="text-sm font-medium mb-1 flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {activity.route.name}
                        </p>
                        <div className="bg-gray-100 h-24 rounded-lg flex items-center justify-center">
                          <p className="text-xs text-gray-500">Карта маршрута</p>
                        </div>
                      </div>
                    )}
                  </div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <p className="text-gray-500">У вас пока нет активностей</p>
                  <Button onClick={() => navigate("/map")} variant="default" className="mt-4">
                    Начать активность
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Содержимое таба Статистика */}
          <TabsContent value="stats" className="animate-fade-in p-4">
            <div className="space-y-4">
              <Card className="ios-card">
                <CardContent className="p-4">
                  <h3 className="font-medium mb-3">Общая статистика</h3>

                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="p-3 bg-gray-50/80 rounded-xl ios-shadow">
                      <p className="text-xs text-gray-500">Всего поездок</p>
                      <p className="font-bold text-lg text-rllr-purple">{stats.totalActivities}</p>
                    </div>
                    <div className="p-3 bg-gray-50/80 rounded-xl ios-shadow">
                      <p className="text-xs text-gray-500">Общее расстояние</p>
                      <p className="font-bold text-lg text-rllr-purple">{stats.totalDistance.toFixed(1)} км</p>
                    </div>
                    <div className="p-3 bg-gray-50/80 rounded-xl ios-shadow">
                      <p className="text-xs text-gray-500">Общее время</p>
                      <p className="font-bold text-lg text-rllr-purple">
                        {Math.floor(stats.totalDuration / 60)} ч {Math.round(stats.totalDuration % 60)} м
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-2 text-center">
                    <div className="p-3 bg-gray-50/80 rounded-xl ios-shadow">
                      <p className="text-xs text-gray-500">Средняя скорость</p>
                      <p className="font-bold text-lg text-rllr-purple">
                        {stats.totalDuration > 0 ? (stats.totalDistance / (stats.totalDuration / 60)).toFixed(1) : "0"}{" "}
                        км/ч
                      </p>
                    </div>
                    <div className="p-3 bg-gray-50/80 rounded-xl ios-shadow">
                      <p className="text-xs text-gray-500">Всего подъем</p>
                      <p className="font-bold text-lg text-rllr-purple">{stats.totalElevation} м</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="ios-card">
                <CardContent className="p-4">
                  <h3 className="font-medium mb-3">Граф активности</h3>
                  <div className="bg-gray-50 h-40 rounded-lg flex items-center justify-center">
                    <p className="text-gray-400">График активности будет здесь</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="ios-card">
                <CardContent className="p-4">
                  <AchievementsList achievements={achievements} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Таб  />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Таб Друзья */}
          <TabsContent value="friends" className="animate-fade-in p-4">
            <div className="space-y-4">
              <FollowSuggestions users={suggestedUsers} onFollow={handleFollow} />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
