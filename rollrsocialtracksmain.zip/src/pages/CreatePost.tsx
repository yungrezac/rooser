"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useNavigate } from "react-router-dom"
import { Camera, X, MapPin, Activity, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/AuthContext"
import { supabase } from "@/integrations/supabase/client"
import { v4 as uuidv4 } from "uuid"

export default function CreatePost() {
  const [content, setContent] = useState("")
  const [images, setImages] = useState<File[]>([])
  const [imageUrls, setImageUrls] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [location, setLocation] = useState<string | null>(null)
  const [activity, setActivity] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  const navigate = useNavigate()
  const { user } = useAuth()

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files)

      // Ограничиваем количество изображений до 5
      if (images.length + newFiles.length > 5) {
        toast({
          title: "Слишком много изображений",
          description: "Вы можете загрузить максимум 5 изображений",
          variant: "destructive",
        })
        return
      }

      setImages([...images, ...newFiles])

      // Создаем URL для предварительного просмотра
      const newImageUrls = newFiles.map((file) => URL.createObjectURL(file))
      setImageUrls([...imageUrls, ...newImageUrls])
    }
  }

  const removeImage = (index: number) => {
    // Освобождаем URL для предотвращения утечек памяти
    URL.revokeObjectURL(imageUrls[index])

    setImages(images.filter((_, i) => i !== index))
    setImageUrls(imageUrls.filter((_, i) => i !== index))
  }

  const handleSubmit = async () => {
    if (!user) {
      toast({
        title: "Требуется авторизация",
        description: "Пожалуйста, войдите в систему, чтобы создать пост",
        variant: "destructive",
      })
      return
    }

    if (!content.trim() && images.length === 0) {
      toast({
        title: "Пустой пост",
        description: "Добавьте текст или изображение для создания поста",
        variant: "destructive",
      })
      return
    }

    try {
      setIsLoading(true)

      // Создаем новый пост
      const { data: postData, error: postError } = await supabase
        .from("posts")
        .insert({
          user_id: user.id,
          content: content.trim(),
          created_at: new Date().toISOString(),
        })
        .select()
        .single()

      if (postError) throw postError

      // Если есть изображения, загружаем их
      if (images.length > 0) {
        const imagePromises = images.map(async (image, index) => {
          const fileExt = image.name.split(".").pop()
          const fileName = `${uuidv4()}.${fileExt}`
          const filePath = `posts/${postData.id}/${fileName}`

          // Загружаем изображение в хранилище
          const { error: uploadError } = await supabase.storage.from("images").upload(filePath, image)

          if (uploadError) throw uploadError

          // Получаем публичный URL изображения
          const { data: urlData } = supabase.storage.from("images").getPublicUrl(filePath)

          // Сохраняем ссылку на изображение в базе данных
          const { error: imageError } = await supabase.from("post_images").insert({
            post_id: postData.id,
            image_url: urlData.publicUrl,
          })

          if (imageError) throw imageError

          return urlData.publicUrl
        })

        await Promise.all(imagePromises)
      }

      // Если указана активность, связываем пост с ней
      if (activity) {
        // Здесь можно добавить логику связывания поста с активностью
      }

      toast({
        title: "Пост создан",
        description: "Ваш пост успешно опубликован",
      })

      // Перенаправляем на страницу ленты
      navigate("/")
    } catch (error: any) {
      console.error("Ошибка при создании поста:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать пост",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddLocation = () => {
    // В реальном приложении здесь будет выбор местоположения
    setLocation("Парк Горького")
    toast({
      title: "Местоположение добавлено",
      description: "Парк Горького добавлен к вашему посту",
    })
  }

  const handleAddActivity = () => {
    // В реальном приложении здесь будет выбор активности
    setActivity("Вечернее катание")
    toast({
      title: "Активность добавлена",
      description: "Вечернее катание добавлено к вашему посту",
    })
  }

  return (
    <div className="animate-fade-in pb-6">
      <h1 className="text-xl font-bold mb-4">Создать пост</h1>

      <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
        <Textarea
          placeholder="Что у вас нового?"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="min-h-[120px] mb-4 resize-none border-none focus-visible:ring-0 p-0 shadow-none text-base"
        />

        {/* Предварительный просмотр изображений */}
        {imageUrls.length > 0 && (
          <div className="grid grid-cols-2 gap-2 mb-4">
            {imageUrls.map((url, index) => (
              <div key={index} className="relative aspect-square rounded-lg overflow-hidden">
                <img src={url || "/placeholder.svg"} alt={`Preview ${index}`} className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => removeImage(index)}
                  className="absolute top-2 right-2 bg-black/50 text-white p-1 rounded-full"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Дополнительная информация */}
        {(location || activity) && (
          <div className="mb-4 space-y-2">
            {location && (
              <div className="flex items-center text-sm text-gray-600">
                <MapPin className="w-4 h-4 mr-1 text-rllr-purple" />
                <span>{location}</span>
              </div>
            )}
            {activity && (
              <div className="flex items-center text-sm text-gray-600">
                <Activity className="w-4 h-4 mr-1 text-rllr-purple" />
                <span>{activity}</span>
              </div>
            )}
          </div>
        )}

        {/* Кнопки действий */}
        <div className="flex justify-between items-center">
          <div className="flex space-x-2">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              className="text-rllr-purple"
            >
              <Camera className="w-5 h-5" />
            </Button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageChange}
              accept="image/*"
              multiple
              className="hidden"
            />
            <Button type="button" variant="ghost" size="sm" onClick={handleAddLocation} className="text-rllr-purple">
              <MapPin className="w-5 h-5" />
            </Button>
            <Button type="button" variant="ghost" size="sm" onClick={handleAddActivity} className="text-rllr-purple">
              <Activity className="w-5 h-5" />
            </Button>
          </div>
          <Button
            type="button"
            onClick={handleSubmit}
            disabled={isLoading || (!content.trim() && images.length === 0)}
            className="bg-rllr-purple hover:bg-rllr-purple/90"
          >
            {isLoading ? "Публикация..." : "Опубликовать"}
            <Send className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  )
}
