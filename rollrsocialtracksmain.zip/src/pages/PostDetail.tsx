"use client"

import { useState, useEffect } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { ArrowLeft } from "lucide-react"
import type { Post } from "@/types"
import { Button } from "@/components/ui/button"
import CommentSection from "@/components/posts/CommentSection"
import { useToast } from "@/hooks/use-toast"
import PostItem from "@/components/posts/PostItem"
import { supabase } from "@/integrations/supabase/client"
import { useAuth } from "@/contexts/AuthContext"

export default function PostDetail() {
  const { postId } = useParams<{ postId: string }>()
  const [post, setPost] = useState<Post | null>(null)
  const [comments, setComments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()
  const navigate = useNavigate()
  const { user } = useAuth()

  useEffect(() => {
    let postSubscription: any
    let commentsSubscription: any
    let likesSubscription: any
    let commentLikesSubscription: any

    async function fetchPost() {
      if (!postId) return

      try {
        setLoading(true)

        const { data, error } = await supabase
          .from("posts")
          .select(`
            *,
            user:profiles(id, username, name, avatar_url),
            images:post_images(image_url),
            activity:activities(*)
          `)
          .eq("id", postId)
          .single()

        if (error) throw error

        if (data) {
          const processedPost = {
            id: data.id,
            content: data.content,
            timestamp: data.created_at,
            likes: data.likes || 0,
            comments: data.comments || 0,
            user: {
              id: data.user.id,
              name: data.user.name || data.user.username,
              username: data.user.username,
              avatar: data.user.avatar_url,
              followers: 0,
              following: 0,
            },
            images: data.images?.map((img: any) => img.image_url) || [],
            activity: data.activity?.[0] || null,
            liked: false, // Будет обновлено при проверке лайков
          }

          setPost(processedPost)

          // Загружаем комментарии
          fetchComments(postId)

          // Проверяем, поставил ли пользователь лайк
          if (user) {
            checkUserLike(postId)
          }
        }

        // Настраиваем подписку на обновления поста
        postSubscription = supabase
          .channel(`post-${postId}`)
          .on(
            "postgres_changes",
            {
              event: "UPDATE",
              schema: "public",
              table: "posts",
              filter: `id=eq.${postId}`,
            },
            (payload) => {
              console.log("Пост обновлен:", payload)
              setPost((prev) => {
                if (!prev) return null
                return {
                  ...prev,
                  content: payload.new.content,
                  likes: payload.new.likes || 0,
                  comments: payload.new.comments || 0,
                }
              })
            },
          )
          .subscribe()

        // Настраиваем подписку на обновления лайков
        likesSubscription = supabase
          .channel(`post-likes-${postId}`)
          .on(
            "postgres_changes",
            {
              event: "*",
              schema: "public",
              table: "post_likes",
              filter: `post_id=eq.${postId}`,
            },
            (payload) => {
              console.log("Лайк обновлен:", payload)

              if (user && (payload.new?.user_id === user.id || payload.old?.user_id === user.id)) {
                setPost((prev) => {
                  if (!prev) return null
                  return {
                    ...prev,
                    liked: payload.eventType === "INSERT",
                  }
                })
              }
            },
          )
          .subscribe()
      } catch (error) {
        console.error("Ошибка при загрузке поста:", error)
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить пост",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    async function fetchComments(postId: string) {
      try {
        const { data, error } = await supabase
          .from("comments")
          .select(`
            *,
            user:profiles(id, username, name, avatar_url)
          `)
          .eq("post_id", postId)
          .order("created_at", { ascending: true })

        if (error) throw error

        if (data) {
          const processedComments = data.map((comment: any) => ({
            id: comment.id,
            content: comment.content,
            timestamp: comment.created_at,
            likes: comment.likes || 0,
            user: {
              id: comment.user.id,
              name: comment.user.name || comment.user.username,
              username: comment.user.username,
              avatar: comment.user.avatar_url,
              followers: 0,
              following: 0,
            },
            liked: false, // Будет обновлено при проверке лайков
          }))

          setComments(processedComments)

          // Проверяем лайки комментариев
          if (user && data.length > 0) {
            checkCommentLikes(data.map((comment: any) => comment.id))
          }
        }

        // Настраиваем подписку на обновления комментариев
        commentsSubscription = supabase
          .channel(`comments-${postId}`)
          .on(
            "postgres_changes",
            {
              event: "*",
              schema: "public",
              table: "comments",
              filter: `post_id=eq.${postId}`,
            },
            async (payload) => {
              console.log("Комментарий обновлен:", payload)

              if (payload.eventType === "INSERT") {
                // Загружаем новый комментарий с отношениями
                const { data: newComment } = await supabase
                  .from("comments")
                  .select(`
                  *,
                  user:profiles(id, username, name, avatar_url)
                `)
                  .eq("id", payload.new.id)
                  .single()

                if (newComment) {
                  const formattedComment = {
                    id: newComment.id,
                    content: newComment.content,
                    timestamp: newComment.created_at,
                    likes: newComment.likes || 0,
                    user: {
                      id: newComment.user.id,
                      name: newComment.user.name || newComment.user.username,
                      username: newComment.user.username,
                      avatar: newComment.user.avatar_url,
                      followers: 0,
                      following: 0,
                    },
                    liked: false,
                  }

                  setComments((prev) => [...prev, formattedComment])
                }
              } else if (payload.eventType === "UPDATE") {
                // Обновляем существующий комментарий
                setComments((prev) =>
                  prev.map((comment) =>
                    comment.id === payload.new.id
                      ? {
                          ...comment,
                          content: payload.new.content,
                          likes: payload.new.likes || 0,
                        }
                      : comment,
                  ),
                )
              } else if (payload.eventType === "DELETE") {
                // Удаляем комментарий
                setComments((prev) => prev.filter((comment) => comment.id !== payload.old.id))
              }
            },
          )
          .subscribe()

        // Настраиваем подписку на обновления лайков комментариев
        commentLikesSubscription = supabase
          .channel(`comment-likes-${postId}`)
          .on(
            "postgres_changes",
            {
              event: "*",
              schema: "public",
              table: "comment_likes",
            },
            (payload) => {
              console.log("Лайк комментария обновлен:", payload)

              if (user && (payload.new?.user_id === user.id || payload.old?.user_id === user.id)) {
                const commentId = payload.new?.comment_id || payload.old?.comment_id

                setComments((prev) =>
                  prev.map((comment) =>
                    comment.id === commentId
                      ? {
                          ...comment,
                          liked: payload.eventType === "INSERT",
                        }
                      : comment,
                  ),
                )
              }
            },
          )
          .subscribe()
      } catch (error) {
        console.error("Ошибка при загрузке комментариев:", error)
      }
    }

    async function checkUserLike(postId: string) {
      if (!user) return

      try {
        const { data, error } = await supabase
          .from("post_likes")
          .select()
          .eq("post_id", postId)
          .eq("user_id", user.id)
          .maybeSingle()

        if (!error && data) {
          setPost((prev) => (prev ? { ...prev, liked: true } : null))
        }
      } catch (error) {
        console.error("Ошибка при проверке лайка:", error)
      }
    }

    async function checkCommentLikes(commentIds: string[]) {
      if (!user || commentIds.length === 0) return

      try {
        const { data, error } = await supabase
          .from("comment_likes")
          .select("comment_id")
          .eq("user_id", user.id)
          .in("comment_id", commentIds)

        if (error) throw error

        if (data) {
          const likedCommentIds = new Set(data.map((like) => like.comment_id))

          setComments((prev) =>
            prev.map((comment) => ({
              ...comment,
              liked: likedCommentIds.has(comment.id),
            })),
          )
        }
      } catch (error) {
        console.error("Ошибка при проверке лайков комментариев:", error)
      }
    }

    fetchPost()

    // Очистка подписок при размонтировании компонента
    return () => {
      if (postSubscription) supabase.removeChannel(postSubscription)
      if (commentsSubscription) supabase.removeChannel(commentsSubscription)
      if (likesSubscription) supabase.removeChannel(likesSubscription)
      if (commentLikesSubscription) supabase.removeChannel(commentLikesSubscription)
    }
  }, [postId, user, toast])

  const handleLike = async () => {
    if (!user || !post) {
      toast({
        title: "Требуется авторизация",
        description: "Войдите в систему, чтобы ставить лайки",
        variant: "destructive",
      })
      return
    }

    try {
      if (post.liked) {
        // Удаляем лайк
        await supabase.from("post_likes").delete().match({ user_id: user.id, post_id: post.id })
      } else {
        // Добавляем лайк
        await supabase.from("post_likes").insert({ user_id: user.id, post_id: post.id })
      }

      // Обновляем UI оптимистично
      setPost({
        ...post,
        liked: !post.liked,
        likes: post.liked ? post.likes - 1 : post.likes + 1,
      })

      toast({
        title: post.liked ? "Убрано из понравившихся" : "Добавлено в понравившиеся",
        description: post.liked ? "Пост убран из списка понравившихся" : "Пост добавлен в список понравившихся",
      })
    } catch (error) {
      console.error("Ошибка при обновлении лайка:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось обновить лайк",
        variant: "destructive",
      })
    }
  }

  const handleAddComment = async (postId: string, content: string) => {
    if (!user) {
      toast({
        title: "Требуется авторизация",
        description: "Войдите в систему, чтобы оставлять комментарии",
        variant: "destructive",
      })
      return
    }

    try {
      const { data: newComment, error } = await supabase
        .from("comments")
        .insert({
          post_id: postId,
          user_id: user.id,
          content,
        })
        .select(`
          *,
          user:profiles(id, username, name, avatar_url)
        `)
        .single()

      if (error) throw error

      if (newComment) {
        // Добавляем комментарий в наш локальный state
        setComments((prev) => [
          ...prev,
          {
            id: newComment.id,
            content: newComment.content,
            timestamp: newComment.created_at,
            likes: 0,
            user: {
              id: newComment.user.id,
              name: newComment.user.name || newComment.user.username,
              username: newComment.user.username,
              avatar: newComment.user.avatar_url,
              followers: 0,
              following: 0,
            },
            liked: false,
          },
        ])

        // Обновляем счетчик комментариев в посте
        setPost((prev) =>
          prev
            ? {
                ...prev,
                comments: (prev.comments || 0) + 1,
              }
            : null,
        )

        toast({
          title: "Комментарий добавлен",
          description: "Ваш комментарий успешно добавлен к посту",
        })
      }
    } catch (error) {
      console.error("Ошибка при добавлении комментария:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось добавить комментарий",
        variant: "destructive",
      })
    }
  }

  const handleLikeComment = async (commentId: string) => {
    if (!user) {
      toast({
        title: "Требуется авторизация",
        description: "Войдите в систему, чтобы ставить лайки",
        variant: "destructive",
      })
      return
    }

    // Находим комментарий
    const targetComment = comments.find((c) => c.id === commentId)
    if (!targetComment) return

    try {
      if (targetComment.liked) {
        // Удаляем лайк
        await supabase.from("comment_likes").delete().match({ user_id: user.id, comment_id: commentId })
      } else {
        // Добавляем лайк
        await supabase.from("comment_likes").insert({ user_id: user.id, comment_id: commentId })
      }

      // Обновляем UI оптимистично
      setComments((prev) =>
        prev.map((comment) =>
          comment.id === commentId
            ? {
                ...comment,
                liked: !comment.liked,
                likes: comment.liked ? comment.likes - 1 : comment.likes + 1,
              }
            : comment,
        ),
      )
    } catch (error) {
      console.error("Ошибка при обновлении лайка комментария:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось обновить лайк комментария",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="animate-pulse p-4 space-y-4">
        <div className="h-10 bg-gray-200 rounded w-1/4"></div>
        <div className="h-40 bg-gray-200 rounded"></div>
        <div className="h-20 bg-gray-200 rounded"></div>
      </div>
    )
  }

  if (!post) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <h2 className="text-xl font-bold mb-2">Пост не найден</h2>
        <p className="text-gray-500 mb-4">Запрашиваемый пост не существует</p>
        <Button onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Вернуться назад
        </Button>
      </div>
    )
  }

  return (
    <div className="animate-fade-in pb-4">
      {/* Back button */}
      <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate(-1)}>
        <ArrowLeft className="w-4 h-4 mr-2" />
        Назад
      </Button>

      <PostItem post={post} onLike={handleLike} isDetailed={true} />

      {/* Comments section */}
      <div className="mt-4">
        <h3 className="text-lg font-medium mb-2">Комментарии</h3>
        <CommentSection
          postId={post.id}
          comments={comments}
          onAddComment={handleAddComment}
          onLikeComment={handleLikeComment}
        />
      </div>
    </div>
  )
}
