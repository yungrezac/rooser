"use client"

import { useState, useEffect } from "react"
import { Navigate, useNavigate } from "react-router-dom"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/contexts/AuthContext"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { LoginForm } from "@/components/auth/LoginForm"
import { RegisterForm } from "@/components/auth/RegisterForm"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader, Info } from "lucide-react"

export default function Auth() {
  const { user, isLoading } = useAuth()
  const [activeTab, setActiveTab] = useState<"login" | "register">("login")
  const [error, setError] = useState<string | null>(null)
  const navigate = useNavigate()

  // Reset errors when changing tabs
  const handleTabChange = (value: string) => {
    setActiveTab(value as "login" | "register")
    setError(null)
  }

  // Check session when page loads
  useEffect(() => {
    if (user && !isLoading) {
      navigate("/", { replace: true })
    }
  }, [user, isLoading, navigate])

  // Show loading indicator
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[calc(100vh-150px)] px-4 py-12">
        <div className="flex flex-col items-center">
          <Loader className="h-8 w-8 animate-spin text-rllr-purple mb-4" />
          <p className="text-gray-600">Проверка авторизации...</p>
        </div>
      </div>
    )
  }

  // Redirect if user is already authenticated
  if (user) {
    return <Navigate to="/" />
  }

  return (
    <div className="flex justify-center items-center min-h-[calc(100vh-150px)] px-4 py-12 bg-gray-50">
      <Card className="w-full max-w-md shadow-lg border-0">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-rllr-purple">RLLR</CardTitle>
          <CardDescription className="text-gray-600">
            Добро пожаловать! Войдите в аккаунт или зарегистрируйтесь
          </CardDescription>
        </CardHeader>

        <CardContent>
          <Alert className="mb-4 bg-yellow-50 border border-yellow-200">
            <Info className="h-4 w-4 text-yellow-600" />
            <AlertTitle className="text-yellow-800">Режим без RLS</AlertTitle>
            <AlertDescription className="text-yellow-700 text-sm">
              В настоящее время Row Level Security (RLS) отключен. Все данные доступны любому пользователю, но будут
              обновляться в реальном времени через Supabase Realtime.
            </AlertDescription>
          </Alert>

          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="grid grid-cols-2 mb-8 w-full">
              <TabsTrigger value="login" className="py-3">
                Вход
              </TabsTrigger>
              <TabsTrigger value="register" className="py-3">
                Регистрация
              </TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="mt-0">
              <LoginForm onError={setError} />
            </TabsContent>

            <TabsContent value="register" className="mt-0">
              <RegisterForm onError={setError} />
            </TabsContent>
          </Tabs>
        </CardContent>

        <CardFooter className="flex justify-center text-sm text-gray-500 border-t pt-4 mt-2">
          <p className="text-center">© {new Date().getFullYear()} RLLR. Все права защищены.</p>
        </CardFooter>
      </Card>
    </div>
  )
}
