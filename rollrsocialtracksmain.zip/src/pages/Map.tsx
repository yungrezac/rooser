"use client"

import { useState, useEffect, useCallback } from "react"
import RouteMap from "@/components/map/RouteMap"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import SaveRouteForm from "@/components/map/SaveRouteForm"
import LocationSpots from "@/components/map/LocationSpots"
import SavedRoutes from "@/components/map/SavedRoutes"
import PlacesManager from "@/components/map/PlacesManager"
import { MapPin } from "lucide-react"
import type { LocationPoint, Route } from "@/types"
import { supabase } from "@/integrations/supabase/client"
import { useAuth } from "@/contexts/AuthContext"

interface RouteData {
  distance: number
  duration: number
  points: { lat: number; lng: number }[]
}

interface UserLocation {
  username: string
  avatarUrl: string
  location: { lat: number; lng: number }
  isRecording?: boolean
  distance?: number
  duration?: number
}

export default function Map() {
  const [activeTab, setActiveTab] = useState("map")
  const [recordedRoute, setRecordedRoute] = useState<RouteData | null>(null)
  const [showSaveForm, setShowSaveForm] = useState(false)
  const { toast } = useToast()
  const [isSharingLocation, setIsSharingLocation] = useState(false)
  const { user } = useAuth()

  // State for spots and routes
  const [spots, setSpots] = useState<LocationPoint[]>([])
  const [routes, setRoutes] = useState<Route[]>([])
  const [isLoading, setIsLoading] = useState(true)

  const [userLocations, setUserLocations] = useState<UserLocation[]>([
    {
      username: "alexskater",
      avatarUrl: "https://i.pravatar.cc/150?img=3",
      location: { lat: 55.7522, lng: 37.6156 },
    },
    {
      username: "mariaskat",
      avatarUrl: "https://i.pravatar.cc/150?img=5",
      location: { lat: 55.7539, lng: 37.6208 },
      isRecording: true,
      distance: 3.2,
      duration: 15.5,
    },
  ])

  // Загрузка мест и маршрутов из Supabase
  useEffect(() => {
    const fetchLocations = async () => {
      try {
        setIsLoading(true)

        // Загрузка мест
        const { data: spotsData, error: spotsError } = await supabase
          .from("location_points")
          .select("*")
          .eq("type", "spot")

        if (spotsError) throw spotsError

        if (spotsData) {
          setSpots(
            spotsData.map((spot) => ({
              id: spot.id,
              name: spot.name,
              description: spot.description,
              type: spot.type,
              location: spot.location,
              rating: spot.rating,
              difficulty: spot.difficulty,
              surface: spot.surface,
              openHours: spot.open_hours,
            })),
          )
        }

        // Загрузка маршрутов (если пользователь авторизован)
        if (user) {
          const { data: routesData, error: routesError } = await supabase
            .from("routes")
            .select("*")
            .or(`user_id.eq.${user.id},is_public.eq.true`)

          if (routesError) throw routesError

          if (routesData) {
            setRoutes(
              routesData.map((route) => ({
                id: route.id,
                name: route.name,
                points: route.points,
                distance: route.distance,
                timestamp: route.timestamp,
                isPublic: route.is_public,
              })),
            )
          }
        }
      } catch (error) {
        console.error("Ошибка при загрузке данных:", error)
        toast({
          title: "Ошибка загрузки данных",
          description: "Не удалось загрузить места и маршруты",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchLocations()
  }, [user, toast])

  // Мемоизированная функция обновления позиций пользователей
  const updateUserLocations = useCallback(() => {
    setUserLocations((prevUsers) =>
      prevUsers.map((user) => ({
        ...user,
        location: {
          lat: user.location.lat + (Math.random() - 0.5) * 0.001,
          lng: user.location.lng + (Math.random() - 0.5) * 0.001,
        },
        distance: user.isRecording ? (user.distance || 0) + 0.05 : user.distance,
        duration: user.isRecording ? (user.duration || 0) + 0.16 : user.duration,
      })),
    )
  }, [])

  // Эмулируем движение пользователей каждые 5 секунд
  useEffect(() => {
    const interval = setInterval(updateUserLocations, 5000)
    return () => clearInterval(interval)
  }, [updateUserLocations])

  // Обработчик для записанного маршрута
  const handleRouteRecorded = (data: RouteData) => {
    setRecordedRoute(data)
    setShowSaveForm(true)
  }

  // Обработчик для сохранения маршрута
  const handleSaveRoute = async (routeName: string, isPublic: boolean) => {
    if (!recordedRoute || !user) return

    try {
      // Сохраняем маршрут в базе данных
      const { data, error } = await supabase
        .from("routes")
        .insert([
          {
            name: routeName,
            points: recordedRoute.points,
            distance: recordedRoute.distance,
            is_public: isPublic,
            user_id: user.id,
          },
        ])
        .select()
        .single()

      if (error) throw error

      // Добавляем новый маршрут в локальное состояние
      const newRoute: Route = {
        id: data.id,
        name: data.name,
        points: data.points,
        distance: data.distance,
        timestamp: data.timestamp,
        isPublic: data.is_public,
      }

      setRoutes((prev) => [...prev, newRoute])

      toast({
        title: "Маршрут сохранен",
        description: `Маршрут "${routeName}" успешно сохранен`,
      })
    } catch (error: any) {
      console.error("Ошибка сохранения маршрута:", error)
      toast({
        title: "Ошибка сохранения",
        description: error.message || "Не удалось сохранить маршрут",
        variant: "destructive",
      })
    }

    setShowSaveForm(false)
    setRecordedRoute(null)
  }

  // Обработчик для отмены сохранения маршрута
  const handleCancelSave = () => {
    setShowSaveForm(false)
    setRecordedRoute(null)
  }

  // Обработчик для выбора маршрута
  const handleSelectRoute = (route: Route) => {
    toast({
      title: "Маршрут выбран",
      description: `"${route.name}" отображается на карте`,
    })
  }

  // Обработчик для добавления нового места
  const handleAddSpot = async (spot: LocationPoint) => {
    if (!user) {
      toast({
        title: "Требуется авторизация",
        description: "Для добавления мест необходимо войти в аккаунт",
        variant: "destructive",
      })
      return
    }

    try {
      // Сохраняем место в базе данных
      const { data, error } = await supabase
        .from("location_points")
        .insert([
          {
            name: spot.name,
            description: spot.description,
            type: "spot",
            location: spot.location,
            rating: spot.rating,
            difficulty: spot.difficulty,
            surface: spot.surface,
            open_hours: spot.openHours,
            created_by: user.id,
          },
        ])
        .select()
        .single()

      if (error) throw error

      // Добавляем новое место в локальное состояние
      const newSpot: LocationPoint = {
        id: data.id,
        name: data.name,
        description: data.description,
        type: data.type,
        location: data.location,
        rating: data.rating,
        difficulty: data.difficulty,
        surface: data.surface,
        openHours: data.open_hours,
      }

      setSpots((prev) => [...prev, newSpot])

      toast({
        title: "Место добавлено",
        description: `"${spot.name}" успешно добавлено на карту`,
      })
    } catch (error: any) {
      console.error("Ошибка добавления места:", error)
      toast({
        title: "Ошибка добавления",
        description: error.message || "Не удалось добавить место",
        variant: "destructive",
      })
    }
  }

  // Обработчик для выбора места
  const handleSelectSpot = (spot: LocationPoint) => {
    toast({
      title: "Место выбрано",
      description: `"${spot.name}" показано на карте`,
    })
  }

  // Обработчик для клика по месту
  const handleSpotClick = (spot: LocationPoint) => {
    toast({
      title: spot.name,
      description: spot.description || "Нет описания",
    })
  }

  // Обработка включения/выключения трансляции геопозиции
  const handleToggleLocationSharing = (isSharing: boolean) => {
    if (!user && isSharing) {
      toast({
        title: "Требуется авторизация",
        description: "Для трансляции геопозиции необходимо войти в аккаунт",
        variant: "destructive",
      })
      return
    }

    setIsSharingLocation(isSharing)

    if (isSharing) {
      toast({
        title: "Трансляция включена",
        description: "Ваша геопозиция доступна другим пользователям",
      })

      if (user && !userLocations.find((u) => u.username === user.user_metadata.username)) {
        setUserLocations((prevUsers) => [
          ...prevUsers,
          {
            username: user.user_metadata.username || "user",
            avatarUrl: user.user_metadata.avatar_url || "https://i.pravatar.cc/150?img=1",
            location: { lat: 55.7516, lng: 37.618 },
            isRecording: false,
          },
        ])
      }
    } else {
      toast({
        title: "Трансляция выключена",
        description: "Ваша геопозиция больше не транслируется",
      })

      if (user) {
        setUserLocations((prevUsers) => prevUsers.filter((u) => u.username !== user.user_metadata.username))
      }
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin h-8 w-8 border-4 border-rllr-purple border-t-transparent rounded-full"></div>
      </div>
    )
  }

  return (
    <div className="animate-fade-in">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-3 mb-4">
          <TabsTrigger value="map" className="data-[state=active]:bg-rllr-purple data-[state=active]:text-white">
            <MapPin className="w-4 h-4 mr-2" />
            Карта
          </TabsTrigger>
          <TabsTrigger value="routes" className="data-[state=active]:bg-rllr-purple data-[state=active]:text-white">
            Маршруты
          </TabsTrigger>
          <TabsTrigger value="places" className="data-[state=active]:bg-rllr-purple data-[state=active]:text-white">
            Места
          </TabsTrigger>
        </TabsList>

        <TabsContent value="map" className="animate-fade-in">
          <div className="mb-4 space-y-4">
            <RouteMap
              onRouteRecorded={handleRouteRecorded}
              userLocations={userLocations}
              isSharingLocation={isSharingLocation}
              onToggleLocationSharing={handleToggleLocationSharing}
            />

            {showSaveForm && recordedRoute && (
              <SaveRouteForm
                distance={recordedRoute.distance}
                duration={recordedRoute.duration}
                points={recordedRoute.points}
                onSave={handleSaveRoute}
                onCancel={handleCancelSave}
              />
            )}

            <LocationSpots spots={spots} onSpotClick={handleSpotClick} />
          </div>
        </TabsContent>

        <TabsContent value="routes" className="animate-fade-in">
          <SavedRoutes routes={routes} onSelectRoute={handleSelectRoute} />
        </TabsContent>

        <TabsContent value="places" className="animate-fade-in">
          <PlacesManager spots={spots} onAddSpot={handleAddSpot} onSelectSpot={handleSelectSpot} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
