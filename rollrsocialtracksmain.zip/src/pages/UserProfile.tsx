"use client"

import { useState, useEffect } from "react"
import { useParams, Link, useNavigate } from "react-router-dom"
import { ActivitySquare, Calendar, MapPin, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import AchievementsList from "@/components/profile/AchievementsList"
import type { User, Achievement, Activity, Post } from "@/types"
import { useToast } from "@/hooks/use-toast"
import { getUserAchievements } from "@/services/achievementService"
import { supabase } from "@/integrations/supabase/client"
import { useAuth } from "@/contexts/AuthContext"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function UserProfile() {
  const { username } = useParams()
  const navigate = useNavigate()
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isFollowing, setIsFollowing] = useState(false)
  const [activeTab, setActiveTab] = useState("posts")
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const [posts, setPosts] = useState<Post[]>([])
  const [activities, setActivities] = useState<Activity[]>([])
  const [stats, setStats] = useState({
    totalActivities: 0,
    totalDistance: 0,
    totalDuration: 0,
    totalElevation: 0,
  })
  const { toast } = useToast()
  const { user: currentUser } = useAuth()

  useEffect(() => {
    if (!username) return

    const fetchUserProfile = async () => {
      try {
        setIsLoading(true)

        // Получаем профиль пользователя по username
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("username", username)
          .single()

        if (profileError) throw profileError

        if (!profileData) {
          setUser(null)
          return
        }

        // Проверяем, подписаны ли мы на этого пользователя
        let isFollowingUser = false
        if (currentUser) {
          const { data: followData, error: followError } = await supabase
            .from("follows")
            .select("*")
            .eq("follower_id", currentUser.id)
            .eq("following_id", profileData.id)
            .maybeSingle()

          if (!followError && followData) {
            isFollowingUser = true
          }
        }

        // Форматируем данные пользователя
        const userData: User = {
          id: profileData.id,
          name: profileData.name || profileData.username,
          username: profileData.username,
          avatar: profileData.avatar_url || "",
          bio: profileData.bio,
          followers: profileData.followers || 0,
          following: profileData.following || 0,
          isFollowing: isFollowingUser,
        }

        setUser(userData)
        setIsFollowing(isFollowingUser)

        // Загружаем посты пользователя
        const { data: postsData, error: postsError } = await supabase
          .from("posts")
          .select(`
            *,
            user:profiles(id, username, name, avatar_url),
            images:post_images(image_url)
          `)
          .eq("user_id", profileData.id)
          .order("created_at", { ascending: false })

        if (postsError) throw postsError

        const formattedPosts = postsData.map((post: any) => ({
          id: post.id,
          content: post.content,
          timestamp: post.created_at,
          likes: post.likes || 0,
          comments: post.comments || 0,
          user: {
            id: post.user.id,
            name: post.user.name || post.user.username,
            username: post.user.username,
            avatar: post.user.avatar_url,
            followers: 0,
            following: 0,
          },
          images: post.images?.map((img: any) => img.image_url) || [],
          liked: false,
        }))

        setPosts(formattedPosts)

        // Загружаем активности пользователя
        const { data: activitiesData, error: activitiesError } = await supabase
          .from("activities")
          .select(`
            *,
            route:routes(*)
          `)
          .eq("user_id", profileData.id)
          .order("created_at", { ascending: false })

        if (activitiesError) throw activitiesError

        const formattedActivities = activitiesData.map((activity: any) => ({
          id: activity.id,
          type: activity.type,
          distance: activity.distance,
          duration: activity.duration,
          avgSpeed: activity.avg_speed,
          elevation: activity.elevation || 0,
          timestamp: activity.timestamp || activity.created_at,
          route: activity.route
            ? {
                id: activity.route.id,
                name: activity.route.name,
                distance: activity.route.distance,
                points: activity.route.points,
                isPublic: activity.route.is_public,
              }
            : undefined,
          user: {
            id: profileData.id,
            name: profileData.name || profileData.username,
            username: profileData.username,
            avatar: profileData.avatar_url,
            followers: profileData.followers || 0,
            following: profileData.following || 0,
          },
        }))

        setActivities(formattedActivities)

        // Рассчитываем статистику
        const totalActivities = formattedActivities.length
        const totalDistance = formattedActivities.reduce((sum, act) => sum + act.distance, 0)
        const totalDuration = formattedActivities.reduce((sum, act) => sum + act.duration, 0)
        const totalElevation = formattedActivities.reduce((sum, act) => sum + (act.elevation || 0), 0)

        setStats({
          totalActivities,
          totalDistance,
          totalDuration,
          totalElevation,
        })

        // Загружаем достижения пользователя
        const userAchievements = await getUserAchievements(profileData.id)
        setAchievements(userAchievements)
      } catch (error: any) {
        console.error("Ошибка при загрузке профиля пользователя:", error)
        toast({
          title: "Ошибка загрузки профиля",
          description: error.message || "Не удалось загрузить профиль пользователя",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchUserProfile()
  }, [username, currentUser, toast])

  const handleFollow = async () => {
    if (!currentUser || !user) {
      toast({
        title: "Требуется авторизация",
        description: "Войдите в систему, чтобы подписаться на пользователя",
        variant: "destructive",
      })
      return
    }

    try {
      if (isFollowing) {
        // Отписываемся
        await supabase.from("follows").delete().match({ follower_id: currentUser.id, following_id: user.id })
      } else {
        // Подписываемся
        await supabase.from("follows").insert({ follower_id: currentUser.id, following_id: user.id })
      }

      // Обновляем UI оптимистично
      setIsFollowing(!isFollowing)
      setUser((prev) => {
        if (!prev) return null
        return {
          ...prev,
          followers: isFollowing ? prev.followers - 1 : prev.followers + 1,
          isFollowing: !isFollowing,
        }
      })

      toast({
        title: isFollowing ? "Отписка" : "Подписка",
        description: isFollowing ? `Вы отписались от ${user.username}` : `Вы подписались на ${user.username}`,
      })
    } catch (error: any) {
      console.error("Ошибка при изменении подписки:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось изменить подписку",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="animate-pulse flex flex-col space-y-4 p-4">
        <div className="flex items-center space-x-4">
          <div className="rounded-full bg-gray-200 h-12 w-12"></div>
          <div className="flex-1 space-y-2">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-3 bg-gray-200 rounded w-1/2"></div>
          </div>
        </div>
        <div className="h-4 bg-gray-200 rounded"></div>
        <div className="grid grid-cols-3 gap-4">
          <div className="h-8 bg-gray-200 rounded"></div>
          <div className="h-8 bg-gray-200 rounded"></div>
          <div className="h-8 bg-gray-200 rounded"></div>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <h2 className="text-xl font-bold mb-2">Пользователь не найден</h2>
        <p className="text-gray-500 mb-4">Пользователь @{username} не существует</p>
        <Button onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Вернуться назад
        </Button>
      </div>
    )
  }

  return (
    <div className="animate-fade-in pb-6 space-y-6">
      {/* Верхняя секция профиля */}
      <Card className="ios-card overflow-hidden">
        <div className="relative h-24 bg-gradient-rllr">
          <div className="absolute -bottom-16 left-4">
            <Avatar className="w-24 h-24 rounded-full border-4 border-white shadow-md">
              <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
              <AvatarFallback>
                {user.name?.substring(0, 2).toUpperCase() || user.username?.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
          </div>

          <div className="absolute top-3 left-3">
            <Button variant="ghost" size="sm" className="text-white" onClick={() => navigate(-1)}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Назад
            </Button>
          </div>

          <div className="absolute top-3 right-3">
            <Button
              variant={isFollowing ? "outline" : "default"}
              size="sm"
              onClick={handleFollow}
              className={isFollowing ? "bg-white" : "bg-rllr-purple hover:bg-rllr-purple/80"}
            >
              {isFollowing ? "Отписаться" : "Подписаться"}
            </Button>
          </div>
        </div>

        <CardContent className="pt-20 pb-4 px-4">
          <div className="mb-3">
            <h1 className="text-xl font-bold">{user.name}</h1>
            <p className="text-gray-600 text-sm">@{user.username}</p>
          </div>

          {user.bio && <p className="text-gray-700 text-sm mb-4">{user.bio}</p>}

          <div className="flex gap-4 bg-gray-50 p-3 rounded-xl text-center">
            <div className="flex-1">
              <p className="font-bold text-lg">{posts.length}</p>
              <p className="text-xs text-gray-500">публикаций</p>
            </div>
            <div className="flex-1 border-x border-gray-200">
              <p className="font-bold text-lg">{user.followers}</p>
              <p className="text-xs text-gray-500">подписчиков</p>
            </div>
            <div className="flex-1">
              <p className="font-bold text-lg">{user.following}</p>
              <p className="text-xs text-gray-500">подписок</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Табы с контентом */}
      <div className="bg-white rounded-2xl ios-shadow">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="px-4 pt-4">
            <TabsList className="w-full grid grid-cols-3 mb-4 bg-gray-100 p-1 rounded-xl gap-1">
              <TabsTrigger
                value="posts"
                className="data-[state=active]:bg-white data-[state=active]:text-rllr-purple data-[state=active]:shadow-sm rounded-lg"
              >
                Посты
              </TabsTrigger>
              <TabsTrigger
                value="activities"
                className="data-[state=active]:bg-white data-[state=active]:text-rllr-purple data-[state=active]:shadow-sm rounded-lg"
              >
                Активность
              </TabsTrigger>
              <TabsTrigger
                value="achievements"
                className="data-[state=active]:bg-white data-[state=active]:text-rllr-purple data-[state=active]:shadow-sm rounded-lg"
              >
                Достижения
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Содержимое таба Посты */}
          <TabsContent value="posts" className="animate-fade-in p-4">
            {posts.length > 0 ? (
              <div className="grid grid-cols-2 gap-2">
                {posts.map((post) => (
                  <Link key={post.id} to={`/post/${post.id}`} className="block hover-scale">
                    <div className="aspect-square rounded-xl overflow-hidden bg-gray-100 hover:opacity-90 transition-opacity shadow-sm">
                      {post.images && post.images.length > 0 ? (
                        <img
                          src={post.images[0] || "/placeholder.svg"}
                          alt="Post"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center p-4 text-center">
                          <p className="text-sm text-gray-500">{post.content?.substring(0, 40)}...</p>
                        </div>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <p className="text-gray-500">У пользователя пока нет публикаций</p>
              </div>
            )}
          </TabsContent>

          {/* Содержимое таба Активности */}
          <TabsContent value="activities" className="animate-fade-in p-4">
            {activities.length > 0 ? (
              <div className="space-y-3">
                {activities.map((activity) => (
                  <div
                    key={activity.id}
                    className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm hover-scale"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="p-2 rounded-full bg-blue-100">
                          <ActivitySquare className="w-5 h-5 text-rllr-blue" />
                        </div>
                        <div>
                          <h3 className="font-medium">{activity.type === "skating" ? "Катание" : "Ролики"}</h3>
                          <p className="text-xs text-gray-500 flex items-center">
                            <Calendar className="w-3 h-3 mr-1" />
                            {new Date(activity.timestamp).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <Badge variant="default" className="bg-gradient-rllr">
                        {activity.distance} км
                      </Badge>
                    </div>

                    {activity.route && (
                      <div>
                        <p className="text-sm font-medium mb-1 flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {activity.route.name}
                        </p>
                        <div className="bg-gray-100 h-24 rounded-lg flex items-center justify-center">
                          <p className="text-xs text-gray-500">Карта маршрута</p>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <p className="text-gray-500">У пользователя пока нет активностей</p>
              </div>
            )}
          </TabsContent>

          {/* Содержимое таба Достижения */}
          <TabsContent value="achievements" className="animate-fade-in p-4">
            <div className="rllr-card">
              <AchievementsList achievements={achievements} />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
