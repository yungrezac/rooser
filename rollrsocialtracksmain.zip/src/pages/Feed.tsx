"use client"

import { useState, useEffect } from "react"
import type { Post, Comment } from "@/types"
import CommentSection from "@/components/posts/CommentSection"
import { useToast } from "@/hooks/use-toast"
import PostItem from "@/components/posts/PostItem"
import { supabase } from "@/integrations/supabase/client"
import { useAuth } from "@/contexts/AuthContext"

export default function Feed() {
  const [posts, setPosts] = useState<Post[]>([])
  const [comments, setComments] = useState<Record<string, Comment[]>>({})
  const [expandedComments, setExpandedComments] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()
  const { user } = useAuth()

  useEffect(() => {
    let postsSubscription: any
    let commentsSubscription: any
    let likesSubscription: any
    let commentLikesSubscription: any

    async function fetchPosts() {
      try {
        setIsLoading(true)
        const { data: postsData, error } = await supabase
          .from("posts")
          .select(`
            *,
            user:profiles(id, username, name, avatar_url),
            images:post_images(image_url)
          `)
          .order("created_at", { ascending: false })
          .limit(20)

        if (error) throw error

        if (postsData) {
          const formattedPosts = postsData.map((post: any) => ({
            id: post.id,
            content: post.content,
            timestamp: post.created_at,
            likes: post.likes || 0,
            comments: post.comments || 0,
            user: {
              id: post.user.id,
              name: post.user.name || post.user.username,
              username: post.user.username,
              avatar: post.user.avatar_url,
              followers: 0,
              following: 0,
            },
            images: post.images?.map((img: any) => img.image_url) || [],
            liked: false, // Будет обновлено при загрузке лайков
          }))

          setPosts(formattedPosts)

          // Загружаем комментарии для всех постов
          const postIds = postsData.map((post: any) => post.id)
          if (postIds.length > 0) {
            fetchComments(postIds)
          }

          // Проверяем лайки пользователя если он авторизован
          if (user) {
            checkUserLikes(postIds)
          }
        }

        // Настраиваем подписку на обновления постов
        postsSubscription = supabase
          .channel("public:posts")
          .on(
            "postgres_changes",
            {
              event: "*",
              schema: "public",
              table: "posts",
            },
            async (payload) => {
              console.log("Изменение в постах:", payload)

              if (payload.eventType === "INSERT") {
                // Загружаем новый пост с отношениями
                const { data: newPost } = await supabase
                  .from("posts")
                  .select(`
                  *,
                  user:profiles(id, username, name, avatar_url),
                  images:post_images(image_url)
                `)
                  .eq("id", payload.new.id)
                  .single()

                if (newPost) {
                  const formattedPost = {
                    id: newPost.id,
                    content: newPost.content,
                    timestamp: newPost.created_at,
                    likes: newPost.likes || 0,
                    comments: newPost.comments || 0,
                    user: {
                      id: newPost.user.id,
                      name: newPost.user.name || newPost.user.username,
                      username: newPost.user.username,
                      avatar: newPost.user.avatar_url,
                      followers: 0,
                      following: 0,
                    },
                    images: newPost.images?.map((img: any) => img.image_url) || [],
                    liked: false,
                  }

                  setPosts((prevPosts) => [formattedPost, ...prevPosts])
                }
              } else if (payload.eventType === "UPDATE") {
                // Обновляем существующий пост
                setPosts((prevPosts) =>
                  prevPosts.map((post) =>
                    post.id === payload.new.id
                      ? {
                          ...post,
                          content: payload.new.content,
                          likes: payload.new.likes || 0,
                          comments: payload.new.comments || 0,
                        }
                      : post,
                  ),
                )
              } else if (payload.eventType === "DELETE") {
                // Удаляем пост
                setPosts((prevPosts) => prevPosts.filter((post) => post.id !== payload.old.id))
              }
            },
          )
          .subscribe()

        // Настраиваем подписку на обновления лайков
        likesSubscription = supabase
          .channel("public:post_likes")
          .on(
            "postgres_changes",
            {
              event: "*",
              schema: "public",
              table: "post_likes",
            },
            async (payload) => {
              console.log("Изменение в лайках постов:", payload)

              if (user && (payload.new?.user_id === user.id || payload.old?.user_id === user.id)) {
                // Обновляем статус лайка для текущего пользователя
                const postId = payload.new?.post_id || payload.old?.post_id

                setPosts((prevPosts) =>
                  prevPosts.map((post) =>
                    post.id === postId
                      ? {
                          ...post,
                          liked: payload.eventType === "INSERT",
                        }
                      : post,
                  ),
                )
              }
            },
          )
          .subscribe()
      } catch (error) {
        console.error("Ошибка при загрузке постов:", error)
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить посты",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    async function fetchComments(postIds: string[]) {
      try {
        const { data: commentsData, error } = await supabase
          .from("comments")
          .select(`
            *,
            user:profiles(id, username, name, avatar_url)
          `)
          .in("post_id", postIds)
          .order("created_at", { ascending: true })

        if (error) throw error

        if (commentsData) {
          const commentsByPost: Record<string, Comment[]> = {}

          commentsData.forEach((comment: any) => {
            if (!commentsByPost[comment.post_id]) {
              commentsByPost[comment.post_id] = []
            }
            commentsByPost[comment.post_id].push({
              id: comment.id,
              content: comment.content,
              timestamp: comment.created_at,
              likes: comment.likes || 0,
              user: {
                id: comment.user.id,
                name: comment.user.name || comment.user.username,
                username: comment.user.username,
                avatar: comment.user.avatar_url,
                followers: 0,
                following: 0,
              },
              liked: false, // Будет обновлено при загрузке лайков комментариев
            })
          })

          setComments(commentsByPost)

          // Проверяем лайки комментариев если пользователь авторизован
          if (user && commentsData.length > 0) {
            checkCommentLikes(commentsData.map((comment: any) => comment.id))
          }
        }

        // Настраиваем подписку на обновления комментариев
        commentsSubscription = supabase
          .channel("public:comments")
          .on(
            "postgres_changes",
            {
              event: "*",
              schema: "public",
              table: "comments",
            },
            async (payload) => {
              console.log("Изменение в комментариях:", payload)

              if (payload.eventType === "INSERT") {
                // Загружаем новый комментарий с отношениями
                const { data: newComment } = await supabase
                  .from("comments")
                  .select(`
                  *,
                  user:profiles(id, username, name, avatar_url)
                `)
                  .eq("id", payload.new.id)
                  .single()

                if (newComment) {
                  const formattedComment = {
                    id: newComment.id,
                    content: newComment.content,
                    timestamp: newComment.created_at,
                    likes: newComment.likes || 0,
                    user: {
                      id: newComment.user.id,
                      name: newComment.user.name || newComment.user.username,
                      username: newComment.user.username,
                      avatar: newComment.user.avatar_url,
                      followers: 0,
                      following: 0,
                    },
                    liked: false,
                  }

                  setComments((prevComments) => {
                    const postId = newComment.post_id
                    const updatedComments = { ...prevComments }

                    if (!updatedComments[postId]) {
                      updatedComments[postId] = []
                    }

                    updatedComments[postId] = [...updatedComments[postId], formattedComment]
                    return updatedComments
                  })

                  // Обновляем счетчик комментариев в посте
                  setPosts((prevPosts) =>
                    prevPosts.map((post) =>
                      post.id === newComment.post_id ? { ...post, comments: (post.comments || 0) + 1 } : post,
                    ),
                  )
                }
              } else if (payload.eventType === "UPDATE") {
                // Обновляем существующий комментарий
                setComments((prevComments) => {
                  const postId = payload.new.post_id
                  if (!prevComments[postId]) return prevComments

                  const updatedComments = { ...prevComments }
                  updatedComments[postId] = updatedComments[postId].map((comment) =>
                    comment.id === payload.new.id
                      ? {
                          ...comment,
                          content: payload.new.content,
                          likes: payload.new.likes || 0,
                        }
                      : comment,
                  )

                  return updatedComments
                })
              } else if (payload.eventType === "DELETE") {
                // Удаляем комментарий
                setComments((prevComments) => {
                  const postId = payload.old.post_id
                  if (!prevComments[postId]) return prevComments

                  const updatedComments = { ...prevComments }
                  updatedComments[postId] = updatedComments[postId].filter((comment) => comment.id !== payload.old.id)

                  return updatedComments
                })

                // Обновляем счетчик комментариев в посте
                setPosts((prevPosts) =>
                  prevPosts.map((post) =>
                    post.id === payload.old.post_id
                      ? { ...post, comments: Math.max((post.comments || 1) - 1, 0) }
                      : post,
                  ),
                )
              }
            },
          )
          .subscribe()

        // Настраиваем подписку на обновления лайков комментариев
        commentLikesSubscription = supabase
          .channel("public:comment_likes")
          .on(
            "postgres_changes",
            {
              event: "*",
              schema: "public",
              table: "comment_likes",
            },
            async (payload) => {
              console.log("Изменение в лайках комментариев:", payload)

              if (user && (payload.new?.user_id === user.id || payload.old?.user_id === user.id)) {
                // Обновляем статус лайка для текущего пользователя
                const commentId = payload.new?.comment_id || payload.old?.comment_id

                setComments((prevComments) => {
                  const updatedComments = { ...prevComments }

                  for (const postId in updatedComments) {
                    updatedComments[postId] = updatedComments[postId].map((comment) =>
                      comment.id === commentId
                        ? {
                            ...comment,
                            liked: payload.eventType === "INSERT",
                          }
                        : comment,
                    )
                  }

                  return updatedComments
                })
              }
            },
          )
          .subscribe()
      } catch (error) {
        console.error("Ошибка при загрузке комментариев:", error)
      }
    }

    async function checkUserLikes(postIds: string[]) {
      if (!user || postIds.length === 0) return

      try {
        const { data: likesData, error } = await supabase
          .from("post_likes")
          .select("post_id")
          .eq("user_id", user.id)
          .in("post_id", postIds)

        if (error) throw error

        if (likesData) {
          const likedPostIds = new Set(likesData.map((like: any) => like.post_id))

          setPosts((prevPosts) =>
            prevPosts.map((post) => ({
              ...post,
              liked: likedPostIds.has(post.id),
            })),
          )
        }
      } catch (error) {
        console.error("Ошибка при проверке лайков:", error)
      }
    }

    async function checkCommentLikes(commentIds: string[]) {
      if (!user || commentIds.length === 0) return

      try {
        const { data: likesData, error } = await supabase
          .from("comment_likes")
          .select("comment_id")
          .eq("user_id", user.id)
          .in("comment_id", commentIds)

        if (error) throw error

        if (likesData) {
          const likedCommentIds = new Set(likesData.map((like: any) => like.comment_id))

          setComments((prevComments) => {
            const newComments = { ...prevComments }

            for (const postId in newComments) {
              newComments[postId] = newComments[postId].map((comment) => ({
                ...comment,
                liked: likedCommentIds.has(comment.id),
              }))
            }

            return newComments
          })
        }
      } catch (error) {
        console.error("Ошибка при проверке лайков комментариев:", error)
      }
    }

    fetchPosts()

    // Очистка подписок при размонтировании компонента
    return () => {
      if (postsSubscription) supabase.removeChannel(postsSubscription)
      if (commentsSubscription) supabase.removeChannel(commentsSubscription)
      if (likesSubscription) supabase.removeChannel(likesSubscription)
      if (commentLikesSubscription) supabase.removeChannel(commentLikesSubscription)
    }
  }, [toast, user])

  const handleLike = async (postId: string) => {
    if (!user) {
      toast({
        title: "Требуется авторизация",
        description: "Пожалуйста, войдите в систему, чтобы ставить лайки",
        variant: "destructive",
      })
      return
    }

    const isLiked = posts.find((p) => p.id === postId)?.liked

    try {
      if (isLiked) {
        // Удаляем лайк
        await supabase.from("post_likes").delete().match({ user_id: user.id, post_id: postId })
      } else {
        // Добавляем лайк
        await supabase.from("post_likes").insert({ user_id: user.id, post_id: postId })
      }

      // Обновляем UI оптимистично
      setPosts((prevPosts) =>
        prevPosts.map((post) =>
          post.id === postId
            ? {
                ...post,
                liked: !post.liked,
                likes: post.liked ? post.likes - 1 : post.likes + 1,
              }
            : post,
        ),
      )

      toast({
        title: isLiked ? "Убрано из понравившихся" : "Добавлено в понравившиеся",
        description: isLiked ? "Пост убран из списка понравившихся" : "Пост добавлен в список понравившихся",
      })
    } catch (error) {
      console.error("Ошибка при обновлении лайка:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось обновить лайк",
        variant: "destructive",
      })
    }
  }

  const handleToggleComments = (postId: string) => {
    setExpandedComments((prev) => (prev.includes(postId) ? prev.filter((id) => id !== postId) : [...prev, postId]))
  }

  const handleAddComment = async (postId: string, content: string) => {
    if (!user) {
      toast({
        title: "Требуется авторизация",
        description: "Пожалуйста, войдите в систему, чтобы оставлять комментарии",
        variant: "destructive",
      })
      return
    }

    try {
      const { data: newComment, error } = await supabase
        .from("comments")
        .insert({
          post_id: postId,
          user_id: user.id,
          content,
        })
        .select(`
          *,
          user:profiles(id, username, name, avatar_url)
        `)
        .single()

      if (error) throw error

      if (newComment) {
        // Добавляем комментарий в наш локальный state
        setComments((prev) => ({
          ...prev,
          [postId]: [
            ...(prev[postId] || []),
            {
              id: newComment.id,
              content: newComment.content,
              timestamp: newComment.created_at,
              likes: 0,
              user: {
                id: newComment.user.id,
                name: newComment.user.name || newComment.user.username,
                username: newComment.user.username,
                avatar: newComment.user.avatar_url,
                followers: 0,
                following: 0,
              },
              liked: false,
            },
          ],
        }))

        // Обновляем счетчик комментариев в посте
        setPosts((prevPosts) =>
          prevPosts.map((post) => (post.id === postId ? { ...post, comments: post.comments + 1 } : post)),
        )

        toast({
          title: "Комментарий добавлен",
          description: "Ваш комментарий успешно добавлен к посту",
        })
      }
    } catch (error) {
      console.error("Ошибка при добавлении комментария:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось добавить комментарий",
        variant: "destructive",
      })
    }
  }

  const handleLikeComment = async (commentId: string) => {
    if (!user) {
      toast({
        title: "Требуется авторизация",
        description: "Пожалуйста, войдите в систему, чтобы ставить лайки",
        variant: "destructive",
      })
      return
    }

    // Находим комментарий
    let targetComment: Comment | null = null
    let targetPostId: string | null = null

    for (const postId in comments) {
      const foundComment = comments[postId].find((c) => c.id === commentId)
      if (foundComment) {
        targetComment = foundComment
        targetPostId = postId
        break
      }
    }

    if (!targetComment || !targetPostId) return

    try {
      if (targetComment.liked) {
        // Удаляем лайк
        await supabase.from("comment_likes").delete().match({ user_id: user.id, comment_id: commentId })
      } else {
        // Добавляем лайк
        await supabase.from("comment_likes").insert({ user_id: user.id, comment_id: commentId })
      }

      // Обновляем UI оптимистично
      setComments((prev) => {
        const newComments = { ...prev }

        for (const postId in newComments) {
          newComments[postId] = newComments[postId].map((comment) =>
            comment.id === commentId
              ? {
                  ...comment,
                  liked: !comment.liked,
                  likes: comment.liked ? comment.likes - 1 : comment.likes + 1,
                }
              : comment,
          )
        }

        return newComments
      })
    } catch (error) {
      console.error("Ошибка при обновлении лайка комментария:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось обновить лайк комментария",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4 pb-4 animate-fade-in">
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white rounded-xl p-4 shadow-sm">
              <div className="flex items-center space-x-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-gray-200 animate-pulse"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded w-1/3 mb-2 animate-pulse"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4 animate-pulse"></div>
                </div>
              </div>
              <div className="h-4 bg-gray-200 rounded w-full mb-2 animate-pulse"></div>
              <div className="h-4 bg-gray-200 rounded w-2/3 mb-4 animate-pulse"></div>
              <div className="h-40 bg-gray-200 rounded w-full mb-4 animate-pulse"></div>
              <div className="flex justify-between">
                <div className="h-6 bg-gray-200 rounded w-1/6 animate-pulse"></div>
                <div className="h-6 bg-gray-200 rounded w-1/6 animate-pulse"></div>
              </div>
            </div>
          ))}
        </div>
      ) : posts.length > 0 ? (
        posts.map((post) => (
          <div key={post.id}>
            <PostItem post={post} onLike={handleLike} onToggleComments={handleToggleComments} />

            {/* Comments section */}
            {expandedComments.includes(post.id) && (
              <div className="mt-2">
                <CommentSection
                  postId={post.id}
                  comments={comments[post.id] || []}
                  onAddComment={handleAddComment}
                  onLikeComment={handleLikeComment}
                />
              </div>
            )}
          </div>
        ))
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-500 mb-3">Пока нет постов</p>
          {user && <p className="text-sm">Будьте первым, кто поделится своим опытом катания!</p>}
        </div>
      )}
    </div>
  )
}
