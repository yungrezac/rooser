"use client"

import { useState, useEffect, useCallback } from "react"
import { View, FlatList, StyleSheet, RefreshControl, ActivityIndicator, Text } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { useNavigation } from "@react-navigation/native"
import { supabase } from "../lib/supabase"
import { useAuth } from "../contexts/AuthContext"
import { useToast } from "../contexts/ToastContext"
import PostItem from "../components/posts/PostItem"
import CommentSection from "../components/posts/CommentSection"
import SearchBar from "../components/search/SearchBar"
import NotificationCenter from "../components/notifications/NotificationCenter"
import { colors } from "../theme/colors"
import type { Post, Comment } from "../types"

const FeedScreen = () => {
  const [posts, setPosts] = useState<Post[]>([])
  const [comments, setComments] = useState<Record<string, Comment[]>>({})
  const [expandedComments, setExpandedComments] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [page, setPage] = useState(0)
  const [hasMore, setHasMore] = useState(true)
  const { user } = useAuth()
  const { showToast } = useToast()
  const navigation = useNavigation()
  const pageSize = 10

  const fetchPosts = useCallback(
    async (refresh = false) => {
      try {
        const currentPage = refresh ? 0 : page

        if (refresh) {
          setIsRefreshing(true)
        } else if (currentPage === 0) {
          setIsLoading(true)
        }

        const { data: postsData, error } = await supabase
          .from("posts")
          .select(`
          *,
          user:profiles(id, username, name, avatar_url),
          images:post_images(image_url)
        `)
          .order("created_at", { ascending: false })
          .range(currentPage * pageSize, (currentPage + 1) * pageSize - 1)

        if (error) throw error

        if (postsData) {
          const formattedPosts = postsData.map((post: any) => ({
            id: post.id,
            content: post.content,
            timestamp: post.created_at,
            likes: post.likes || 0,
            comments: post.comments || 0,
            user: {
              id: post.user.id,
              name: post.user.name || post.user.username,
              username: post.user.username,
              avatar: post.user.avatar_url,
              followers: 0,
              following: 0,
            },
            images: post.images?.map((img: any) => img.image_url) || [],
            liked: false, // Будет обновлено при загрузке лайков
          }))

          if (refresh) {
            setPosts(formattedPosts)
            setPage(1)
          } else {
            setPosts((prev) => [...prev, ...formattedPosts])
            setPage(currentPage + 1)
          }

          setHasMore(postsData.length === pageSize)

          // Загружаем комментарии для всех постов
          const postIds = postsData.map((post: any) => post.id)
          if (postIds.length > 0) {
            fetchComments(postIds)
          }

          // Проверяем лайки пользователя если он авторизован
          if (user && postIds.length > 0) {
            checkUserLikes(postIds)
          }
        }
      } catch (error: any) {
        console.error("Ошибка при загрузке постов:", error)
        showToast({
          type: "error",
          message: "Не удалось загрузить посты",
        })
      } finally {
        setIsLoading(false)
        setIsRefreshing(false)
      }
    },
    [page, user, showToast],
  )

  const fetchComments = async (postIds: string[]) => {
    try {
      const { data: commentsData, error } = await supabase
        .from("comments")
        .select(`
          *,
          user:profiles(id, username, name, avatar_url)
        `)
        .in("post_id", postIds)
        .order("created_at", { ascending: true })

      if (error) throw error

      if (commentsData) {
        const commentsByPost: Record<string, Comment[]> = {}

        commentsData.forEach((comment: any) => {
          if (!commentsByPost[comment.post_id]) {
            commentsByPost[comment.post_id] = []
          }
          commentsByPost[comment.post_id].push({
            id: comment.id,
            postId: comment.post_id,
            content: comment.content,
            timestamp: comment.created_at,
            likes: comment.likes || 0,
            user: {
              id: comment.user.id,
              name: comment.user.name || comment.user.username,
              username: comment.user.username,
              avatar: comment.user.avatar_url,
              followers: 0,
              following: 0,
            },
            liked: false, // Будет обновлено при загрузке лайков комментариев
          })
        })

        setComments((prev) => ({ ...prev, ...commentsByPost }))

        // Проверяем лайки комментариев если пользователь авторизован
        if (user && commentsData.length > 0) {
          checkCommentLikes(commentsData.map((comment: any) => comment.id))
        }
      }
    } catch (error) {
      console.error("Ошибка при загрузке комментариев:", error)
    }
  }

  const checkUserLikes = async (postIds: string[]) => {
    if (!user || postIds.length === 0) return

    try {
      const { data: likesData, error } = await supabase
        .from("post_likes")
        .select("post_id")
        .eq("user_id", user.id)
        .in("post_id", postIds)

      if (error) throw error

      if (likesData) {
        const likedPostIds = new Set(likesData.map((like: any) => like.post_id))

        setPosts((prevPosts) =>
          prevPosts.map((post) => ({
            ...post,
            liked: likedPostIds.has(post.id),
          })),
        )
      }
    } catch (error) {
      console.error("Ошибка при проверке лайков:", error)
    }
  }

  const checkCommentLikes = async (commentIds: string[]) => {
    if (!user || commentIds.length === 0) return

    try {
      const { data: likesData, error } = await supabase
        .from("comment_likes")
        .select("comment_id")
        .eq("user_id", user.id)
        .in("comment_id", commentIds)

      if (error) throw error

      if (likesData) {
        const likedCommentIds = new Set(likesData.map((like: any) => like.comment_id))

        setComments((prevComments) => {
          const newComments = { ...prevComments }

          for (const postId in newComments) {
            newComments[postId] = newComments[postId].map((comment) => ({
              ...comment,
              liked: likedCommentIds.has(comment.id),
            }))
          }

          return newComments
        })
      }
    } catch (error) {
      console.error("Ошибка при проверке лайков комментариев:", error)
    }
  }

  useEffect(() => {
    fetchPosts()

    // Set up realtime subscriptions
    const postsSubscription = supabase
      .channel("public:posts")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "posts",
        },
        (payload) => {
          console.log("Изменение в постах:", payload)
          // Handle realtime updates
          if (payload.eventType === "INSERT") {
            fetchPosts(true)
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(postsSubscription)
    }
  }, [fetchPosts])

  const handleRefresh = () => {
    fetchPosts(true)
  }

  const handleLoadMore = () => {
    if (!isLoading && hasMore) {
      fetchPosts()
    }
  }

  const handleLike = async (postId: string) => {
    if (!user) {
      showToast({
        type: "error",
        message: "Пожалуйста, войдите в систему, чтобы ставить лайки",
      })
      return
    }

    const isLiked = posts.find((p) => p.id === postId)?.liked

    try {
      if (isLiked) {
        // Удаляем лайк
        await supabase.from("post_likes").delete().match({ user_id: user.id, post_id: postId })
      } else {
        // Добавляем лайк
        await supabase.from("post_likes").insert({ user_id: user.id, post_id: postId })
      }

      // Обновляем UI оптимистично
      setPosts((prevPosts) =>
        prevPosts.map((post) =>
          post.id === postId
            ? {
                ...post,
                liked: !post.liked,
                likes: post.liked ? post.likes - 1 : post.likes + 1,
              }
            : post,
        ),
      )

      showToast({
        type: "success",
        message: isLiked ? "Пост убран из списка понравившихся" : "Пост добавлен в список понравившихся",
      })
    } catch (error) {
      console.error("Ошибка при обновлении лайка:", error)
      showToast({
        type: "error",
        message: "Не удалось обновить лайк",
      })
    }
  }

  const handleToggleComments = (postId: string) => {
    setExpandedComments((prev) => (prev.includes(postId) ? prev.filter((id) => id !== postId) : [...prev, postId]))
  }

  const handleAddComment = async (postId: string, content: string) => {
    if (!user) {
      showToast({
        type: "error",
        message: "Пожалуйста, войдите в систему, чтобы оставлять комментарии",
      })
      return
    }

    try {
      const { data: newComment, error } = await supabase
        .from("comments")
        .insert({
          post_id: postId,
          user_id: user.id,
          content,
        })
        .select(`
          *,
          user:profiles(id, username, name, avatar_url)
        `)
        .single()

      if (error) throw error

      if (newComment) {
        // Добавляем комментарий в наш локальный state
        setComments((prev) => ({
          ...prev,
          [postId]: [
            ...(prev[postId] || []),
            {
              id: newComment.id,
              postId: newComment.post_id,
              content: newComment.content,
              timestamp: newComment.created_at,
              likes: 0,
              user: {
                id: newComment.user.id,
                name: newComment.user.name || newComment.user.username,
                username: newComment.user.username,
                avatar: newComment.user.avatar_url,
                followers: 0,
                following: 0,
              },
              liked: false,
            },
          ],
        }))

        // Обновляем счетчик комментариев в посте
        setPosts((prevPosts) =>
          prevPosts.map((post) => (post.id === postId ? { ...post, comments: post.comments + 1 } : post)),
        )

        showToast({
          type: "success",
          message: "Комментарий успешно добавлен",
        })
      }
    } catch (error) {
      console.error("Ошибка при добавлении комментария:", error)
      showToast({
        type: "error",
        message: "Не удалось добавить комментарий",
      })
    }
  }

  const handleLikeComment = async (commentId: string) => {
    if (!user) {
      showToast({
        type: "error",
        message: "Пожалуйста, войдите в систему, чтобы ставить лайки",
      })
      return
    }

    // Находим комментарий
    let targetComment: Comment | null = null
    let targetPostId: string | null = null

    for (const postId in comments) {
      const foundComment = comments[postId].find((c) => c.id === commentId)
      if (foundComment) {
        targetComment = foundComment
        targetPostId = postId
        break
      }
    }

    if (!targetComment || !targetPostId) return

    try {
      if (targetComment.liked) {
        // Удаляем лайк
        await supabase.from("comment_likes").delete().match({ user_id: user.id, comment_id: commentId })
      } else {
        // Добавляем лайк
        await supabase.from("comment_likes").insert({ user_id: user.id, comment_id: commentId })
      }

      // Обновляем UI оптимистично
      setComments((prev) => {
        const newComments = { ...prev }

        for (const postId in newComments) {
          newComments[postId] = newComments[postId].map((comment) =>
            comment.id === commentId
              ? {
                  ...comment,
                  liked: !comment.liked,
                  likes: comment.liked ? comment.likes - 1 : comment.likes + 1,
                }
              : comment,
          )
        }

        return newComments
      })
    } catch (error) {
      console.error("Ошибка при обновлении лайка комментария:", error)
      showToast({
        type: "error",
        message: "Не удалось обновить лайк комментария",
      })
    }
  }

  const renderItem = ({ item }: { item: Post }) => (
    <View style={styles.postContainer}>
      <PostItem
        post={item}
        onLike={handleLike}
        onToggleComments={handleToggleComments}
        onPress={() => navigation.navigate("PostDetail", { postId: item.id })}
      />

      {expandedComments.includes(item.id) && (
        <CommentSection
          postId={item.id}
          comments={comments[item.id] || []}
          onAddComment={handleAddComment}
          onLikeComment={handleLikeComment}
        />
      )}
    </View>
  )

  const renderFooter = () => {
    if (!isLoading || isRefreshing) return null
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="small" color={colors.primary} />
      </View>
    )
  }

  const renderEmpty = () => {
    if (isLoading) return null
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>Пока нет постов</Text>
        {user && <Text style={styles.emptySubtext}>Будьте первым, кто поделится своим опытом катания!</Text>}
      </View>
    )
  }

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>RollrSocial</Text>
        <View style={styles.headerRight}>
          <SearchBar />
          <NotificationCenter />
        </View>
      </View>

      <FlatList
        data={posts}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            colors={[colors.primary]}
            tintColor={colors.primary}
          />
        }
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.5}
        ListFooterComponent={renderFooter}
        ListEmptyComponent={renderEmpty}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.gray[50],
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.gray[200],
  },
  headerTitle: {
    fontSize: 20,
    fontFamily: "Inter-Bold",
    color: colors.primary,
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
  },
  listContent: {
    paddingBottom: 20,
  },
  postContainer: {
    marginBottom: 8,
  },
  loaderContainer: {
    paddingVertical: 20,
    alignItems: "center",
  },
  emptyContainer: {
    padding: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyText: {
    fontSize: 16,
    fontFamily: "Inter-Medium",
    color: colors.gray[500],
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    fontFamily: "Inter-Regular",
    color: colors.gray[400],
    textAlign: "center",
  },
})

export default FeedScreen
