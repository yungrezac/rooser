"use client"

import { useState } from "react"
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { StatusBar } from "expo-status-bar"
import LoginForm from "../components/auth/LoginForm"
import RegisterForm from "../components/auth/RegisterForm"
import { colors } from "../theme/colors"

const AuthScreen = () => {
  const [activeTab, setActiveTab] = useState<"login" | "register">("login")
  const [error, setError] = useState<string | null>(null)

  const handleTabChange = (tab: "login" | "register") => {
    setActiveTab(tab)
    setError(null)
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
          <View style={styles.logoContainer}>
            <Image source={require("../../assets/logo.png")} style={styles.logo} resizeMode="contain" />
            <Text style={styles.appName}>RollrSocial</Text>
            <Text style={styles.tagline}>Сообщество роллеров и скейтеров</Text>
          </View>

          <View style={styles.tabContainer}>
            <TouchableOpacity
              style={[styles.tab, activeTab === "login" && styles.activeTab]}
              onPress={() => handleTabChange("login")}
            >
              <Text style={[styles.tabText, activeTab === "login" && styles.activeTabText]}>Вход</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.tab, activeTab === "register" && styles.activeTab]}
              onPress={() => handleTabChange("register")}
            >
              <Text style={[styles.tabText, activeTab === "register" && styles.activeTabText]}>Регистрация</Text>
            </TouchableOpacity>
          </View>

          {error && (
            <View style={styles.errorContainer}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          <View style={styles.formContainer}>
            {activeTab === "login" ? <LoginForm onError={setError} /> : <RegisterForm onError={setError} />}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  scrollContent: {
    flexGrow: 1,
    padding: 20,
  },
  logoContainer: {
    alignItems: "center",
    marginTop: 20,
    marginBottom: 40,
  },
  logo: {
    width: 80,
    height: 80,
    marginBottom: 16,
  },
  appName: {
    fontSize: 28,
    fontFamily: "Inter-Bold",
    color: colors.primary,
    marginBottom: 8,
  },
  tagline: {
    fontSize: 16,
    fontFamily: "Inter-Regular",
    color: colors.gray[600],
    textAlign: "center",
  },
  tabContainer: {
    flexDirection: "row",
    marginBottom: 24,
    borderRadius: 8,
    backgroundColor: colors.gray[100],
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: "center",
    borderRadius: 6,
  },
  activeTab: {
    backgroundColor: colors.white,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  tabText: {
    fontSize: 16,
    fontFamily: "Inter-Medium",
    color: colors.gray[500],
  },
  activeTabText: {
    color: colors.primary,
  },
  errorContainer: {
    backgroundColor: colors.error,
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  errorText: {
    color: colors.white,
    fontSize: 14,
    fontFamily: "Inter-Medium",
  },
  formContainer: {
    flex: 1,
  },
})

export default AuthScreen
