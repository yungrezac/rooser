import { supabase } from "../integrations/supabase/client"
import { JWT_SECRET } from "../integrations/supabase/client"
import jwt from "jsonwebtoken"

// Типы для аутентификации
export interface AuthUser {
  id: string
  email: string
  username?: string
}

export interface AuthResponse {
  user: AuthUser | null
  session: any | null
  error: Error | null
}

// Функция для входа с email и паролем
export const signInWithEmail = async (email: string, password: string): Promise<AuthResponse> => {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) throw error

    return {
      user: data.user
        ? {
            id: data.user.id,
            email: data.user.email || "",
            username: data.user.user_metadata?.username,
          }
        : null,
      session: data.session,
      error: null,
    }
  } catch (error) {
    console.error("Error signing in:", error)
    return {
      user: null,
      session: null,
      error: error as Error,
    }
  }
}

// Функция для регистрации с email и паролем
export const signUpWithEmail = async (email: string, password: string, username: string): Promise<AuthResponse> => {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username,
        },
      },
    })

    if (error) throw error

    // Создаем запись в таблице профилей
    if (data.user) {
      const { error: profileError } = await supabase.from("profiles").insert([
        {
          id: data.user.id,
          username,
          email,
          created_at: new Date(),
        },
      ])

      if (profileError) throw profileError
    }

    return {
      user: data.user
        ? {
            id: data.user.id,
            email: data.user.email || "",
            username,
          }
        : null,
      session: data.session,
      error: null,
    }
  } catch (error) {
    console.error("Error signing up:", error)
    return {
      user: null,
      session: null,
      error: error as Error,
    }
  }
}

// Функция для выхода
export const signOut = async (): Promise<{ error: Error | null }> => {
  try {
    const { error } = await supabase.auth.signOut()
    if (error) throw error
    return { error: null }
  } catch (error) {
    console.error("Error signing out:", error)
    return { error: error as Error }
  }
}

// Функция для получения текущего пользователя
export const getCurrentUser = async (): Promise<AuthResponse> => {
  try {
    const { data, error } = await supabase.auth.getUser()
    if (error) throw error

    return {
      user: data.user
        ? {
            id: data.user.id,
            email: data.user.email || "",
            username: data.user.user_metadata?.username,
          }
        : null,
      session: null, // Сессия получается отдельно
      error: null,
    }
  } catch (error) {
    console.error("Error getting current user:", error)
    return {
      user: null,
      session: null,
      error: error as Error,
    }
  }
}

// Функция для получения текущей сессии
export const getSession = async () => {
  try {
    const { data, error } = await supabase.auth.getSession()
    if (error) throw error
    return { session: data.session, error: null }
  } catch (error) {
    console.error("Error getting session:", error)
    return { session: null, error: error as Error }
  }
}

// Функция для создания JWT токена
export const createJWT = (userId: string, expiresIn = "7d") => {
  const secret = JWT_SECRET
  if (!secret) {
    throw new Error("JWT_SECRET is not defined")
  }

  return jwt.sign({ sub: userId }, secret, { expiresIn })
}

// Функция для проверки JWT токена
export const verifyJWT = (token: string) => {
  const secret = JWT_SECRET
  if (!secret) {
    throw new Error("JWT_SECRET is not defined")
  }

  try {
    return jwt.verify(token, secret)
  } catch (error) {
    console.error("Error verifying JWT:", error)
    return null
  }
}
