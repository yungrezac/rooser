import { supabase } from "@/integrations/supabase/client"
import type { Achievement } from "@/types"

// Функция для проверки и обновления достижений пользователя
export async function updateUserAchievements(userId: string) {
  try {
    // Получаем все достижения из базы данных
    const { data: achievements, error: achievementsError } = await supabase.from("achievements").select("*")

    if (achievementsError) throw achievementsError

    // Получаем статистику пользователя
    const { data: activities, error: activitiesError } = await supabase
      .from("activities")
      .select("distance")
      .eq("user_id", userId)

    if (activitiesError) throw activitiesError

    // Получаем количество подписчиков
    const { data: followers, error: followersError } = await supabase
      .from("follows")
      .select("*")
      .eq("following_id", userId)

    if (followersError) throw followersError

    // Получаем количество посещенных мест
    const { data: visitedLocations, error: locationsError } = await supabase
      .from("location_reviews")
      .select("location_id")
      .eq("user_id", userId)
      .distinct()

    if (locationsError) throw locationsError

    // Рассчитываем статистику
    const totalDistance = activities.reduce((sum, activity) => sum + activity.distance, 0)
    const totalActivities = activities.length
    const followersCount = followers.length
    const locationsCount = visitedLocations.length

    // Проверяем каждое достижение и обновляем прогресс
    for (const achievement of achievements) {
      let progress = 0
      let unlocked = false

      switch (achievement.id) {
        case "distance-10":
          progress = Math.min(totalDistance, 10)
          unlocked = totalDistance >= 10
          break
        case "distance-50":
          progress = Math.min(totalDistance, 50)
          unlocked = totalDistance >= 50
          break
        case "distance-100":
          progress = Math.min(totalDistance, 100)
          unlocked = totalDistance >= 100
          break
        case "activities-5":
          progress = Math.min(totalActivities, 5)
          unlocked = totalActivities >= 5
          break
        case "activities-20":
          progress = Math.min(totalActivities, 20)
          unlocked = totalActivities >= 20
          break
        case "followers-10":
          progress = Math.min(followersCount, 10)
          unlocked = followersCount >= 10
          break
        case "locations-5":
          progress = Math.min(locationsCount, 5)
          unlocked = locationsCount >= 5
          break
        default:
          continue
      }

      // Проверяем, существует ли уже запись о достижении пользователя
      const { data: existingAchievement, error: existingError } = await supabase
        .from("user_achievements")
        .select("*")
        .eq("user_id", userId)
        .eq("achievement_id", achievement.id)
        .single()

      if (existingError && existingError.code !== "PGRST116") {
        // PGRST116 - запись не найдена, это нормально
        throw existingError
      }

      if (existingAchievement) {
        // Обновляем существующее достижение
        await supabase
          .from("user_achievements")
          .update({
            progress,
            unlocked,
            updated_at: new Date().toISOString(),
          })
          .eq("id", existingAchievement.id)
      } else {
        // Создаем новую запись о достижении
        await supabase.from("user_achievements").insert({
          user_id: userId,
          achievement_id: achievement.id,
          progress,
          max_progress: achievement.max_progress || progress,
          unlocked,
        })
      }
    }

    return { success: true }
  } catch (error) {
    console.error("Ошибка при обновлении достижений:", error)
    return { success: false, error }
  }
}

// Функция для получения достижений пользователя
export async function getUserAchievements(userId: string): Promise<Achievement[]> {
  try {
    const { data, error } = await supabase
      .from("user_achievements")
      .select(`
        *,
        achievement:achievements(*)
      `)
      .eq("user_id", userId)

    if (error) throw error

    return data.map((item) => ({
      id: item.achievement.id,
      title: item.achievement.title,
      description: item.achievement.description,
      icon: item.achievement.icon,
      progress: item.progress,
      maxProgress: item.max_progress,
      unlocked: item.unlocked,
    }))
  } catch (error) {
    console.error("Ошибка при получении достижений:", error)
    return []
  }
}

// Функция для проверки достижений (используется для демо-данных)
export function checkAchievements(
  totalDistance: number,
  totalActivities: number,
  followersCount: number,
  locationsCount: number,
): Achievement[] {
  const achievements: Achievement[] = [
    {
      id: "distance-10",
      title: "Первые 10 км",
      description: "Пройдите 10 километров на роликах",
      icon: "🛼",
      progress: Math.min(totalDistance, 10),
      maxProgress: 10,
      unlocked: totalDistance >= 10,
    },
    {
      id: "distance-50",
      title: "Путешественник",
      description: "Пройдите 50 километров на роликах",
      icon: "🗺️",
      progress: Math.min(totalDistance, 50),
      maxProgress: 50,
      unlocked: totalDistance >= 50,
    },
    {
      id: "distance-100",
      title: "Марафонец",
      description: "Пройдите 100 километров на роликах",
      icon: "🏆",
      progress: Math.min(totalDistance, 100),
      maxProgress: 100,
      unlocked: totalDistance >= 100,
    },
    {
      id: "activities-5",
      title: "Регулярные тренировки",
      description: "Совершите 5 активностей",
      icon: "📅",
      progress: Math.min(totalActivities, 5),
      maxProgress: 5,
      unlocked: totalActivities >= 5,
    },
    {
      id: "activities-20",
      title: "Постоянство",
      description: "Совершите 20 активностей",
      icon: "⏱️",
      progress: Math.min(totalActivities, 20),
      maxProgress: 20,
      unlocked: totalActivities >= 20,
    },
    {
      id: "followers-10",
      title: "Популярность",
      description: "Наберите 10 подписчиков",
      icon: "👥",
      progress: Math.min(followersCount, 10),
      maxProgress: 10,
      unlocked: followersCount >= 10,
    },
    {
      id: "locations-5",
      title: "Исследователь",
      description: "Посетите 5 разных мест для катания",
      icon: "🔍",
      progress: Math.min(locationsCount, 5),
      maxProgress: 5,
      unlocked: locationsCount >= 5,
    },
  ]

  return achievements
}
