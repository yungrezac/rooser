"use client"

import { useState } from "react"
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Modal } from "react-native"
import { Bell } from "react-native-feather"
import { colors } from "../../theme/colors"

// Временные данные для демонстрации
const demoNotifications = [
  {
    id: "1",
    type: "like",
    content: "Алексей оценил ваш пост",
    timestamp: "2023-05-01T10:30:00Z",
    read: false,
  },
  {
    id: "2",
    type: "comment",
    content: "Мария прокомментировала ваш пост",
    timestamp: "2023-05-01T09:15:00Z",
    read: true,
  },
  {
    id: "3",
    type: "follow",
    content: "Иван подписался на вас",
    timestamp: "2023-04-30T18:45:00Z",
    read: false,
  },
]

const NotificationCenter = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [notifications, setNotifications] = useState(demoNotifications)

  const unreadCount = notifications.filter((n) => !n.read).length

  const handleOpen = () => {
    setIsOpen(true)
  }

  const handleClose = () => {
    setIsOpen(false)
    // Отмечаем все уведомления как прочитанные
    setNotifications(notifications.map((n) => ({ ...n, read: true })))
  }

  const renderNotification = ({ item }: { item: any }) => (
    <View style={[styles.notificationItem, !item.read && styles.unreadNotification]}>
      <Text style={styles.notificationContent}>{item.content}</Text>
      <Text style={styles.notificationTime}>{new Date(item.timestamp).toLocaleDateString()}</Text>
    </View>
  )

  return (
    <>
      <TouchableOpacity style={styles.iconContainer} onPress={handleOpen}>
        <Bell width={24} height={24} color={colors.gray[700]} />
        {unreadCount > 0 && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{unreadCount}</Text>
          </View>
        )}
      </TouchableOpacity>

      <Modal visible={isOpen} transparent animationType="fade">
        <TouchableOpacity style={styles.modalOverlay} onPress={handleClose} activeOpacity={1}>
          <View style={styles.modalContent} onClick={(e) => e.stopPropagation()}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Уведомления</Text>
              <TouchableOpacity onPress={handleClose}>
                <Text style={styles.closeButton}>Закрыть</Text>
              </TouchableOpacity>
            </View>

            {notifications.length > 0 ? (
              <FlatList
                data={notifications}
                renderItem={renderNotification}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.notificationsList}
              />
            ) : (
              <View style={styles.emptyContainer}>
                <Text style={styles.emptyText}>У вас нет уведомлений</Text>
              </View>
            )}
          </View>
        </TouchableOpacity>
      </Modal>
    </>
  )
}

const styles = StyleSheet.create({
  iconContainer: {
    position: "relative",
    padding: 8,
    marginLeft: 8,
  },
  badge: {
    position: "absolute",
    top: 4,
    right: 4,
    backgroundColor: colors.error,
    borderRadius: 10,
    minWidth: 16,
    height: 16,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 4,
  },
  badgeText: {
    color: colors.white,
    fontSize: 10,
    fontWeight: "600",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    backgroundColor: colors.white,
    borderRadius: 12,
    width: "90%",
    maxWidth: 400,
    maxHeight: "80%",
    overflow: "hidden",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.gray[200],
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: colors.gray[900],
  },
  closeButton: {
    color: colors.primary,
    fontSize: 16,
  },
  notificationsList: {
    padding: 8,
  },
  notificationItem: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.gray[200],
  },
  unreadNotification: {
    backgroundColor: colors.gray[50],
  },
  notificationContent: {
    fontSize: 14,
    color: colors.gray[900],
    marginBottom: 4,
  },
  notificationTime: {
    fontSize: 12,
    color: colors.gray[500],
  },
  emptyContainer: {
    padding: 24,
    alignItems: "center",
  },
  emptyText: {
    color: colors.gray[500],
    fontSize: 16,
  },
})

export default NotificationCenter
