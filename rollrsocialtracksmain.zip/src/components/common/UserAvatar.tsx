import type React from "react"
import { Image, StyleSheet, View, Text } from "react-native"
import { colors } from "../../theme/colors"
import type { User } from "../../types"

interface UserAvatarProps {
  user: User
  size?: number
  showStatus?: boolean
  status?: "online" | "offline" | "away"
}

const UserAvatar: React.FC<UserAvatarProps> = ({ user, size = 40, showStatus = false, status = "offline" }) => {
  const getInitials = () => {
    if (!user.name) return "?"

    const nameParts = user.name.split(" ")
    if (nameParts.length === 1) {
      return nameParts[0].charAt(0).toUpperCase()
    }

    return (nameParts[0].charAt(0) + nameParts[1].charAt(0)).toUpperCase()
  }

  const getStatusColor = () => {
    switch (status) {
      case "online":
        return colors.success
      case "away":
        return colors.warning
      default:
        return colors.gray[400]
    }
  }

  return (
    <View style={{ position: "relative" }}>
      {user.avatar ? (
        <Image
          source={{ uri: user.avatar }}
          style={[
            styles.avatar,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
            },
          ]}
        />
      ) : (
        <View
          style={[
            styles.placeholderAvatar,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
              backgroundColor: colors.gray[300],
            },
          ]}
        >
          <Text
            style={[
              styles.placeholderText,
              {
                fontSize: size * 0.4,
              },
            ]}
          >
            {getInitials()}
          </Text>
        </View>
      )}

      {showStatus && (
        <View
          style={[
            styles.statusIndicator,
            {
              backgroundColor: getStatusColor(),
              right: 0,
              bottom: 0,
              width: size * 0.3,
              height: size * 0.3,
              borderWidth: size * 0.05,
            },
          ]}
        />
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  avatar: {
    backgroundColor: colors.gray[200],
  },
  placeholderAvatar: {
    justifyContent: "center",
    alignItems: "center",
  },
  placeholderText: {
    color: colors.white,
    fontWeight: "600",
  },
  statusIndicator: {
    position: "absolute",
    borderRadius: 50,
    borderColor: colors.white,
  },
})

export default UserAvatar
