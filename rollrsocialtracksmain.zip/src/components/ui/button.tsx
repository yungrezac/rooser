"use client"

import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"
import { useIsMobile } from "@/hooks/use-mobile"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 active:scale-[0.98]",
  {
    variants: {
      variant: {
        default: "bg-black text-white hover:bg-black/90 shadow-sm",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-sm",
        outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-gray-200 text-gray-800 hover:bg-gray-300 shadow-sm",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-black underline-offset-4 hover:underline",
        subtle: "bg-gray-50 text-gray-700 hover:bg-gray-100",
        gradient: "bg-black text-white hover:opacity-90 shadow-sm",
      },
      size: {
        default: "h-10 px-5 py-2 [&_svg]:size-4",
        sm: "h-8 rounded-full px-3 py-1.5 text-xs [&_svg]:size-3.5",
        lg: "h-11 rounded-full px-8 text-base [&_svg]:size-5",
        icon: "h-9 w-9 rounded-full [&_svg]:size-4",
        mobile: "h-9 px-4 py-1.5 text-xs [&_svg]:size-3.5",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const isMobile = useIsMobile()
    // Use mobile size on mobile devices if not explicitly specified
    const adaptiveSize = isMobile && !size ? "mobile" : size

    const Comp = asChild ? Slot : "button"
    return <Comp className={cn(buttonVariants({ variant, size: adaptiveSize, className }))} ref={ref} {...props} />
  },
)
Button.displayName = "Button"

export { Button, buttonVariants }
