"use client"

import { useEffect } from "react"
import { View, Text, StyleSheet, Animated, TouchableOpacity, Platform } from "react-native"
import { CheckCircle, AlertCircle, Info, AlertTriangle, X } from "react-native-feather"
import { useToast } from "../../contexts/ToastContext"
import { colors } from "../../theme/colors"

const Toast = () => {
  const { toast, hideToast } = useToast()
  const translateY = new Animated.Value(-100)

  useEffect(() => {
    if (toast) {
      // Animate in
      Animated.spring(translateY, {
        toValue: 0,
        useNativeDriver: true,
        tension: 80,
        friction: 10,
      }).start()
    } else {
      // Animate out
      Animated.timing(translateY, {
        toValue: -100,
        duration: 300,
        useNativeDriver: true,
      }).start()
    }
  }, [toast])

  if (!toast) return null

  const getIcon = () => {
    switch (toast.type) {
      case "success":
        return <CheckCircle width={20} height={20} color={colors.white} />
      case "error":
        return <AlertCircle width={20} height={20} color={colors.white} />
      case "info":
        return <Info width={20} height={20} color={colors.white} />
      case "warning":
        return <AlertTriangle width={20} height={20} color={colors.white} />
      default:
        return null
    }
  }

  const getBackgroundColor = () => {
    switch (toast.type) {
      case "success":
        return colors.success
      case "error":
        return colors.error
      case "info":
        return colors.info
      case "warning":
        return colors.warning
      default:
        return colors.gray[800]
    }
  }

  return (
    <Animated.View
      style={[
        styles.container,
        {
          backgroundColor: getBackgroundColor(),
          transform: [{ translateY }],
        },
      ]}
    >
      <View style={styles.content}>
        <View style={styles.iconContainer}>{getIcon()}</View>
        <Text style={styles.message}>{toast.message}</Text>
      </View>
      <TouchableOpacity onPress={hideToast} style={styles.closeButton}>
        <X width={16} height={16} color={colors.white} />
      </TouchableOpacity>
    </Animated.View>
  )
}

const styles = StyleSheet.create({
  container: {
    position: Platform.OS === "web" ? "fixed" : "absolute",
    top: 20,
    left: 16,
    right: 16,
    padding: 16,
    borderRadius: 8,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    zIndex: 1000,
  },
  content: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  iconContainer: {
    marginRight: 12,
  },
  message: {
    color: colors.white,
    fontSize: 14,
    fontWeight: "500",
    flex: 1,
  },
  closeButton: {
    padding: 4,
  },
})

export default Toast
