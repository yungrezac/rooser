"use client"
import type { Activity } from "@/types"
import { formatDate } from "@/lib/date"
import { MapPin, Route as RouteIcon, TrendingUp, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface ActivityDetailProps {
  activity: Activity
  onShareActivity?: (activity: Activity) => void
}

export default function ActivityDetail({ activity, onShareActivity }: ActivityDetailProps) {
  const formattedDuration = () => {
    const hours = Math.floor(activity.duration / 60)
    const mins = activity.duration % 60
    return `${hours > 0 ? `${hours} ч ` : ""}${mins} мин`
  }

  return (
    <div className="space-y-4 animate-fade-in">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold">{activity.type === "skating" ? "Катание" : "Ролики"}</h2>
          <p className="text-sm text-gray-500">{formatDate(activity.timestamp)}</p>
        </div>

        <Badge
          variant="outline"
          className={
            activity.type === "skating" ? "border-rllr-blue text-rllr-blue" : "border-rllr-purple text-rllr-purple"
          }
        >
          {activity.type === "skating" ? "Катание" : "Ролики"}
        </Badge>
      </header>

      <div className="grid grid-cols-3 gap-3">
        <div className="bg-gray-50 p-3 rounded-lg text-center">
          <div className="flex justify-center mb-1">
            <RouteIcon className="w-5 h-5 text-gray-500" />
          </div>
          <p className="text-sm text-gray-500">Расстояние</p>
          <p className="font-bold text-lg">{activity.distance} км</p>
        </div>

        <div className="bg-gray-50 p-3 rounded-lg text-center">
          <div className="flex justify-center mb-1">
            <Clock className="w-5 h-5 text-gray-500" />
          </div>
          <p className="text-sm text-gray-500">Время</p>
          <p className="font-bold text-lg">{formattedDuration()}</p>
        </div>

        <div className="bg-gray-50 p-3 rounded-lg text-center">
          <div className="flex justify-center mb-1">
            <TrendingUp className="w-5 h-5 text-gray-500" />
          </div>
          <p className="text-sm text-gray-500">Скорость</p>
          <p className="font-bold text-lg">{activity.avgSpeed} км/ч</p>
        </div>
      </div>

      {activity.route && (
        <div className="border border-gray-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              <MapPin className="w-5 h-5 text-rllr-purple mr-2" />
              <h3 className="font-medium">{activity.route.name}</h3>
            </div>
            <p className="text-sm text-gray-500">{activity.route.distance} км</p>
          </div>

          <div className="bg-gray-100 h-40 rounded-md flex items-center justify-center mb-2">
            <p className="text-sm text-gray-500">Карта маршрута</p>
          </div>
        </div>
      )}

      {onShareActivity && (
        <div className="flex justify-center mt-2">
          <Button variant="outline" onClick={() => onShareActivity(activity)} className="w-full">
            Поделиться активностью
          </Button>
        </div>
      )}

      <div className="text-sm text-gray-500">
        <h4 className="font-medium mb-1">Дополнительная информация</h4>
        <ul className="list-disc list-inside pl-2 space-y-1">
          <li>Подъем: {activity.elevation} м</li>
          <li>
            Время: {new Date(activity.timestamp).toLocaleTimeString("ru", { hour: "2-digit", minute: "2-digit" })}
          </li>
          {activity.route && <li>Точек маршрута: {activity.route.points.length}</li>}
        </ul>
      </div>
    </div>
  )
}
