"use client"

import type React from "react"
import { useState } from "react"
import type { Activity } from "@/types"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Share2 } from "lucide-react"
import { useNavigate } from "react-router-dom"

interface ShareActivityFormProps {
  activity: Activity
  onClose: () => void
}

export default function ShareActivityForm({ activity, onClose }: ShareActivityFormProps) {
  const [content, setContent] = useState(
    `Только что прошёл ${activity.distance} км на ${activity.type === "skating" ? "коньках" : "роликах"}! Средняя скорость: ${activity.avgSpeed} км/ч.`,
  )
  const { toast } = useToast()
  const navigate = useNavigate()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // В реальном приложении здесь был бы API-запрос для создания поста
    console.log("Публикация поста с активностью:", {
      content,
      activity,
    })

    toast({
      title: "Пост опубликован!",
      description: "Ваша активность успешно опубликована в ленте.",
    })

    // Перенаправление на главную страницу
    setTimeout(() => {
      navigate("/")
      onClose()
    }, 500)
  }

  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h2 className="text-lg font-bold mb-4">Поделиться активностью</h2>

      <div className="mb-4 p-3 bg-gray-50 rounded-lg">
        <div className="grid grid-cols-3 gap-2 mb-2">
          <div>
            <span className="text-xs text-gray-500">Расстояние</span>
            <p className="font-medium">{activity.distance} км</p>
          </div>
          <div>
            <span className="text-xs text-gray-500">Время</span>
            <p className="font-medium">
              {Math.floor(activity.duration / 60) > 0 && `${Math.floor(activity.duration / 60)} ч `}
              {activity.duration % 60} мин
            </p>
          </div>
          <div>
            <span className="text-xs text-gray-500">Скорость</span>
            <p className="font-medium">{activity.avgSpeed} км/ч</p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Напишите что-нибудь о вашей активности..."
          className="min-h-[100px]"
        />

        <div className="flex gap-2">
          <Button
            type="submit"
            className="flex-1 bg-rllr-purple hover:bg-rllr-purple/80 flex items-center justify-center gap-2"
          >
            <Share2 className="w-4 h-4" />
            Опубликовать
          </Button>

          <Button type="button" variant="outline" onClick={onClose} className="flex-1">
            Отмена
          </Button>
        </div>
      </form>
    </div>
  )
}
