"use client"

import { useState } from "react"
import { Link } from "react-router-dom"
import { Menu, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/contexts/AuthContext"
import SearchBar from "@/components/search/SearchBar"
import NotificationCenter from "@/components/notifications/NotificationCenter"

export default function TopHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { user, userProfile } = useAuth()

  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b border-gray-100">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-4">
          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[250px] sm:w-[300px]">
              <nav className="flex flex-col gap-4 mt-8">
                <Link to="/" className="text-lg font-medium" onClick={() => setIsMenuOpen(false)}>
                  Главная
                </Link>
                <Link to="/map" className="text-lg font-medium" onClick={() => setIsMenuOpen(false)}>
                  Карта
                </Link>
                <Link to="/messages" className="text-lg font-medium" onClick={() => setIsMenuOpen(false)}>
                  Сообщения
                </Link>
                <Link to="/profile" className="text-lg font-medium" onClick={() => setIsMenuOpen(false)}>
                  Профиль
                </Link>
                <Link to="/settings" className="text-lg font-medium" onClick={() => setIsMenuOpen(false)}>
                  Настройки
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
          <Link to="/" className="flex items-center gap-2">
            <span className="font-bold text-xl text-rllr-purple">Rollr</span>
          </Link>
        </div>

        <div className="hidden md:flex flex-1 justify-center max-w-md mx-4">
          <SearchBar />
        </div>

        <div className="flex items-center gap-2">
          <NotificationCenter />

          <Link to="/create">
            <Button size="icon" variant="ghost">
              <Plus className="h-5 w-5" />
            </Button>
          </Link>

          <Link to="/profile">
            <Avatar className="h-8 w-8">
              <AvatarImage src={userProfile?.avatar_url || "/placeholder.svg"} alt={userProfile?.name || "Профиль"} />
              <AvatarFallback>
                {userProfile?.name?.substring(0, 2).toUpperCase() ||
                  userProfile?.username?.substring(0, 2).toUpperCase() ||
                  "ПР"}
              </AvatarFallback>
            </Avatar>
          </Link>
        </div>
      </div>

      <div className="md:hidden px-4 pb-2">
        <SearchBar />
      </div>
    </header>
  )
}
