"use client"

import type { ReactNode } from "react"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useNavigate } from "react-router-dom"
import { Outlet } from "react-router-dom"
import { useIsMobile } from "@/hooks/use-mobile"

interface SettingsLayoutProps {
  title: string
  children?: ReactNode
}

export default function SettingsLayout({ title, children }: SettingsLayoutProps) {
  const navigate = useNavigate()
  const isMobile = useIsMobile()

  return (
    <div className="animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <Button
          variant="ghost"
          size={isMobile ? "icon" : "icon"}
          onClick={() => navigate(-1)}
          className="rounded-full hover:bg-gray-100"
        >
          <ArrowLeft className={isMobile ? "h-4 w-4" : "h-5 w-5"} />
        </Button>
        <h1 className="text-xl font-bold">{title}</h1>
      </div>

      <div className="space-y-6">{children || <Outlet />}</div>
    </div>
  )
}
