"use client"

import type React from "react"

import { View, StyleSheet } from "react-native"
import { useRouter, usePathname } from "next/navigation"
import { useAuth } from "../../contexts/AuthContext"
import BottomNav from "./BottomNav"
import Toast from "../ui/Toast"
import { colors } from "../../theme/colors"

interface AppLayoutProps {
  children: React.ReactNode
}

const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  // Если пользователь не авторизован и загрузка завершена, перенаправляем на страницу авторизации
  if (!isLoading && !user && pathname !== "/auth") {
    router.replace("/auth")
    return null
  }

  return (
    <View style={styles.container}>
      {children}
      {user && <BottomNav />}
      <Toast />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
    height: "100vh",
    position: "relative",
  },
})

export default AppLayout
