"use client"

import { View, TouchableOpacity, StyleSheet, Text } from "react-native"
import { useRouter, usePathname } from "next/navigation"
import { Home, Map, PlusSquare, MessageSquare, User } from "react-native-feather"
import { colors } from "../../theme/colors"

const BottomNav = () => {
  const router = useRouter()
  const pathname = usePathname()

  const tabs = [
    { name: "feed", label: "Лента", icon: Home, path: "/feed" },
    { name: "map", label: "Карта", icon: Map, path: "/map" },
    { name: "create", label: "Создать", icon: PlusSquare, path: "/create" },
    { name: "messages", label: "Чаты", icon: MessageSquare, path: "/messages" },
    { name: "profile", label: "Профиль", icon: User, path: "/profile" },
  ]

  return (
    <View style={styles.container}>
      {tabs.map((tab) => {
        const isActive = pathname === tab.path
        const Icon = tab.icon

        return (
          <TouchableOpacity key={tab.name} style={styles.tab} onPress={() => router.push(tab.path)}>
            <Icon width={24} height={24} color={isActive ? colors.primary : colors.gray[500]} strokeWidth={2} />
            <Text style={[styles.tabLabel, { color: isActive ? colors.primary : colors.gray[500] }]}>{tab.label}</Text>
          </TouchableOpacity>
        )
      })}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: colors.gray[200],
    paddingBottom: 8,
    paddingTop: 8,
    position: "fixed",
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  tab: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 8,
  },
  tabLabel: {
    fontSize: 12,
    marginTop: 4,
    fontWeight: "500",
  },
})

export default BottomNav
