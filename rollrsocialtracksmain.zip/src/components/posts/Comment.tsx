import type React from "react"
import { View, Text, StyleSheet, TouchableOpacity } from "react-native"
import { Heart } from "react-native-feather"
import { formatDistanceToNow } from "date-fns"
import { ru } from "date-fns/locale"
import UserAvatar from "../common/UserAvatar"
import { colors } from "../../theme/colors"
import type { Comment as CommentType } from "../../types"

interface CommentProps {
  comment: CommentType
  onLike: () => void
}

const Comment: React.FC<CommentProps> = ({ comment, onLike }) => {
  const formattedDate = formatDistanceToNow(new Date(comment.timestamp), {
    addSuffix: true,
    locale: ru,
  })

  return (
    <View style={styles.container}>
      <UserAvatar user={comment.user} size={32} />
      <View style={styles.contentContainer}>
        <View style={styles.header}>
          <Text style={styles.userName}>{comment.user.name}</Text>
          <Text style={styles.timestamp}>{formattedDate}</Text>
        </View>
        <Text style={styles.content}>{comment.content}</Text>
        <View style={styles.actions}>
          <TouchableOpacity style={styles.likeButton} onPress={onLike}>
            <Heart
              width={16}
              height={16}
              color={comment.liked ? colors.error : colors.gray[500]}
              fill={comment.liked ? colors.error : "none"}
            />
            <Text style={[styles.likeCount, comment.liked && { color: colors.error }]}>
              {comment.likes > 0 ? comment.likes : ""}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    marginBottom: 16,
  },
  contentContainer: {
    flex: 1,
    marginLeft: 8,
    backgroundColor: colors.white,
    borderRadius: 12,
    padding: 12,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  userName: {
    fontSize: 14,
    fontWeight: "600",
    color: colors.gray[900],
  },
  timestamp: {
    fontSize: 12,
    color: colors.gray[500],
  },
  content: {
    fontSize: 14,
    lineHeight: 20,
    color: colors.gray[800],
  },
  actions: {
    flexDirection: "row",
    marginTop: 8,
  },
  likeButton: {
    flexDirection: "row",
    alignItems: "center",
  },
  likeCount: {
    fontSize: 12,
    color: colors.gray[500],
    marginLeft: 4,
  },
})

export default Comment
