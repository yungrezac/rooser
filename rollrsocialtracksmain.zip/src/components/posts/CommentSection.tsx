"use client"

import type React from "react"

import { useState } from "react"
import { View, Text, StyleSheet, TextInput, TouchableOpacity, FlatList } from "react-native"
import { Send } from "react-native-feather"
import Comment from "./Comment"
import { colors } from "../../theme/colors"
import type { Comment as CommentType } from "../../types"

interface CommentSectionProps {
  postId: string
  comments: CommentType[]
  onAddComment: (postId: string, content: string) => void
  onLikeComment: (commentId: string) => void
}

const CommentSection: React.FC<CommentSectionProps> = ({ postId, comments, onAddComment, onLikeComment }) => {
  const [commentText, setCommentText] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async () => {
    if (!commentText.trim() || isSubmitting) return

    setIsSubmitting(true)
    try {
      await onAddComment(postId, commentText.trim())
      setCommentText("")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.commentInputContainer}>
        <TextInput
          style={styles.commentInput}
          placeholder="Добавить комментарий..."
          value={commentText}
          onChangeText={setCommentText}
          multiline
          maxLength={500}
        />
        <TouchableOpacity
          style={[styles.sendButton, (!commentText.trim() || isSubmitting) && styles.sendButtonDisabled]}
          onPress={handleSubmit}
          disabled={!commentText.trim() || isSubmitting}
        >
          <Send width={20} height={20} color={colors.white} />
        </TouchableOpacity>
      </View>

      {comments.length > 0 ? (
        <FlatList
          data={comments}
          renderItem={({ item }) => <Comment comment={item} onLike={() => onLikeComment(item.id)} />}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.commentsList}
        />
      ) : (
        <View style={styles.emptyCommentsContainer}>
          <Text style={styles.emptyCommentsText}>Будьте первым, кто оставит комментарий</Text>
        </View>
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.gray[50],
    padding: 12,
    borderTopWidth: 1,
    borderTopColor: colors.gray[200],
  },
  commentInputContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  commentInput: {
    flex: 1,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.gray[300],
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    fontSize: 14,
    maxHeight: 100,
  },
  sendButton: {
    backgroundColor: colors.primary,
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 8,
  },
  sendButtonDisabled: {
    backgroundColor: colors.gray[400],
  },
  commentsList: {
    paddingTop: 8,
  },
  emptyCommentsContainer: {
    padding: 16,
    alignItems: "center",
  },
  emptyCommentsText: {
    color: colors.gray[500],
    fontSize: 14,
  },
})

export default CommentSection
