import type React from "react"
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native"
import { Heart, MessageCircle, Share2 } from "react-native-feather"
import { formatDistanceToNow } from "date-fns"
import { ru } from "date-fns/locale"
import UserAvatar from "../common/UserAvatar"
import { colors } from "../../theme/colors"
import type { Post } from "../../types"

interface PostItemProps {
  post: Post
  onLike: (postId: string) => void
  onToggleComments: (postId: string) => void
  onPress: () => void
}

const PostItem: React.FC<PostItemProps> = ({ post, onLike, onToggleComments, onPress }) => {
  const formattedDate = formatDistanceToNow(new Date(post.timestamp), {
    addSuffix: true,
    locale: ru,
  })

  return (
    <TouchableOpacity style={styles.container} onPress={onPress} activeOpacity={0.9}>
      <View style={styles.header}>
        <UserAvatar user={post.user} size={40} />
        <View style={styles.userInfo}>
          <Text style={styles.userName}>{post.user.name}</Text>
          <Text style={styles.userHandle}>@{post.user.username}</Text>
        </View>
        <Text style={styles.timestamp}>{formattedDate}</Text>
      </View>

      <Text style={styles.content}>{post.content}</Text>

      {post.images && post.images.length > 0 && (
        <View style={styles.imageContainer}>
          {post.images.length === 1 ? (
            <Image source={{ uri: post.images[0] }} style={styles.singleImage} resizeMode="cover" />
          ) : (
            <View style={styles.imageGrid}>
              {post.images.slice(0, 4).map((image, index) => (
                <Image
                  key={index}
                  source={{ uri: image }}
                  style={[styles.gridImage, post.images.length === 3 && index === 0 && styles.gridImageLarge]}
                  resizeMode="cover"
                />
              ))}
              {post.images.length > 4 && (
                <View style={styles.moreImagesContainer}>
                  <Text style={styles.moreImagesText}>+{post.images.length - 4}</Text>
                </View>
              )}
            </View>
          )}
        </View>
      )}

      <View style={styles.actions}>
        <TouchableOpacity style={styles.actionButton} onPress={() => onLike(post.id)} activeOpacity={0.7}>
          <Heart
            width={20}
            height={20}
            color={post.liked ? colors.error : colors.gray[500]}
            fill={post.liked ? colors.error : "none"}
          />
          <Text style={[styles.actionText, post.liked && { color: colors.error }]}>{post.likes}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionButton} onPress={() => onToggleComments(post.id)} activeOpacity={0.7}>
          <MessageCircle width={20} height={20} color={colors.gray[500]} />
          <Text style={styles.actionText}>{post.comments}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionButton} activeOpacity={0.7}>
          <Share2 width={20} height={20} color={colors.gray[500]} />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.white,
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.gray[200],
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  userInfo: {
    flex: 1,
    marginLeft: 12,
  },
  userName: {
    fontSize: 16,
    fontWeight: "600",
    color: colors.gray[900],
  },
  userHandle: {
    fontSize: 14,
    color: colors.gray[500],
  },
  timestamp: {
    fontSize: 12,
    color: colors.gray[500],
  },
  content: {
    fontSize: 16,
    lineHeight: 24,
    color: colors.gray[900],
    marginBottom: 12,
  },
  imageContainer: {
    marginBottom: 12,
    borderRadius: 12,
    overflow: "hidden",
  },
  singleImage: {
    width: "100%",
    height: 200,
    borderRadius: 12,
  },
  imageGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    height: 200,
  },
  gridImage: {
    width: "49%",
    height: "49%",
    margin: "0.5%",
    borderRadius: 6,
  },
  gridImageLarge: {
    width: "100%",
    height: "49%",
  },
  moreImagesContainer: {
    position: "absolute",
    bottom: 4,
    right: 4,
    backgroundColor: "rgba(0,0,0,0.7)",
    borderRadius: 12,
    padding: 4,
    paddingHorizontal: 8,
  },
  moreImagesText: {
    color: colors.white,
    fontSize: 12,
    fontWeight: "600",
  },
  actions: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: 8,
  },
  actionButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  actionText: {
    marginLeft: 6,
    fontSize: 14,
    color: colors.gray[500],
  },
})

export default PostItem
