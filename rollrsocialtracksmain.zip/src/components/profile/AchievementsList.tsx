import type { Achievement } from "@/types"
import AchievementCard from "./AchievementCard"

interface AchievementsListProps {
  achievements: Achievement[]
}

export default function AchievementsList({ achievements }: AchievementsListProps) {
  const unlockedAchievements = achievements.filter((a) => a.unlocked)
  const lockedAchievements = achievements.filter((a) => !a.unlocked)

  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-medium mb-2 flex items-center justify-between">
          <span>Полученные достижения</span>
          <span className="text-sm text-rllr-blue">
            {unlockedAchievements.length} из {achievements.length}
          </span>
        </h3>

        {unlockedAchievements.length > 0 ? (
          <div className="space-y-2">
            {unlockedAchievements.map((achievement) => (
              <AchievementCard key={achievement.id} achievement={achievement} />
            ))}
          </div>
        ) : (
          <p className="text-sm text-gray-500 p-4 text-center bg-gray-50 rounded-lg">
            У вас пока нет полученных достижений
          </p>
        )}
      </div>

      {lockedAchievements.length > 0 && (
        <div>
          <h3 className="font-medium mb-2">Будущие достижения</h3>
          <div className="space-y-2">
            {lockedAchievements.map((achievement) => (
              <AchievementCard key={achievement.id} achievement={achievement} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
