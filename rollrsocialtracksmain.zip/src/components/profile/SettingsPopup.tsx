"use client"

import type React from "react"

import { Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useNavigate } from "react-router-dom"
import { useToast } from "@/hooks/use-toast"
import { useIsMobile } from "@/hooks/use-mobile"
import { useAuth } from "@/contexts/AuthContext"

interface SettingsPopupProps {
  triggerButton?: React.ReactNode
}

export default function SettingsPopup({ triggerButton }: SettingsPopupProps) {
  const navigate = useNavigate()
  const { toast } = useToast()
  const { signOut } = useAuth()
  const isMobile = useIsMobile()

  const handleOpenSettings = () => {
    // Navigate directly to the main settings page
    navigate("/settings")
  }

  const handleLogout = async () => {
    try {
      await signOut()
      navigate("/auth")
    } catch (error) {
      console.error("Ошибка при выходе:", error)
      toast({
        title: "Ошибка выхода",
        description: "Произошла ошибка при выходе из системы",
        variant: "destructive",
      })
    }
  }

  return (
    <div>
      {triggerButton ? (
        <div onClick={handleOpenSettings}>{triggerButton}</div>
      ) : (
        <Button variant="outline" size={isMobile ? "sm" : "default"} className="gap-1" onClick={handleOpenSettings}>
          <Settings className={isMobile ? "w-3.5 h-3.5" : "w-4 h-4"} />
        </Button>
      )}
    </div>
  )
}
