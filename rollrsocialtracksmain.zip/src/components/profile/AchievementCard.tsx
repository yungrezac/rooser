import type { Achievement } from "@/types"
import { Progress } from "@/components/ui/progress"
import { Award, MapPin, Medal, Trophy, Users } from "lucide-react"

interface AchievementCardProps {
  achievement: Achievement
}

export default function AchievementCard({ achievement }: AchievementCardProps) {
  const getIcon = () => {
    switch (achievement.icon) {
      case "award":
        return <Award className="w-5 h-5" />
      case "medal":
        return <Medal className="w-5 h-5" />
      case "users":
        return <Users className="w-5 h-5" />
      case "trophy":
        return <Trophy className="w-5 h-5" />
      case "map-pin":
        return <MapPin className="w-5 h-5" />
      default:
        return <Award className="w-5 h-5" />
    }
  }

  const progressPercent = (achievement.progress / achievement.maxProgress) * 100

  return (
    <div
      className={`p-4 border rounded-xl flex items-center gap-4 transition-all hover-scale ${
        achievement.unlocked ? "border-green-200 bg-green-50/50" : "border-gray-100 bg-gray-50/50"
      } ios-shadow`}
    >
      <div
        className={`p-2.5 rounded-full ${
          achievement.unlocked ? "bg-green-500 text-white" : "bg-gray-300 text-gray-600"
        } shadow-sm`}
      >
        {getIcon()}
      </div>

      <div className="flex-1">
        <div className="flex justify-between items-center mb-1">
          <h4 className="font-medium text-sm">{achievement.title}</h4>
          {achievement.unlocked ? (
            <span className="text-xs px-2 py-0.5 bg-green-100 text-green-600 rounded-full font-medium">Получено</span>
          ) : (
            <span className="text-xs text-gray-500">
              {achievement.progress}/{achievement.maxProgress}
            </span>
          )}
        </div>

        <p className="text-xs text-gray-500 mb-2">{achievement.description}</p>

        {!achievement.unlocked && (
          <Progress value={progressPercent} className="h-1.5 bg-gray-200" indicatorClassName="bg-black" />
        )}
      </div>
    </div>
  )
}
