"use client"
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import type { User } from "@/types"
import { UserPlus } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface FollowSuggestionProps {
  users: User[]
  onFollow: (userId: string) => void
}

export default function FollowSuggestions({ users, onFollow }: FollowSuggestionProps) {
  const { toast } = useToast()

  const handleFollow = (userId: string) => {
    onFollow(userId)

    // Показываем уведомление
    toast({
      title: "Подписка оформлена",
      description: "Вы успешно подписались на пользователя",
    })
  }

  return (
    <div className="space-y-4 animate-fade-in">
      <h3 className="font-medium mb-2">Рекомендуемые пользователи</h3>

      <div className="space-y-3">
        {users.map((user) => (
          <div
            key={user.id}
            className="flex items-center justify-between p-4 bg-gray-50/70 rounded-xl hover-scale ios-shadow"
          >
            <Link to={`/profile/${user.username}`} className="flex items-center gap-3 flex-1">
              <Avatar className="h-11 w-11 border-2 border-white shadow-sm">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback>{user.name.substring(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{user.name}</p>
                <p className="text-xs text-gray-500">@{user.username}</p>
              </div>
            </Link>

            <Button
              variant={user.isFollowing ? "subtle" : "gradient"}
              size="sm"
              className={user.isFollowing ? "" : ""}
              onClick={() => handleFollow(user.id)}
            >
              {user.isFollowing ? (
                "Отписаться"
              ) : (
                <>
                  <UserPlus className="w-4 h-4 mr-1" />
                  Подписаться
                </>
              )}
            </Button>
          </div>
        ))}
      </div>
    </div>
  )
}
