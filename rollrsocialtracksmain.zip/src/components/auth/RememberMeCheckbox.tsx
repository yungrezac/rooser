import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

interface RememberMeCheckboxProps {
  checked: boolean
  onChange: (checked: boolean) => void
  disabled?: boolean
}

export function RememberMeCheckbox({ checked, onChange, disabled = false }: RememberMeCheckboxProps) {
  return (
    <div className="flex items-center space-x-2">
      <Checkbox id="remember-me" checked={checked} onCheckedChange={onChange} disabled={disabled} />
      <Label htmlFor="remember-me" className="text-sm text-gray-600 cursor-pointer select-none">
        Запомнить меня
      </Label>
    </div>
  )
}
