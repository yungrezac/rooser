"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { Navigate, useLocation } from "react-router-dom"
import { useAuth } from "@/contexts/AuthContext"
import { Loader } from "lucide-react"

interface ProtectedRouteProps {
  children: React.ReactNode
}

export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { user, isLoading, refreshSession } = useAuth()
  const location = useLocation()
  const [isSessionRefreshed, setIsSessionRefreshed] = useState(false)
  const [redirectToAuth, setRedirectToAuth] = useState(false)

  useEffect(() => {
    // Set a reasonable timeout for loading
    const loadingTimeout = setTimeout(() => {
      // If still loading after 5 seconds and no user, redirect to auth
      if (isLoading && !user && !redirectToAuth) {
        console.log("Loading timeout reached, redirecting to auth")
        setRedirectToAuth(true)
      }
    }, 5000)

    return () => clearTimeout(loadingTimeout)
  }, [isLoading, user, redirectToAuth])

  useEffect(() => {
    // Try to refresh session once when component loads
    const attemptSessionRefresh = async () => {
      if (!user && !isLoading && !isSessionRefreshed) {
        setIsSessionRefreshed(true)

        try {
          const session = await refreshSession()
          if (!session) {
            console.log("No session after refresh attempt, redirecting to auth")
            setRedirectToAuth(true)
          }
        } catch (error) {
          console.error("Error refreshing session:", error)
          setRedirectToAuth(true)
        }
      }
    }

    attemptSessionRefresh()
  }, [user, isLoading, refreshSession, isSessionRefreshed])

  // Show loading state
  if (isLoading && !redirectToAuth) {
    return (
      <div className="flex flex-col justify-center items-center h-screen">
        <Loader className="h-8 w-8 animate-spin text-rllr-purple mb-4" />
        <p className="text-gray-600">Загрузка...</p>
      </div>
    )
  }

  // Redirect to auth page if not authenticated
  if (!user || redirectToAuth) {
    return <Navigate to="/auth" state={{ from: location }} replace />
  }

  // User is authenticated, render protected content
  return <>{children}</>
}
