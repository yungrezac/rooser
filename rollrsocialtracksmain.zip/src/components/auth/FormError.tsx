interface FormErrorProps {
  error: string | null
}

export function FormError({ error }: FormErrorProps) {
  if (!error) return null

  return <div className="text-red-500 text-sm">{error}</div>
}
