"use client"

import type React from "react"
import { useState } from "react"
import { View, StyleSheet, TextInput, TouchableOpacity, Text, ActivityIndicator } from "react-native"
import { Mail, Lock, Eye, EyeOff } from "react-native-feather"
import { useAuth } from "../../contexts/AuthContext"
import { colors } from "../../theme/colors"

interface LoginFormProps {
  onError?: (error: string | null) => void
}

const LoginForm: React.FC<LoginFormProps> = ({ onError }) => {
  const { signIn } = useAuth()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  const handleLogin = async () => {
    if (!email || !password) {
      if (onError) onError("Пожалуйста, заполните все поля")
      return
    }

    setIsSubmitting(true)
    if (onError) onError(null)

    try {
      const { error } = await signIn(email, password)
      if (error) {
        const errorMessage = error.message || "Произошла ошибка при входе"
        if (onError) onError(errorMessage)
      }
    } catch (error: any) {
      console.error("Ошибка входа:", error)
      const errorMessage = error.message || "Произошла ошибка при входе"
      if (onError) onError(errorMessage)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleForgotPassword = () => {
    // В будущем здесь будет реализация восстановления пароля
    alert("Функция восстановления пароля будет доступна позже")
  }

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <Mail width={20} height={20} color={colors.gray[500]} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
          editable={!isSubmitting}
        />
      </View>

      <View style={styles.inputContainer}>
        <Lock width={20} height={20} color={colors.gray[500]} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Пароль"
          value={password}
          onChangeText={setPassword}
          secureTextEntry={!showPassword}
          autoCapitalize="none"
          editable={!isSubmitting}
        />
        <TouchableOpacity style={styles.eyeIcon} onPress={() => setShowPassword(!showPassword)}>
          {showPassword ? (
            <EyeOff width={20} height={20} color={colors.gray[500]} />
          ) : (
            <Eye width={20} height={20} color={colors.gray[500]} />
          )}
        </TouchableOpacity>
      </View>

      <View style={styles.rememberContainer}>
        <TouchableOpacity
          style={styles.checkboxContainer}
          onPress={() => setRememberMe(!rememberMe)}
          disabled={isSubmitting}
        >
          <View style={[styles.checkbox, rememberMe && { backgroundColor: colors.primary }]}>
            {rememberMe && <View style={styles.checkmark} />}
          </View>
          <Text style={styles.rememberText}>Запомнить меня</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={handleForgotPassword} disabled={isSubmitting}>
          <Text style={styles.forgotText}>Забыли пароль?</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        style={[styles.button, isSubmitting && styles.buttonDisabled]}
        onPress={handleLogin}
        disabled={isSubmitting}
      >
        {isSubmitting ? <ActivityIndicator color={colors.white} /> : <Text style={styles.buttonText}>Войти</Text>}
      </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: colors.gray[300],
    borderRadius: 8,
    marginBottom: 16,
    paddingHorizontal: 12,
    height: 50,
    backgroundColor: colors.white,
  },
  inputIcon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    height: "100%",
    fontFamily: "Inter-Regular",
    fontSize: 16,
    color: colors.gray[900],
  },
  eyeIcon: {
    padding: 8,
  },
  rememberContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 24,
  },
  checkboxContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: colors.gray[400],
    marginRight: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  checkmark: {
    width: 10,
    height: 10,
    backgroundColor: colors.white,
    borderRadius: 2,
  },
  rememberText: {
    fontFamily: "Inter-Regular",
    fontSize: 14,
    color: colors.gray[700],
  },
  forgotText: {
    fontFamily: "Inter-Regular",
    fontSize: 14,
    color: colors.gray[500],
  },
  button: {
    backgroundColor: colors.primary,
    borderRadius: 8,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonDisabled: {
    backgroundColor: colors.gray[400],
  },
  buttonText: {
    color: colors.white,
    fontFamily: "Inter-SemiBold",
    fontSize: 16,
  },
})

export default LoginForm
