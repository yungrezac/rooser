"use client"
import { Checkbox } from "@/components/ui/checkbox"

interface TermsOfServiceProps {
  accepted: boolean
  onAcceptChange: (accepted: boolean) => void
  disabled?: boolean
}

export function TermsOfService({ accepted, onAcceptChange, disabled = false }: TermsOfServiceProps) {
  return (
    <div className="flex items-start space-x-2 pt-2">
      <Checkbox id="terms" checked={accepted} onCheckedChange={onAcceptChange} disabled={disabled} className="mt-1" />
      <div className="text-sm text-gray-500">
        <label htmlFor="terms" className="cursor-pointer select-none">
          Я соглашаюсь с{" "}
          <button
            type="button"
            onClick={() => alert("Эта функция будет доступна позже")}
            className="text-gray-900 underline"
            disabled={disabled}
          >
            условиями использования
          </button>{" "}
          и{" "}
          <button
            type="button"
            onClick={() => alert("Эта функция будет доступна позже")}
            className="text-gray-900 underline"
            disabled={disabled}
          >
            политикой приватности
          </button>
        </label>
      </div>
    </div>
  )
}
