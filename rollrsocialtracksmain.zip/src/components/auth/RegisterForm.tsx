"use client"

import type React from "react"
import { useState } from "react"
import { View, StyleSheet, TextInput, TouchableOpacity, Text, ActivityIndicator } from "react-native"
import { User, Mail, Lock, Eye, EyeOff } from "react-native-feather"
import { useAuth } from "../../contexts/AuthContext"
import { colors } from "../../theme/colors"

interface RegisterFormProps {
  onError?: (error: string | null) => void
}

const RegisterForm: React.FC<RegisterFormProps> = ({ onError }) => {
  const { signUp, signIn } = useAuth()
  const [name, setName] = useState("")
  const [username, setUsername] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [acceptedTerms, setAcceptedTerms] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)

  const validateForm = () => {
    if (!acceptedTerms) {
      const errorMessage = "Необходимо принять условия использования"
      if (onError) onError(errorMessage)
      return false
    }

    if (password !== confirmPassword) {
      const errorMessage = "Пароли не совпадают"
      if (onError) onError(errorMessage)
      return false
    }

    if (password.length < 6) {
      const errorMessage = "Пароль должен содержать не менее 6 символов"
      if (onError) onError(errorMessage)
      return false
    }

    if (!username.trim()) {
      const errorMessage = "Имя пользователя обязательно"
      if (onError) onError(errorMessage)
      return false
    }

    return true
  }

  const handleRegister = async () => {
    if (onError) onError(null)

    if (!validateForm()) return

    setIsSubmitting(true)

    try {
      const sanitizedUsername = username.toLowerCase().replace(/\s+/g, "")

      const signUpResult = await signUp(email, password, {
        name: name,
        username: sanitizedUsername,
      })

      if (signUpResult.error) throw signUpResult.error

      // После регистрации пробуем войти
      try {
        const signInResult = await signIn(email, password)
        if (signInResult.error) {
          throw new Error("Регистрация прошла успешно. Пожалуйста, войдите в систему.")
        }
      } catch (loginError: any) {
        throw new Error("Регистрация прошла успешно. Пожалуйста, войдите в систему.")
      }
    } catch (error: any) {
      console.error("Ошибка регистрации:", error)
      const errorMessage = error.message || "Произошла ошибка при регистрации"
      if (onError) onError(errorMessage)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <User width={20} height={20} color={colors.gray[500]} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Имя"
          value={name}
          onChangeText={setName}
          autoCapitalize="words"
          editable={!isSubmitting}
        />
      </View>

      <View style={styles.inputContainer}>
        <User width={20} height={20} color={colors.gray[500]} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Имя пользователя"
          value={username}
          onChangeText={setUsername}
          autoCapitalize="none"
          autoCorrect={false}
          editable={!isSubmitting}
        />
      </View>

      <View style={styles.inputContainer}>
        <Mail width={20} height={20} color={colors.gray[500]} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
          editable={!isSubmitting}
        />
      </View>

      <View style={styles.inputContainer}>
        <Lock width={20} height={20} color={colors.gray[500]} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Пароль"
          value={password}
          onChangeText={setPassword}
          secureTextEntry={!showPassword}
          autoCapitalize="none"
          editable={!isSubmitting}
        />
        <TouchableOpacity style={styles.eyeIcon} onPress={() => setShowPassword(!showPassword)}>
          {showPassword ? (
            <EyeOff width={20} height={20} color={colors.gray[500]} />
          ) : (
            <Eye width={20} height={20} color={colors.gray[500]} />
          )}
        </TouchableOpacity>
      </View>

      <View style={styles.inputContainer}>
        <Lock width={20} height={20} color={colors.gray[500]} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Подтвердите пароль"
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          secureTextEntry={!showConfirmPassword}
          autoCapitalize="none"
          editable={!isSubmitting}
        />
        <TouchableOpacity style={styles.eyeIcon} onPress={() => setShowConfirmPassword(!showConfirmPassword)}>
          {showConfirmPassword ? (
            <EyeOff width={20} height={20} color={colors.gray[500]} />
          ) : (
            <Eye width={20} height={20} color={colors.gray[500]} />
          )}
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        style={styles.termsContainer}
        onPress={() => setAcceptedTerms(!acceptedTerms)}
        disabled={isSubmitting}
      >
        <View style={[styles.checkbox, acceptedTerms && { backgroundColor: colors.primary }]}>
          {acceptedTerms && <View style={styles.checkmark} />}
        </View>
        <Text style={styles.termsText}>
          Я принимаю <Text style={styles.termsLink}>условия использования</Text> и{" "}
          <Text style={styles.termsLink}>политику конфиденциальности</Text>
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.button, isSubmitting && styles.buttonDisabled]}
        onPress={handleRegister}
        disabled={isSubmitting}
      >
        {isSubmitting ? (
          <ActivityIndicator color={colors.white} />
        ) : (
          <Text style={styles.buttonText}>Зарегистрироваться</Text>
        )}
      </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: colors.gray[300],
    borderRadius: 8,
    marginBottom: 16,
    paddingHorizontal: 12,
    height: 50,
    backgroundColor: colors.white,
  },
  inputIcon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    height: "100%",
    fontFamily: "Inter-Regular",
    fontSize: 16,
    color: colors.gray[900],
  },
  eyeIcon: {
    padding: 8,
  },
  termsContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 24,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: colors.gray[400],
    marginRight: 8,
    marginTop: 2,
    justifyContent: "center",
    alignItems: "center",
  },
  checkmark: {
    width: 10,
    height: 10,
    backgroundColor: colors.white,
    borderRadius: 2,
  },
  termsText: {
    flex: 1,
    fontFamily: "Inter-Regular",
    fontSize: 14,
    color: colors.gray[700],
    lineHeight: 20,
  },
  termsLink: {
    color: colors.primary,
    fontFamily: "Inter-Medium",
  },
  button: {
    backgroundColor: colors.primary,
    borderRadius: 8,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonDisabled: {
    backgroundColor: colors.gray[400],
  },
  buttonText: {
    color: colors.white,
    fontFamily: "Inter-SemiBold",
    fontSize: 16,
  },
})

export default RegisterForm
