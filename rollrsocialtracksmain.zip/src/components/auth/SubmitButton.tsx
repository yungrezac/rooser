import { Button } from "@/components/ui/button"
import { Loader } from "lucide-react"

interface SubmitButtonProps {
  isSubmitting: boolean
  label: string
  loadingLabel?: string
  className?: string
}

export function SubmitButton({ isSubmitting, label, loadingLabel, className }: SubmitButtonProps) {
  return (
    <Button type="submit" className={`w-full bg-gradient-rllr ${className || ""}`} disabled={isSubmitting}>
      {isSubmitting ? (
        <span className="flex items-center">
          <Loader className="h-4 w-4 mr-2 animate-spin" />
          {loadingLabel || "Загрузка..."}
        </span>
      ) : (
        label
      )}
    </Button>
  )
}
