"use client"

import type React from "react"
import { useState } from "react"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Eye, EyeOff } from "lucide-react"

interface FormFieldProps {
  id: string
  label: string
  type: string
  value: string
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
  placeholder?: string
  required?: boolean
  disabled?: boolean
  icon?: React.ReactNode
  autoFocus?: boolean
}

export function FormField({
  id,
  label,
  type: initialType,
  value,
  onChange,
  placeholder,
  required = false,
  disabled = false,
  icon,
  autoFocus = false,
}: FormFieldProps) {
  const [showPassword, setShowPassword] = useState(false)
  const isPasswordField = initialType === "password"
  const type = isPasswordField ? (showPassword ? "text" : "password") : initialType

  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <Input
          id={id}
          type={type}
          value={value}
          onChange={onChange}
          required={required}
          placeholder={placeholder}
          className={icon ? "pl-10" : ""}
          disabled={disabled}
          autoFocus={autoFocus}
        />
        {icon && <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">{icon}</div>}
        {isPasswordField && (
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
            disabled={disabled}
          >
            {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </button>
        )}
      </div>
    </div>
  )
}
