"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/contexts/AuthContext"
import { supabase } from "@/integrations/supabase/client"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"
import { format, subDays, eachDayOfInterval, startOfMonth, endOfMonth } from "date-fns"
import { ru } from "date-fns/locale"

type ActivityData = {
  date: string
  distance: number
  duration: number
  count: number
}

type MonthlyData = {
  month: string
  distance: number
  duration: number
  count: number
}

export default function ActivityStats() {
  const [activeTab, setActiveTab] = useState("weekly")
  const [weeklyData, setWeeklyData] = useState<ActivityData[]>([])
  const [monthlyData, setMonthlyData] = useState<MonthlyData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { user } = useAuth()

  useEffect(() => {
    if (!user) return

    const fetchActivityData = async () => {
      setIsLoading(true)
      try {
        // Получаем данные за последние 30 дней
        const thirtyDaysAgo = subDays(new Date(), 30).toISOString()

        const { data: activitiesData, error } = await supabase
          .from("activities")
          .select("distance, duration, created_at")
          .eq("user_id", user.id)
          .gte("created_at", thirtyDaysAgo)
          .order("created_at", { ascending: true })

        if (error) throw error

        // Создаем массив дат за последние 7 дней
        const last7Days = eachDayOfInterval({
          start: subDays(new Date(), 6),
          end: new Date(),
        })

        // Форматируем данные для недельного графика
        const weeklyActivityData = last7Days.map((date) => {
          const dateStr = format(date, "yyyy-MM-dd")
          const dayActivities = activitiesData?.filter((activity) => activity.created_at.startsWith(dateStr)) || []

          return {
            date: format(date, "EEE", { locale: ru }),
            distance: dayActivities.reduce((sum, activity) => sum + (activity.distance || 0), 0),
            duration: dayActivities.reduce((sum, activity) => sum + (activity.duration || 0), 0) / 60, // в часах
            count: dayActivities.length,
          }
        })

        setWeeklyData(weeklyActivityData)

        // Получаем данные за последние 12 месяцев
        const currentDate = new Date()
        const monthsData: MonthlyData[] = []

        for (let i = 0; i < 12; i++) {
          const monthDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1)
          const monthStart = startOfMonth(monthDate).toISOString()
          const monthEnd = endOfMonth(monthDate).toISOString()

          const { data: monthActivities, error: monthError } = await supabase
            .from("activities")
            .select("distance, duration")
            .eq("user_id", user.id)
            .gte("created_at", monthStart)
            .lte("created_at", monthEnd)

          if (monthError) throw monthError

          monthsData.unshift({
            month: format(monthDate, "MMM", { locale: ru }),
            distance: monthActivities?.reduce((sum, activity) => sum + (activity.distance || 0), 0) || 0,
            duration: (monthActivities?.reduce((sum, activity) => sum + (activity.duration || 0), 0) || 0) / 60, // в часах
            count: monthActivities?.length || 0,
          })
        }

        setMonthlyData(monthsData.slice(-6)) // Показываем только последние 6 месяцев
      } catch (error) {
        console.error("Ошибка при загрузке данных активности:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchActivityData()
  }, [user])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Статистика активности</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="weekly">За неделю</TabsTrigger>
            <TabsTrigger value="monthly">За месяцы</TabsTrigger>
          </TabsList>
          <TabsContent value="weekly" className="space-y-4">
            {isLoading ? (
              <div className="h-64 flex items-center justify-center">
                <div className="animate-spin h-8 w-8 border-4 border-rllr-purple border-t-transparent rounded-full"></div>
              </div>
            ) : (
              <>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={weeklyData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                      <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                      <Tooltip />
                      <Line yAxisId="left" type="monotone" dataKey="distance" stroke="#8884d8" name="Расстояние (км)" />
                      <Line yAxisId="right" type="monotone" dataKey="duration" stroke="#82ca9d" name="Время (ч)" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <p className="text-sm text-gray-500">Всего поездок</p>
                    <p className="font-bold text-lg text-rllr-purple">
                      {weeklyData.reduce((sum, day) => sum + day.count, 0)}
                    </p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <p className="text-sm text-gray-500">Общее расстояние</p>
                    <p className="font-bold text-lg text-rllr-purple">
                      {weeklyData.reduce((sum, day) => sum + day.distance, 0).toFixed(1)} км
                    </p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <p className="text-sm text-gray-500">Общее время</p>
                    <p className="font-bold text-lg text-rllr-purple">
                      {weeklyData.reduce((sum, day) => sum + day.duration, 0).toFixed(1)} ч
                    </p>
                  </div>
                </div>
              </>
            )}
          </TabsContent>
          <TabsContent value="monthly" className="space-y-4">
            {isLoading ? (
              <div className="h-64 flex items-center justify-center">
                <div className="animate-spin h-8 w-8 border-4 border-rllr-purple border-t-transparent rounded-full"></div>
              </div>
            ) : (
              <>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="distance" fill="#8884d8" name="Расстояние (км)" />
                      <Bar dataKey="count" fill="#82ca9d" name="Количество поездок" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <p className="text-sm text-gray-500">Всего поездок</p>
                    <p className="font-bold text-lg text-rllr-purple">
                      {monthlyData.reduce((sum, month) => sum + month.count, 0)}
                    </p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <p className="text-sm text-gray-500">Общее расстояние</p>
                    <p className="font-bold text-lg text-rllr-purple">
                      {monthlyData.reduce((sum, month) => sum + month.distance, 0).toFixed(1)} км
                    </p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <p className="text-sm text-gray-500">Среднее в месяц</p>
                    <p className="font-bold text-lg text-rllr-purple">
                      {(monthlyData.reduce((sum, month) => sum + month.distance, 0) / monthlyData.length).toFixed(1)} км
                    </p>
                  </div>
                </div>
              </>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
