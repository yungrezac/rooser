"use client"
import type { LocationPoint } from "@/types"
import { Star, ShoppingBag, Calendar, Users, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface LocationSpotsProps {
  spots: LocationPoint[]
  onSpotClick: (spot: LocationPoint) => void
}

export default function LocationSpots({ spots, onSpotClick }: LocationSpotsProps) {
  const getSpotIcon = (type: "spot" | "shop" | "event" | "meetup") => {
    switch (type) {
      case "spot":
        return <Star className="w-4 h-4" />
      case "shop":
        return <ShoppingBag className="w-4 h-4" />
      case "event":
        return <Calendar className="w-4 h-4" />
      case "meetup":
        return <Users className="w-4 h-4" />
    }
  }

  const getSpotColor = (type: "spot" | "shop" | "event" | "meetup") => {
    switch (type) {
      case "spot":
        return "bg-yellow-500"
      case "shop":
        return "bg-blue-500"
      case "event":
        return "bg-green-500"
      case "meetup":
        return "bg-purple-500"
    }
  }

  const getSurfaceBadgeColor = (surface?: string) => {
    switch (surface) {
      case "asphalt":
        return "bg-gray-800 text-white"
      case "concrete":
        return "bg-gray-400 text-black"
      case "wood":
        return "bg-amber-700 text-white"
      case "mixed":
        return "bg-teal-500 text-white"
      default:
        return "bg-gray-200 text-gray-800"
    }
  }

  if (spots.length === 0) {
    return null
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-3 max-h-80 overflow-y-auto">
      <h3 className="font-medium mb-2">Места поблизости ({spots.length})</h3>
      <div className="space-y-2">
        {spots.map((spot) => (
          <div
            key={spot.id}
            className="border border-gray-100 rounded-lg p-2 cursor-pointer hover:bg-gray-50"
            onClick={() => onSpotClick(spot)}
          >
            <div className="flex items-center gap-2">
              <div className={`p-1 rounded-full text-white ${getSpotColor(spot.type)}`}>{getSpotIcon(spot.type)}</div>
              <div className="flex-1">
                <h4 className="font-medium text-sm">{spot.name}</h4>
                <p className="text-xs text-gray-500 line-clamp-1">{spot.description || "Нет описания"}</p>

                <div className="flex flex-wrap gap-1 mt-1">
                  {spot.difficulty && (
                    <Badge variant="outline" className="text-[10px] h-5">
                      Сложность: {spot.difficulty}/10
                    </Badge>
                  )}

                  {spot.surface && (
                    <Badge variant="secondary" className={`text-[10px] h-5 ${getSurfaceBadgeColor(spot.surface)}`}>
                      {spot.surface}
                    </Badge>
                  )}

                  {spot.openHours && (
                    <Badge variant="outline" className="text-[10px] h-5 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {spot.openHours}
                    </Badge>
                  )}
                </div>
              </div>
              {spot.rating && (
                <div className="flex items-center">
                  <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                  <span className="text-xs ml-1">{spot.rating}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
