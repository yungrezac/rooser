"use client"

import type React from "react"
import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import type { LocationPoint } from "@/types"
import { Slider } from "@/components/ui/slider"
import { v4 as uuidv4 } from "uuid"
import { useToast } from "@/hooks/use-toast"
import { MapPin, Plus, Image } from "lucide-react"

interface PlacesManagerProps {
  spots: LocationPoint[]
  onAddSpot: (spot: LocationPoint) => void
  onSelectSpot: (spot: LocationPoint) => void
}

export default function PlacesManager({ spots, onAddSpot, onSelectSpot }: PlacesManagerProps) {
  const [isAdding, setIsAdding] = useState(false)
  const [newSpot, setNewSpot] = useState<Partial<LocationPoint>>({
    name: "",
    description: "",
    type: "spot",
    difficulty: 5,
    images: [],
  })
  const [imageUrls, setImageUrls] = useState<string[]>([])
  const { toast } = useToast()

  const handleAddImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // In a real app, you would upload the file to a server
    // For this demo, we'll just create a URL for the file
    const imageUrl = URL.createObjectURL(file)
    setImageUrls([...imageUrls, imageUrl])
    setNewSpot({
      ...newSpot,
      images: [...(newSpot.images || []), imageUrl],
    })
  }

  const handleSubmit = () => {
    if (!newSpot.name || !newSpot.location) {
      toast({
        title: "Не все поля заполнены",
        description: "Пожалуйста, заполните название и выберите место на карте",
        variant: "destructive",
      })
      return
    }

    const completeSpot: LocationPoint = {
      id: uuidv4(),
      name: newSpot.name || "",
      description: newSpot.description,
      type: newSpot.type || "spot",
      location: newSpot.location || { lat: 0, lng: 0 },
      difficulty: newSpot.difficulty,
      images: newSpot.images,
      timestamp: new Date().toISOString(),
      rating: 0,
    }

    onAddSpot(completeSpot)
    setNewSpot({
      name: "",
      description: "",
      type: "spot",
      difficulty: 5,
      images: [],
    })
    setImageUrls([])
    setIsAdding(false)

    toast({
      title: "Место добавлено",
      description: "Новое место успешно добавлено на карту",
    })
  }

  const handleMapClick = (location: { lat: number; lng: number }) => {
    setNewSpot({
      ...newSpot,
      location,
    })
  }

  const getSpotTypeLabel = (type: "spot" | "shop" | "event" | "meetup") => {
    switch (type) {
      case "spot":
        return "Место для катания"
      case "shop":
        return "Магазин"
      case "event":
        return "Мероприятие"
      case "meetup":
        return "Встреча"
    }
  }

  const getSpotColor = (type: "spot" | "shop" | "event" | "meetup") => {
    switch (type) {
      case "spot":
        return "bg-yellow-500"
      case "shop":
        return "bg-blue-500"
      case "event":
        return "bg-green-500"
      case "meetup":
        return "bg-purple-500"
    }
  }

  const getDifficultyLabel = (level = 5) => {
    if (level <= 2) return "Начинающий"
    if (level <= 5) return "Средний"
    if (level <= 8) return "Продвинутый"
    return "Эксперт"
  }

  return (
    <div className="space-y-4">
      {!isAdding ? (
        <>
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Места ({spots.length})</h3>
            <Button onClick={() => setIsAdding(true)} className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Добавить место
            </Button>
          </div>

          <div className="max-h-[60vh] overflow-y-auto space-y-2">
            {spots.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <MapPin className="mx-auto w-12 h-12 opacity-20 mb-2" />
                <p>Нет добавленных мест</p>
                <p className="text-sm">Будьте первым, кто добавит интересное место!</p>
              </div>
            ) : (
              spots.map((spot) => (
                <Card
                  key={spot.id}
                  className="cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => onSelectSpot(spot)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-full text-white ${getSpotColor(spot.type)}`}>
                        <MapPin className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <h3 className="font-medium">{spot.name}</h3>
                          {spot.difficulty && (
                            <div className="text-xs bg-gray-100 px-2 py-1 rounded">Сложность: {spot.difficulty}/10</div>
                          )}
                        </div>
                        <div className="text-xs text-gray-500 flex items-center gap-2">
                          <span>{getSpotTypeLabel(spot.type)}</span>
                          {spot.images && spot.images.length > 0 && (
                            <span className="flex items-center gap-1">
                              <Image className="w-3 h-3" />
                              {spot.images.length}
                            </span>
                          )}
                        </div>
                        {spot.description && <p className="text-sm mt-2 line-clamp-2">{spot.description}</p>}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </>
      ) : (
        <div className="space-y-4 bg-white p-4 rounded-lg border">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Новое место</h3>
            <Button variant="ghost" size="sm" onClick={() => setIsAdding(false)}>
              Отмена
            </Button>
          </div>

          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Название</Label>
              <Input
                id="name"
                value={newSpot.name}
                onChange={(e) => setNewSpot({ ...newSpot, name: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="type">Тип места</Label>
              <select
                id="type"
                className="w-full border rounded-md px-3 py-2"
                value={newSpot.type}
                onChange={(e) =>
                  setNewSpot({ ...newSpot, type: e.target.value as "spot" | "shop" | "event" | "meetup" })
                }
              >
                <option value="spot">Место для катания</option>
                <option value="shop">Магазин</option>
                <option value="event">Мероприятие</option>
                <option value="meetup">Встреча</option>
              </select>
            </div>

            <div>
              <Label htmlFor="description">Описание</Label>
              <Textarea
                id="description"
                value={newSpot.description}
                onChange={(e) => setNewSpot({ ...newSpot, description: e.target.value })}
              />
            </div>

            <div>
              <Label>
                Уровень сложности: {newSpot.difficulty || 5}/10 ({getDifficultyLabel(newSpot.difficulty)})
              </Label>
              <Slider
                className="py-4"
                defaultValue={[5]}
                min={1}
                max={10}
                step={1}
                value={[newSpot.difficulty || 5]}
                onValueChange={(values) => setNewSpot({ ...newSpot, difficulty: values[0] })}
              />
            </div>

            <div>
              <Label>Фотографии</Label>
              <div className="grid grid-cols-3 gap-2 mt-2">
                {imageUrls.map((url, index) => (
                  <div key={index} className="relative h-20 rounded-md overflow-hidden">
                    <img src={url} alt="Place" className="w-full h-full object-cover" />
                  </div>
                ))}
                <label className="border-2 border-dashed rounded-md h-20 flex items-center justify-center cursor-pointer bg-gray-50">
                  <div className="text-center">
                    <Plus className="mx-auto w-6 h-6 text-gray-400" />
                    <span className="text-xs text-gray-500">Добавить</span>
                  </div>
                  <input type="file" accept="image/*" className="hidden" onChange={handleAddImage} />
                </label>
              </div>
            </div>

            <div className="pt-2">
              <Button onClick={handleSubmit} className="w-full">
                Добавить место
              </Button>
              <p className="text-xs text-center mt-2 text-gray-500">Чтобы указать местоположение, кликните на карте</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
