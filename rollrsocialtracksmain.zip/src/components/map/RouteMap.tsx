"use client"

import { useEffect, useRef, useState } from "react"
import mapboxgl from "mapbox-gl"
import "mapbox-gl/dist/mapbox-gl.css"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { MapPin, Play, Square, Navigation } from "lucide-react"
import UserLocationMarker from "./UserLocationMarker"
import { createRoot } from "react-dom/client"

// Использование реального API ключа Mapbox
const MAPBOX_TOKEN = "pk.eyJ1IjoieXVuZ3JlemFjIiwiYSI6ImNtOW10ZzJ6bDBjNHUyanI3ejc5eXo1d2MifQ._tryk9cXjfReUGLGnNkm6Q"

interface UserLocation {
  username: string
  avatarUrl: string
  location: {
    lat: number
    lng: number
  }
  isRecording?: boolean
  distance?: number
  duration?: number
}

interface RouteMapProps {
  initialCenter?: [number, number] // [lng, lat]
  initialZoom?: number
  onRouteRecorded?: (data: {
    distance: number
    duration: number
    points: {
      lat: number
      lng: number
    }[]
  }) => void
  userLocations?: UserLocation[]
  isSharingLocation?: boolean
  onToggleLocationSharing?: (isSharing: boolean) => void
}

export default function RouteMap({
  initialCenter = [37.6156, 55.7522], // Москва по умолчанию
  initialZoom = 12,
  onRouteRecorded,
  userLocations = [],
  isSharingLocation = false,
  onToggleLocationSharing,
}: RouteMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<mapboxgl.Map | null>(null)
  const [recording, setRecording] = useState(false)
  const [route, setRoute] = useState<
    {
      lat: number
      lng: number
    }[]
  >([])
  const [distance, setDistance] = useState(0)
  const [duration, setDuration] = useState(0)
  const [startTime, setStartTime] = useState<Date | null>(null)
  const [mapLoaded, setMapLoaded] = useState(false)
  const routeSourceRef = useRef<string | null>(null)
  const watchPositionIdRef = useRef<number | null>(null)
  const { toast } = useToast()
  const userMarkers = useRef<{
    [key: string]: mapboxgl.Marker
  }>({})
  const [selectedUser, setSelectedUser] = useState<string | null>(null)
  const markersInitializedRef = useRef(false)

  // Инициализация карты (единожды)
  useEffect(() => {
    if (!mapContainer.current || map.current) return

    mapboxgl.accessToken = MAPBOX_TOKEN
    const mapInstance = new mapboxgl.Map({
      container: mapContainer.current,
      style: "mapbox://styles/mapbox/streets-v11",
      center: initialCenter,
      zoom: initialZoom,
    })

    mapInstance.addControl(new mapboxgl.NavigationControl(), "top-right")
    mapInstance.addControl(
      new mapboxgl.GeolocateControl({
        positionOptions: {
          enableHighAccuracy: true,
        },
        trackUserLocation: true,
      }),
    )

    mapInstance.on("load", () => {
      setMapLoaded(true)
      mapInstance.addSource("route", {
        type: "geojson",
        data: {
          type: "Feature",
          properties: {},
          geometry: {
            type: "LineString",
            coordinates: [],
          },
        },
      })

      mapInstance.addLayer({
        id: "route",
        type: "line",
        source: "route",
        layout: {
          "line-join": "round",
          "line-cap": "round",
        },
        paint: {
          "line-color": "#8B5CF6",
          "line-width": 5,
        },
      })

      routeSourceRef.current = "route"
    })

    map.current = mapInstance

    return () => {
      if (watchPositionIdRef.current) {
        navigator.geolocation.clearWatch(watchPositionIdRef.current)
      }
      mapInstance.remove()
      markersInitializedRef.current = false
    }
  }, []) // Пустой массив зависимостей для инициализации только один раз

  // Функция для расчета расстояния между точками (в км)
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371 // Радиус Земли в км
    const dLat = ((lat2 - lat1) * Math.PI) / 180
    const dLon = ((lon2 - lon1) * Math.PI) / 180
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }

  // Обновление маркеров пользователей на карте
  useEffect(() => {
    if (!map.current || !mapLoaded) return

    // Удаляем маркеры, которых больше нет в списке
    Object.keys(userMarkers.current).forEach((username) => {
      if (!userLocations.find((u) => u.username === username)) {
        userMarkers.current[username].remove()
        delete userMarkers.current[username]
      }
    })

    // Добавляем или обновляем маркеры пользователей
    userLocations.forEach((user) => {
      // Если маркер уже есть, обновляем его позицию
      if (userMarkers.current[user.username]) {
        userMarkers.current[user.username].setLngLat([user.location.lng, user.location.lat])
      } else {
        // Иначе создаем новый маркер
        const markerElement = document.createElement("div")
        const markerRoot = createRoot(markerElement)

        markerRoot.render(
          <UserLocationMarker
            username={user.username}
            avatarUrl={user.avatarUrl}
            isRecording={user.isRecording}
            distance={user.distance}
            duration={user.duration}
            onClick={() => setSelectedUser(selectedUser === user.username ? null : user.username)}
          />,
        )

        userMarkers.current[user.username] = new mapboxgl.Marker(markerElement)
          .setLngLat([user.location.lng, user.location.lat])
          .addTo(map.current)
      }
    })

    markersInitializedRef.current = true
  }, [mapLoaded, userLocations, selectedUser])

  // Начать запись маршрута
  const startRecording = () => {
    if (!mapLoaded || !map.current) {
      toast({
        title: "Ошибка",
        description: "Карта не загружена. Пожалуйста, подождите.",
        variant: "destructive",
      })
      return
    }

    // Запрашиваем доступ к геолокации
    if (navigator.geolocation) {
      setRecording(true)
      setRoute([])
      setDistance(0)
      setStartTime(new Date())

      // Уведомление о начале записи
      toast({
        title: "Запись маршрута",
        description: "Запись вашего маршрута начата",
      })

      // Следить за изменением позиции
      const id = navigator.geolocation.watchPosition(
        (position) => {
          const { latitude, longitude } = position.coords
          const newPoint = { lat: latitude, lng: longitude }

          setRoute((prevRoute) => {
            const updatedRoute = [...prevRoute, newPoint]

            // Обновляем линию на карте
            if (map.current && routeSourceRef.current) {
              const source = map.current.getSource(routeSourceRef.current) as mapboxgl.GeoJSONSource
              if (source) {
                source.setData({
                  type: "Feature",
                  properties: {},
                  geometry: {
                    type: "LineString",
                    coordinates: updatedRoute.map((p) => [p.lng, p.lat]),
                  },
                })
              }
            }

            // Рассчитываем новое расстояние
            if (prevRoute.length > 0) {
              const lastPoint = prevRoute[prevRoute.length - 1]
              const newSegmentDistance = calculateDistance(lastPoint.lat, lastPoint.lng, newPoint.lat, newPoint.lng)
              setDistance((prevDistance) => prevDistance + newSegmentDistance)
            }

            // Центрируем карту на текущей позиции
            if (map.current) {
              map.current.flyTo({
                center: [newPoint.lng, newPoint.lat],
                essential: true,
              })
            }

            // Обновляем продолжительность
            if (startTime) {
              const elapsed = (new Date().getTime() - startTime.getTime()) / 1000 / 60 // в минутах
              setDuration(elapsed)
            }

            return updatedRoute
          })
        },
        (error) => {
          toast({
            title: "Ошибка геолокации",
            description: error.message,
            variant: "destructive",
          })
          console.error("Ошибка геолокации:", error)
          setRecording(false)
        },
        {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0,
        },
      )

      watchPositionIdRef.current = id
    } else {
      toast({
        title: "Геолокация недоступна",
        description: "Ваш браузер не поддерживает геолокацию",
        variant: "destructive",
      })
    }
  }

  // Остановить запись маршрута
  const stopRecording = () => {
    if (watchPositionIdRef.current) {
      navigator.geolocation.clearWatch(watchPositionIdRef.current)
      watchPositionIdRef.current = null
    }

    setRecording(false)

    toast({
      title: "Запись завершена",
      description: `Маршрут записан: ${distance.toFixed(2)} км за ${Math.floor(duration)} мин ${Math.round((duration % 1) * 60)} сек`,
    })

    // Вызываем onRouteRecorded, если он был передан
    if (onRouteRecorded && route.length > 1) {
      onRouteRecorded({
        distance,
        duration,
        points: route,
      })
    }
  }

  return (
    <div className="relative w-full h-[70vh] md:h-[80vh] rounded-lg overflow-hidden">
      <div ref={mapContainer} className="absolute inset-0" />

      {/* Управление записью маршрута */}
      <div className="absolute bottom-4 left-0 right-0 mx-auto w-max flex gap-2 items-center px-[2px] py-0">
        {recording ? (
          <Button onClick={stopRecording} className="flex items-center gap-2 bg-red-500 hover:bg-red-600" size="mobile">
            <Square className="w-4 h-4" />
            Остановить запись
          </Button>
        ) : (
          <Button
            onClick={startRecording}
            className="flex items-center gap-2 bg-rllr-purple hover:bg-rllr-purple/80"
            size="mobile"
          >
            <Play className="w-4 h-4" />
            Начать запись
          </Button>
        )}

        {/* Кнопка включения/выключения трансляции */}
        {onToggleLocationSharing && (
          <Button
            onClick={() => onToggleLocationSharing(!isSharingLocation)}
            variant={isSharingLocation ? "destructive" : "secondary"}
            className="flex items-center gap-2 ml-2 text-left"
            size="mobile"
          >
            <Navigation className="w-4 h-4" />
            {isSharingLocation ? "Выключить трансляцию" : "Включить трансляцию"}
          </Button>
        )}
      </div>

      {/* Информация о текущей записи */}
      {recording && (
        <div className="absolute top-4 left-4 bg-white p-3 rounded-lg shadow-md">
          <h3 className="font-bold text-sm">Запись маршрута</h3>
          <div className="grid grid-cols-2 gap-2 mt-2 text-sm">
            <div>
              <span className="text-gray-500">Расстояние:</span>
              <p className="font-medium">{distance.toFixed(2)} км</p>
            </div>
            <div>
              <span className="text-gray-500">Время:</span>
              <p className="font-medium">
                {Math.floor(duration)} мин {Math.round((duration % 1) * 60)} сек
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Маркеры записанного маршрута */}
      {route.length > 0 && (
        <div className="absolute top-4 right-4 flex items-center bg-white py-1 px-3 rounded-lg shadow-md">
          <MapPin className="w-4 h-4 text-rllr-purple mr-1" />
          <span className="text-sm font-medium">{route.length} точек</span>
        </div>
      )}
    </div>
  )
}
