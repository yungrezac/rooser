"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { Save, Share2 } from "lucide-react"

interface SaveRouteFormProps {
  distance: number
  duration: number
  points: { lat: number; lng: number }[]
  onSave: (name: string, isPublic: boolean) => void
  onCancel: () => void
}

export default function SaveRouteForm({ distance, duration, points, onSave, onCancel }: SaveRouteFormProps) {
  const [routeName, setRouteName] = useState("")
  const [routeDescription, setRouteDescription] = useState("")
  const [isPublic, setIsPublic] = useState(true)
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!routeName.trim()) {
      toast({
        title: "Требуется название",
        description: "Пожалуйста, укажите название маршрута",
        variant: "destructive",
      })
      return
    }

    // В реальном приложении здесь будет сохранение в API
    console.log("Сохранение маршрута:", {
      name: routeName,
      description: routeDescription,
      isPublic,
      distance,
      duration,
      points,
    })

    toast({
      title: "Маршрут сохранен",
      description: `"${routeName}" успешно сохранен`,
    })

    onSave(routeName, isPublic)
  }

  const handleShareRoute = () => {
    // В реальном приложении здесь будет реализация шеринга
    toast({
      title: "Поделиться маршрутом",
      description: "Функция поделиться будет доступна в полной версии",
    })
  }

  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h2 className="text-lg font-bold mb-4">Сохранить маршрут</h2>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-gray-50 p-3 rounded-lg">
          <span className="text-sm text-gray-500">Расстояние</span>
          <p className="font-medium">{distance.toFixed(2)} км</p>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <span className="text-sm text-gray-500">Время</span>
          <p className="font-medium">
            {Math.floor(duration)} мин {Math.round((duration % 1) * 60)} сек
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="routeName">Название маршрута</Label>
          <Input
            id="routeName"
            value={routeName}
            onChange={(e) => setRouteName(e.target.value)}
            placeholder="Например: Утренняя пробежка"
            required
          />
        </div>

        <div>
          <Label htmlFor="routeDescription">Описание (необязательно)</Label>
          <Textarea
            id="routeDescription"
            value={routeDescription}
            onChange={(e) => setRouteDescription(e.target.value)}
            placeholder="Расскажите о маршруте подробнее..."
            rows={3}
          />
        </div>

        <div className="flex items-center justify-between">
          <Label htmlFor="isPublic" className="text-sm font-normal cursor-pointer">
            Сделать маршрут публичным
          </Label>
          <Switch id="isPublic" checked={isPublic} onCheckedChange={setIsPublic} />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Button
            type="submit"
            className="bg-rllr-purple hover:bg-rllr-purple/80 flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            Сохранить
          </Button>

          <Button
            type="button"
            onClick={handleShareRoute}
            variant="outline"
            className="flex items-center justify-center gap-2"
          >
            <Share2 className="w-4 h-4" />
            Поделиться
          </Button>
        </div>

        <Button type="button" onClick={onCancel} variant="ghost" className="w-full text-gray-500">
          Отмена
        </Button>
      </form>
    </div>
  )
}
