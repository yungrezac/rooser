"use client"
import { Link } from "react-router-dom"
import UserAvatar from "@/components/common/UserAvatar"
import { Clock, Navigation } from "lucide-react"
import { Button } from "@/components/ui/button"

interface UserLocationMarkerProps {
  username: string
  avatarUrl: string
  isRecording?: boolean
  distance?: number
  duration?: number
  onClick?: () => void
}

export default function UserLocationMarker({
  username,
  avatarUrl,
  isRecording,
  distance,
  duration,
  onClick,
}: UserLocationMarkerProps) {
  // Format duration to minutes and seconds
  const formatDuration = (durationInMinutes?: number) => {
    if (!durationInMinutes) return "0 мин 0 сек"
    const minutes = Math.floor(durationInMinutes)
    const seconds = Math.round((durationInMinutes % 1) * 60)
    return `${minutes} мин ${seconds} сек`
  }

  return (
    <div className="relative" onClick={onClick}>
      <div className="absolute -top-16 -left-20 w-40 bg-white rounded-lg shadow-lg p-3 z-10 animate-fade-in">
        <div className="flex items-center gap-2 mb-2">
          <UserAvatar src={avatarUrl} alt={username} username={username} size="sm" withLink={false} />
          <span className="font-medium text-sm">{username}</span>
        </div>

        {isRecording ? (
          <div className="space-y-1">
            <div className="flex items-center text-xs text-gray-600">
              <Navigation className="w-3 h-3 mr-1 text-rllr-purple" />
              <span>{distance?.toFixed(2)} км</span>
            </div>
            <div className="flex items-center text-xs text-gray-600">
              <Clock className="w-3 h-3 mr-1 text-rllr-purple" />
              <span>{formatDuration(duration)}</span>
            </div>
          </div>
        ) : (
          <Link to={`/profile/${username}`}>
            <Button size="sm" className="w-full text-xs">
              Перейти в профиль
            </Button>
          </Link>
        )}
      </div>
      <div className="rounded-full shadow-md cursor-pointer hover:scale-105 transition-transform">
        <UserAvatar src={avatarUrl} alt={username} username={username} size="sm" withLink={false} />
      </div>
    </div>
  )
}
