"use client"
import { formatRelativeDate } from "@/lib/date"
import { Button } from "@/components/ui/button"
import type { Route } from "@/types"
import { MapPin } from "lucide-react"

interface SavedRoutesProps {
  routes: Route[]
  onSelectRoute: (route: Route) => void
}

export default function SavedRoutes({ routes, onSelectRoute }: SavedRoutesProps) {
  if (routes.length === 0) {
    return (
      <div className="bg-white p-4 rounded-lg shadow text-center">
        <MapPin className="w-10 h-10 text-gray-300 mx-auto mb-2" />
        <h3 className="font-medium">Нет сохраненных маршрутов</h3>
        <p className="text-sm text-gray-500 mt-1">Запишите свой первый маршрут, чтобы он отобразился здесь</p>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg shadow divide-y">
      {routes.map((route) => (
        <div key={route.id} className="p-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium">{route.name}</h3>
              <p className="text-xs text-gray-500">{formatRelativeDate(route.timestamp || new Date().toISOString())}</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium">{route.distance.toFixed(2)} км</p>
              <Button size="sm" variant="ghost" className="text-rllr-blue" onClick={() => onSelectRoute(route)}>
                Показать
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
