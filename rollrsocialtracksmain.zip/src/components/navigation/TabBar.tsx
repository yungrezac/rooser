import type React from "react"
import { View, TouchableOpacity, StyleSheet, Text } from "react-native"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import type { BottomTabBarProps } from "@react-navigation/bottom-tabs"
import { Home, Map, PlusSquare, MessageSquare, User } from "react-native-feather"
import { colors } from "../../theme/colors"

const TabBar: React.FC<BottomTabBarProps> = ({ state, descriptors, navigation }) => {
  const insets = useSafeAreaInsets()

  return (
    <View
      style={[
        styles.container,
        {
          height: 60 + insets.bottom,
          paddingBottom: insets.bottom,
        },
      ]}
    >
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key]
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
              ? options.title
              : route.name

        const isFocused = state.index === index

        const onPress = () => {
          const event = navigation.emit({
            type: "tabPress",
            target: route.key,
            canPreventDefault: true,
          })

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name)
          }
        }

        const getIcon = () => {
          const color = isFocused ? colors.primary : colors.gray[500]
          const size = 24

          switch (route.name) {
            case "Feed":
              return <Home width={size} height={size} color={color} />
            case "Map":
              return <Map width={size} height={size} color={color} />
            case "Create":
              return <PlusSquare width={size} height={size} color={color} />
            case "Messages":
              return <MessageSquare width={size} height={size} color={color} />
            case "Profile":
              return <User width={size} height={size} color={color} />
            default:
              return null
          }
        }

        const getLabel = () => {
          switch (route.name) {
            case "Feed":
              return "Лента"
            case "Map":
              return "Карта"
            case "Create":
              return "Создать"
            case "Messages":
              return "Чаты"
            case "Profile":
              return "Профиль"
            default:
              return label
          }
        }

        return (
          <TouchableOpacity
            key={index}
            accessibilityRole="button"
            accessibilityState={isFocused ? { selected: true } : {}}
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            onPress={onPress}
            style={styles.tabButton}
          >
            {getIcon()}
            <Text style={[styles.tabLabel, { color: isFocused ? colors.primary : colors.gray[500] }]}>
              {getLabel()}
            </Text>
          </TouchableOpacity>
        )
      })}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: colors.gray[200],
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 5,
  },
  tabButton: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 8,
  },
  tabLabel: {
    fontSize: 12,
    fontFamily: "Inter-Medium",
    marginTop: 4,
  },
})

export default TabBar
