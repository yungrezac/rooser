import { Link } from "react-router-dom"
import { cn } from "@/lib/utils"
import type { Chat } from "@/types"
import { formatMessageDate } from "@/lib/date"

interface ChatListProps {
  chats: Chat[]
  isLoading: boolean
}

export default function ChatList({ chats, isLoading }: ChatListProps) {
  if (isLoading) {
    return (
      <div className="animate-fade-in space-y-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="flex items-center gap-3 p-3 rounded-xl">
            <div className="w-12 h-12 rounded-full bg-gray-200 animate-pulse"></div>
            <div className="flex-1">
              <div className="flex justify-between items-baseline">
                <div className="h-4 bg-gray-200 rounded w-1/3 animate-pulse"></div>
                <div className="h-3 bg-gray-200 rounded w-1/5 animate-pulse"></div>
              </div>
              <div className="h-3 bg-gray-200 rounded w-2/3 mt-2 animate-pulse"></div>
            </div>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="animate-fade-in">
      <div className="space-y-2">
        {chats.map((chat) => (
          <ChatItem key={chat.id} chat={chat} />
        ))}
      </div>

      {chats.length === 0 && (
        <div className="text-center py-10">
          <p className="text-gray-500">У вас пока нет сообщений</p>
        </div>
      )}
    </div>
  )
}

interface ChatItemProps {
  chat: Chat
}

function ChatItem({ chat }: ChatItemProps) {
  return (
    <Link
      to={`/messages/${chat.id}`}
      className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-100 transition-colors"
    >
      <div className="relative">
        <img
          src={chat.user.avatar || "/placeholder.svg"}
          alt={chat.user.name}
          className="w-12 h-12 rounded-full object-cover"
        />
        {chat.unread > 0 && (
          <div className="absolute -top-1 -right-1 bg-rllr-orange text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
            {chat.unread}
          </div>
        )}
      </div>

      <div className="flex-1">
        <div className="flex justify-between items-baseline">
          <h3 className="font-medium">{chat.user.name}</h3>
          <span className="text-xs text-gray-500">{formatMessageDate(chat.timestamp)}</span>
        </div>

        <p className={cn("text-sm truncate pr-2", chat.unread > 0 ? "font-medium text-black" : "text-gray-500")}>
          {chat.lastMessage}
        </p>
      </div>
    </Link>
  )
}
