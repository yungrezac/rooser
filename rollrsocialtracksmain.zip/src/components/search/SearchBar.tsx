"use client"

import type React from "react"

import { useState } from "react"
import { View, TextInput, StyleSheet, TouchableOpacity } from "react-native"
import { Search, X } from "react-native-feather"
import { colors } from "../../theme/colors"

interface SearchBarProps {
  onSearch?: (query: string) => void
  placeholder?: string
}

const SearchBar: React.FC<SearchBarProps> = ({ onSearch, placeholder = "Поиск..." }) => {
  const [query, setQuery] = useState("")
  const [isFocused, setIsFocused] = useState(false)

  const handleClear = () => {
    setQuery("")
    if (onSearch) {
      onSearch("")
    }
  }

  const handleSubmit = () => {
    if (onSearch) {
      onSearch(query)
    }
  }

  return (
    <View style={[styles.container, isFocused && styles.containerFocused]}>
      <Search width={18} height={18} color={colors.gray[500]} />
      <TextInput
        style={styles.input}
        placeholder={placeholder}
        value={query}
        onChangeText={setQuery}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        onSubmitEditing={handleSubmit}
        returnKeyType="search"
      />
      {query.length > 0 && (
        <TouchableOpacity onPress={handleClear} style={styles.clearButton}>
          <X width={16} height={16} color={colors.gray[500]} />
        </TouchableOpacity>
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.gray[100],
    borderRadius: 20,
    paddingHorizontal: 12,
    height: 36,
    width: 180,
  },
  containerFocused: {
    backgroundColor: colors.gray[200],
  },
  input: {
    flex: 1,
    fontSize: 14,
    marginLeft: 8,
    height: "100%",
    color: colors.gray[900],
  },
  clearButton: {
    padding: 4,
  },
})

export default SearchBar
