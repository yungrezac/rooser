"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { supabase } from "@/integrations/supabase/client"
import { useAuth } from "./AuthContext"
import { useToast } from "@/hooks/use-toast"

interface UserProfile {
  username: string
  name: string | null
  avatar_url: string | null
  bio: string | null
  followers: number
  following: number
}

interface UserDataContextType {
  profile: UserProfile | null
  isLoading: boolean
  refetchProfile: () => Promise<void>
}

const UserDataContext = createContext<UserDataContextType | undefined>(undefined)

export function UserDataProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const fetchUserProfile = async () => {
    if (!user?.id) return

    try {
      setIsLoading(true)

      const { data, error } = await supabase
        .from("profiles")
        .select("username, name, avatar_url, bio, followers, following")
        .eq("id", user.id)
        .single()

      if (error) throw error

      setProfile(data)
    } catch (error: any) {
      console.error("Error fetching user profile:", error)
      toast({
        title: "Ошибка загрузки профиля",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (user?.id) {
      fetchUserProfile()

      // Set up Realtime subscription for profile updates
      const channel = supabase
        .channel(`user-profile-${user.id}`)
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "profiles",
            filter: `id=eq.${user.id}`,
          },
          (payload) => {
            console.log("Profile updated in realtime:", payload)
            setProfile(payload.new as UserProfile)
          },
        )
        .subscribe()

      return () => {
        supabase.removeChannel(channel)
      }
    } else {
      setProfile(null)
    }
  }, [user?.id])

  const value = {
    profile,
    isLoading,
    refetchProfile: fetchUserProfile,
  }

  return <UserDataContext.Provider value={value}>{children}</UserDataContext.Provider>
}

export function useUserData() {
  const context = useContext(UserDataContext)

  if (context === undefined) {
    throw new Error("useUserData must be used within a UserDataProvider")
  }

  return context
}
