"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { useColorScheme } from "react-native"

type ThemeMode = "light" | "dark" | "system"

interface ThemeContextType {
  mode: ThemeMode
  isDark: boolean
  setMode: (mode: ThemeMode) => void
}

const ThemeContext = createContext<ThemeContextType | null>(null)

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const systemColorScheme = useColorScheme()
  const [mode, setMode] = useState<ThemeMode>("system")

  // Определяем, темная ли тема
  const isDark = mode === "system" ? systemColorScheme === "dark" : mode === "dark"

  // Загружаем сохраненную тему при инициализации
  useEffect(() => {
    const loadTheme = async () => {
      try {
        // В веб-версии используем localStorage
        if (typeof window !== "undefined") {
          const savedMode = localStorage.getItem("themeMode") as ThemeMode | null
          if (savedMode) {
            setMode(savedMode)
          }
        }
      } catch (error) {
        console.error("Error loading theme:", error)
      }
    }

    loadTheme()
  }, [])

  // Сохраняем тему при изменении
  const handleSetMode = (newMode: ThemeMode) => {
    setMode(newMode)
    try {
      // В веб-версии используем localStorage
      if (typeof window !== "undefined") {
        localStorage.setItem("themeMode", newMode)
      }
    } catch (error) {
      console.error("Error saving theme:", error)
    }
  }

  return <ThemeContext.Provider value={{ mode, isDark, setMode: handleSetMode }}>{children}</ThemeContext.Provider>
}

export const useTheme = () => {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error("useTheme must be used within a ThemeProvider")
  }
  return context
}
