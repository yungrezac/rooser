"use client"

import type React from "react"

import { createContext, useContext, useState } from "react"

export type ToastType = "success" | "error" | "info" | "warning"

export interface Toast {
  type: ToastType
  message: string
  duration?: number
}

interface ToastContextType {
  toast: Toast | null
  showToast: (toast: Toast) => void
  hideToast: () => void
}

const ToastContext = createContext<ToastContextType | null>(null)

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toast, setToast] = useState<Toast | null>(null)
  const [timeoutId, setTimeoutId] = useState<NodeJS.Timeout | null>(null)

  const showToast = (newToast: Toast) => {
    // Clear any existing timeout
    if (timeoutId) {
      clearTimeout(timeoutId)
    }

    setToast(newToast)

    // Auto-hide toast after duration
    const duration = newToast.duration || 3000
    const id = setTimeout(() => {
      setToast(null)
      setTimeoutId(null)
    }, duration)

    setTimeoutId(id)
  }

  const hideToast = () => {
    if (timeoutId) {
      clearTimeout(timeoutId)
      setTimeoutId(null)
    }
    setToast(null)
  }

  return <ToastContext.Provider value={{ toast, showToast, hideToast }}>{children}</ToastContext.Provider>
}

export const useToast = () => {
  const context = useContext(ToastContext)
  if (!context) {
    throw new Error("useToast must be used within a ToastProvider")
  }
  return context
}
