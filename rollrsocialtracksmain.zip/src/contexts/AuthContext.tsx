"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import type { Session, User } from "@supabase/supabase-js"
import { supabase } from "../lib/supabase"
import { useToast } from "./ToastContext"

interface AuthContextType {
  user: User | null
  session: Session | null
  isLoading: boolean
  signUp: (email: string, password: string, userData: Record<string, any>) => Promise<{ error: Error | null }>
  signIn: (email: string, password: string) => Promise<{ error: Error | null; data: any }>
  signOut: () => Promise<{ error: Error | null }>
  updateProfile: (userData: Record<string, any>) => Promise<{ error: Error | null }>
  refreshSession: () => Promise<Session | null>
}

const AuthContext = createContext<AuthContextType | null>(null)

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const { showToast } = useToast()

  // Initialize auth state
  useEffect(() => {
    let mounted = true

    // Set up auth state listener
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, currentSession) => {
      if (mounted) {
        setSession(currentSession)
        setUser(currentSession?.user || null)
      }
    })

    // Get initial session
    const getInitialSession = async () => {
      try {
        setIsLoading(true)
        const { data, error } = await supabase.auth.getSession()

        if (error) {
          throw error
        }

        if (mounted) {
          setSession(data.session)
          setUser(data.session?.user || null)
        }
      } catch (error) {
        console.error("Error getting initial session:", error)
      } finally {
        if (mounted) {
          setIsLoading(false)
        }
      }
    }

    getInitialSession()

    return () => {
      mounted = false
      subscription.unsubscribe()
    }
  }, [])

  // Sign up function
  const signUp = async (email: string, password: string, userData: Record<string, any>) => {
    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            username: userData.username,
            name: userData.name,
            avatar_url: userData.avatarUrl,
          },
        },
      })

      if (error) throw error

      // Create profile record
      if (!error) {
        showToast({
          type: "success",
          message: "Аккаунт создан. Проверьте электронную почту для подтверждения.",
        })
      }

      return { error: null }
    } catch (error: any) {
      showToast({
        type: "error",
        message: error.message || "Ошибка при регистрации",
      })
      return { error }
    }
  }

  // Sign in function
  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) throw error

      showToast({
        type: "success",
        message: `Добро пожаловать${data.user?.user_metadata?.name ? ", " + data.user.user_metadata.name : ""}!`,
      })

      return { error: null, data }
    } catch (error: any) {
      showToast({
        type: "error",
        message: error.message || "Ошибка при входе",
      })
      return { error, data: null }
    }
  }

  // Sign out function
  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut()

      if (error) throw error

      showToast({
        type: "success",
        message: "Вы успешно вышли из системы",
      })

      return { error: null }
    } catch (error: any) {
      showToast({
        type: "error",
        message: error.message || "Ошибка при выходе",
      })
      return { error }
    }
  }

  // Update profile function
  const updateProfile = async (userData: Record<string, any>) => {
    if (!user?.id) {
      return { error: new Error("User not authenticated") }
    }

    try {
      // Update user metadata
      const { error: authError } = await supabase.auth.updateUser({
        data: userData,
      })

      if (authError) throw authError

      // Update profile data
      const { error: profileError } = await supabase.from("profiles").update(userData).eq("id", user.id)

      if (profileError) throw profileError

      showToast({
        type: "success",
        message: "Профиль успешно обновлен",
      })

      return { error: null }
    } catch (error: any) {
      showToast({
        type: "error",
        message: error.message || "Ошибка при обновлении профиля",
      })
      return { error }
    }
  }

  // Refresh session
  const refreshSession = async () => {
    try {
      const { data, error } = await supabase.auth.refreshSession()

      if (error) throw error

      setSession(data.session)
      setUser(data.session?.user || null)

      return data.session
    } catch (error) {
      console.error("Error refreshing session:", error)
      return null
    }
  }

  const value = {
    user,
    session,
    isLoading,
    signUp,
    signIn,
    signOut,
    updateProfile,
    refreshSession,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)

  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }

  return context
}
