import { createClient } from "@supabase/supabase-js"

// Получаем переменные окружения
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

// Создаем клиент Supabase
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
})

// Проверка сессии
export const checkSession = async () => {
  const { data, error } = await supabase.auth.getSession()
  return { session: data.session, error }
}

// Создание канала для реального времени
export const createRealtimeChannel = (channelName: string, tableName: string, eventType = "*") => {
  return supabase.channel(channelName).on(
    "postgres_changes",
    {
      event: eventType,
      schema: "public",
      table: tableName,
    },
    (payload) => {
      console.log("Realtime update:", payload)
      return payload
    },
  )
}
