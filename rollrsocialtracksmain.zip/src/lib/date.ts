/**
 * Форматирует дату в относительном формате (например, "2 часа назад")
 */
export function formatRelativeDate(dateString: string): string {
  const date = new Date(dateString)
  const now = new Date()
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

  // Меньше минуты
  if (diffInSeconds < 60) {
    return "только что"
  }

  // Меньше часа
  const diffInMinutes = Math.floor(diffInSeconds / 60)
  if (diffInMinutes < 60) {
    return `${diffInMinutes} ${getRussianWordForm(diffInMinutes, "минуту", "минуты", "минут")} назад`
  }

  // Меньше суток
  const diffInHours = Math.floor(diffInMinutes / 60)
  if (diffInHours < 24) {
    return `${diffInHours} ${getRussianWordForm(diffInHours, "час", "часа", "часов")} назад`
  }

  // Меньше недели
  const diffInDays = Math.floor(diffInHours / 24)
  if (diffInDays < 7) {
    return `${diffInDays} ${getRussianWordForm(diffInDays, "день", "дня", "дней")} назад`
  }

  // Используем стандартное форматирование даты
  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date)
}

/**
 * Возвращает правильную форму слова в зависимости от числа
 * @param number число
 * @param one форма слова для 1
 * @param few форма слова для 2-4
 * @param many форма слова для 5-20
 */
export function getRussianWordForm(number: number, one: string, few: string, many: string): string {
  const mod10 = number % 10
  const mod100 = number % 100

  if (mod100 >= 11 && mod100 <= 19) {
    return many
  }

  if (mod10 === 1) {
    return one
  }

  if (mod10 >= 2 && mod10 <= 4) {
    return few
  }

  return many
}

/**
 * Форматирует дату в стандартном формате
 */
export function formatDate(dateString: string) {
  const date = new Date(dateString)
  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date)
}

export const formatMessageDate = (dateString: string): string => {
  const date = new Date(dateString)
  const now = new Date()

  // Если сообщение отправлено сегодня, показываем только время
  if (date.toDateString() === now.toDateString()) {
    return new Intl.DateTimeFormat("ru-RU", {
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  // Иначе показываем дату
  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "short",
  }).format(date)
}
