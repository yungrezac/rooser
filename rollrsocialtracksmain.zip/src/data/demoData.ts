import type { Activity, Comment, LocationPoint, Post, User } from "@/types"

// Пустые массивы и объекты вместо демо данных
export const currentUser: User | null = null

export const demoUsers: User[] = []

export const demoActivities: Activity[] = []

export const demoPosts: Post[] = []

export const demoComments: Comment[] = []

export const demoLocationPoints: LocationPoint[] = []

// Данные для чатов
export const demoChats = []

// Данные для сообщений в чате
export const demoMessages = []
