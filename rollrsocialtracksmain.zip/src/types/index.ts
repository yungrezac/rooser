export interface User {
  id: string
  name: string
  username: string
  avatar: string | null
  followers: number
  following: number
}

export interface Post {
  id: string
  content: string
  timestamp: string
  likes: number
  comments: number
  user: User
  images: string[]
  liked: boolean
}

export interface Comment {
  id: string
  postId: string
  content: string
  timestamp: string
  likes: number
  user: User
  liked: boolean
}

export interface Message {
  id: string
  content: string
  timestamp: string
  senderId: string
  receiverId: string
  read: boolean
}

export interface Chat {
  id: string
  user: User
  lastMessage: string
  timestamp: string
  unreadCount: number
}

export interface Route {
  id: string
  name: string
  description: string
  distance: number
  duration: number
  difficulty: "easy" | "medium" | "hard"
  coordinates: [number, number][]
  createdBy: User
  likes: number
  saved: boolean
}

export interface Activity {
  id: string
  type: "skating" | "rollerblading" | "skateboarding"
  distance: number
  duration: number
  calories: number
  timestamp: string
  route?: Route
  user: User
}

export interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  unlockedAt: string | null
}

export interface Notification {
  id: string
  type: "like" | "comment" | "follow" | "achievement" | "message"
  content: string
  timestamp: string
  read: boolean
  user?: User
  postId?: string
  commentId?: string
  achievementId?: string
}
