import type { NavigatorScreenParams } from "@react-navigation/native"

export type MainTabParamList = {
  Feed: undefined
  Map: { locationId?: string }
  Create: undefined
  Messages: undefined
  Profile: undefined
}

export type RootStackParamList = {
  Main: NavigatorScreenParams<MainTabParamList>
  Auth: undefined
  PostDetail: { postId: string }
  ChatDetail: { chatId: string }
  UserProfile: { userId: string }
  EditProfile: undefined
  ActivityDetail: { activityId: string }
  Settings: undefined
  NotFound: undefined
}

declare global {
  namespace ReactNavigation {
    interface RootParamList extends RootStackParamList {}
  }
}
