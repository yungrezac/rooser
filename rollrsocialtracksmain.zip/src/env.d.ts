/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly URL: string
  readonly API_Key_Anon: string
  readonly API_K: string
  readonly service_role: string
  readonly JWT_Secret: string
  readonly JWT_S: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
