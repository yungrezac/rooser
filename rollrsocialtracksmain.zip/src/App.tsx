import { Toaster } from "@/components/ui/toaster"
import { Toaster as Sonner } from "@/components/ui/sonner"
import { TooltipProvider } from "@/components/ui/tooltip"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { BrowserRouter, Routes, Route } from "react-router-dom"
import { AuthProvider } from "@/contexts/AuthContext"
import { UserDataProvider } from "@/contexts/UserDataContext"
import AppLayout from "./components/layout/AppLayout"
import Feed from "./pages/Feed"
import Map from "./pages/Map"
import Messages from "./pages/Messages"
import ChatDetail from "./pages/ChatDetail"
import CreatePost from "./pages/CreatePost"
import Profile from "./pages/Profile"
import EditProfile from "./pages/EditProfile"
import NotFound from "./pages/NotFound"
import ActivityDetail from "./pages/ActivityDetail"
import UserProfile from "./pages/UserProfile"
import PostDetail from "./pages/PostDetail"
import Auth from "./pages/Auth"

// Settings Pages
import Settings from "./pages/settings/Settings"
import NotificationsSettings from "./pages/settings/NotificationsSettings"
import PrivacySettings from "./pages/settings/PrivacySettings"
import AppearanceSettings from "./pages/settings/AppearanceSettings"
import AccountSettings from "./pages/settings/AccountSettings"
import SettingsLayout from "./components/layout/SettingsLayout"
import ProtectedRoute from "./components/auth/ProtectedRoute"

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      refetchOnWindowFocus: false,
    },
  },
})

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <UserDataProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/auth" element={<Auth />} />

              <Route
                element={
                  <ProtectedRoute>
                    <AppLayout />
                  </ProtectedRoute>
                }
              >
                <Route path="/" element={<Feed />} />
                <Route path="/map" element={<Map />} />
                <Route path="/create" element={<CreatePost />} />
                <Route path="/messages" element={<Messages />} />
                <Route path="/messages/:chatId" element={<ChatDetail />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/profile/edit" element={<EditProfile />} />
                <Route path="/profile/:username" element={<UserProfile />} />
                <Route path="/activity/:activityId?" element={<ActivityDetail />} />
                <Route path="/post/:postId" element={<PostDetail />} />

                {/* Settings Routes */}
                <Route path="/settings" element={<Settings />} />
                <Route
                  path="/settings/notifications"
                  element={
                    <SettingsLayout title="Уведомления">
                      <NotificationsSettings />
                    </SettingsLayout>
                  }
                />
                <Route
                  path="/settings/privacy"
                  element={
                    <SettingsLayout title="Приватность">
                      <PrivacySettings />
                    </SettingsLayout>
                  }
                />
                <Route
                  path="/settings/appearance"
                  element={
                    <SettingsLayout title="Внешний вид">
                      <AppearanceSettings />
                    </SettingsLayout>
                  }
                />
                <Route
                  path="/settings/account"
                  element={
                    <SettingsLayout title="Аккаунт">
                      <AccountSettings />
                    </SettingsLayout>
                  }
                />
              </Route>
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </UserDataProvider>
    </AuthProvider>
  </QueryClientProvider>
)

export default App
