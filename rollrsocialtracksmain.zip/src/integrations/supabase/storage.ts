import { supabase } from "./client"
import { v4 as uuidv4 } from "uuid"

/**
 * Загружает файл в указанное хранилище Supabase
 * @param file Файл для загрузки
 * @param bucket Имя корзины ('profiles', 'posts', и т.д.)
 * @param path Опциональный путь внутри корзины
 * @returns URL загруженного файла или null в случае ошибки
 */
export async function uploadFile(file: File, bucket: string, path?: string): Promise<string | null> {
  try {
    // Проверяем аутентификацию пользователя
    const {
      data: { session },
    } = await supabase.auth.getSession()
    if (!session) throw new Error("Требуется аутентификация для загрузки файлов")

    const userId = session.user.id

    // Создаем уникальное имя файла
    const fileExt = file.name.split(".").pop()
    const fileName = `${uuidv4()}-${Date.now()}.${fileExt}`

    // Путь для сохранения файла (в папке пользователя)
    const userPath = path ? `${userId}/${path}` : userId
    const filePath = `${userPath}/${fileName}`

    // Загружаем файл
    const { error: uploadError } = await supabase.storage.from(bucket).upload(filePath, file)

    if (uploadError) throw uploadError

    // Получаем публичный URL файла
    const { data } = await supabase.storage.from(bucket).getPublicUrl(filePath)

    return data.publicUrl
  } catch (error) {
    console.error("Ошибка загрузки файла:", error)
    return null
  }
}

/**
 * Загружает аватар пользователя
 * @param file Файл аватара для загрузки
 * @returns URL загруженного аватара или null в случае ошибки
 */
export async function uploadAvatar(file: File): Promise<string | null> {
  // Проверяем аутентификацию пользователя
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) return null

  const avatarUrl = await uploadFile(file, "profiles", "avatar")

  if (avatarUrl) {
    // Обновляем профиль пользователя с новым URL аватара
    const { error } = await supabase.from("profiles").update({ avatar_url: avatarUrl }).eq("id", session.user.id)

    if (error) {
      console.error("Ошибка обновления аватара в профиле:", error)
      await deleteFile(avatarUrl, "profiles") // Удаляем загруженный файл, если не удалось обновить профиль
      return null
    }
  }

  return avatarUrl
}

/**
 * Загружает изображение для поста
 * @param file Файл изображения для загрузки
 * @param postId ID поста (опционально, если изображение загружается для нового поста)
 * @returns URL загруженного изображения или null в случае ошибки
 */
export async function uploadPostImage(file: File, postId?: string): Promise<string | null> {
  // Для постов просто используем общую папку по ID пользователя
  const imageUrl = await uploadFile(file, "posts")

  // Если есть postId, то можно добавить запись в таблицу post_images
  if (imageUrl && postId) {
    const { error } = await supabase.from("post_images").insert({ post_id: postId, image_url: imageUrl })

    if (error) {
      console.error("Ошибка сохранения изображения поста:", error)
      await deleteFile(imageUrl, "posts")
      return null
    }
  }

  return imageUrl
}

/**
 * Удаляет файл из хранилища Supabase
 * @param url URL файла для удаления
 * @param bucket Имя корзины ('profiles', 'posts', и т.д.)
 * @returns true в случае успеха, false в случае ошибки
 */
export async function deleteFile(url: string, bucket: string): Promise<boolean> {
  try {
    // Проверяем аутентификацию пользователя
    const {
      data: { session },
    } = await supabase.auth.getSession()
    if (!session) throw new Error("Требуется аутентификация для удаления файлов")

    // Извлекаем путь к файлу из URL
    const urlParts = url.split(`${bucket}/`)
    if (urlParts.length < 2) {
      throw new Error("Невозможно извлечь путь к файлу из URL")
    }

    const path = urlParts[1]

    if (!path) {
      throw new Error("Невозможно извлечь путь к файлу из URL")
    }

    // Проверяем, что пользователь является владельцем файла или администратором
    // Путь должен содержать ID пользователя
    const userId = session.user.id
    if (!path.includes(userId)) {
      throw new Error("У вас нет прав на удаление этого файла")
    }

    const { error } = await supabase.storage.from(bucket).remove([path])

    if (error) throw error

    return true
  } catch (error) {
    console.error("Ошибка удаления файла:", error)
    return false
  }
}

/**
 * Получает список файлов в указанной корзине и пути
 * @param bucket Имя корзины ('profiles', 'posts', и т.д.)
 * @param path Путь внутри корзины (опционально)
 * @returns Список файлов или null в случае ошибки
 */
export async function listFiles(bucket: string, path?: string): Promise<any[] | null> {
  try {
    // Проверяем аутентификацию пользователя
    const {
      data: { session },
    } = await supabase.auth.getSession()
    if (!session) throw new Error("Требуется аутентификация для просмотра файлов")

    // Путь для списка файлов (в папке пользователя)
    const userId = session.user.id
    const userPath = path ? `${userId}/${path}` : userId

    const { data, error } = await supabase.storage.from(bucket).list(userPath)

    if (error) throw error

    return data
  } catch (error) {
    console.error("Ошибка получения списка файлов:", error)
    return null
  }
}
