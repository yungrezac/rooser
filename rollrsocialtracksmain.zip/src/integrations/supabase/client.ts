import { createClient } from "@supabase/supabase-js"

// Используем переменные окружения с резервными вариантами
const supabaseUrl = import.meta.env.URL || "https://natvqokelwujnzqfiyth.supabase.co"
const supabaseAnonKey =
  import.meta.env.API_Key_Anon ||
  import.meta.env.API_K ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5hdHZxb2tlbHd1am56cWZpeXRoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU5NDU3NjEsImV4cCI6MjA2MTUyMTc2MX0.CF3-1g0rNfJoFIZng3qKCkWu700PKJIoFUGiwC0EIjY"

// JWT Secret с резервным вариантом
export const JWT_SECRET = import.meta.env.JWT_Secret || import.meta.env.JWT_S || ""

// Сервисная роль для административного доступа
const serviceRoleKey = import.meta.env.service_role || ""

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: localStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
})

// Создаем клиент с сервисной ролью для административных операций
// Этот клиент должен использоваться только на сервере, никогда на клиенте!
export const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
})

// Helper function to check session status
export const checkSession = async () => {
  const { data, error } = await supabase.auth.getSession()
  return { session: data.session, error }
}

// Helper function to create a Supabase channel for real-time updates
export const createRealtimeChannel = (channelName, tableName, eventType = "*") => {
  return supabase.channel(channelName).on(
    "postgres_changes",
    {
      event: eventType,
      schema: "public",
      table: tableName,
    },
    (payload) => {
      console.log("Realtime update:", payload)
      return payload
    },
  )
}
