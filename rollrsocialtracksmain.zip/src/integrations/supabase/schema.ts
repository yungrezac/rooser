import { supabase } from "./client"

export async function initializeSchema() {
  try {
    // Проверяем, существуют ли уже таблицы
    const { data: tablesExist, error: checkError } = await supabase.from("profiles").select("id").limit(1)

    if (checkError && checkError.code === "42P01") {
      console.log("Схема базы данных не инициализирована. Запускаем инициализацию...")

      // Здесь можно добавить код для выполнения SQL скрипта,
      // но обычно это делается через SQL редактор Supabase
      console.log("Пожалуйста, выполните SQL скрипт из файла schema.sql в SQL редакторе Supabase")

      return false
    } else {
      console.log("Схема базы данных уже инициализирована")
      return true
    }
  } catch (error) {
    console.error("Ошибка при проверке схемы базы данных:", error)
    return false
  }
}

export async function seedDemoData() {
  try {
    // Проверяем, есть ли уже данные в базе
    const { data: existingProfiles, error: profilesError } = await supabase.from("profiles").select("count").single()

    if (profilesError) {
      console.error("Ошибка при проверке данных:", profilesError)
      return false
    }

    if (existingProfiles && existingProfiles.count > 1) {
      console.log("Демо-данные уже существуют")
      return true
    }

    console.log("Добавляем демо-данные...")

    // Здесь можно добавить код для добавления демо-данных
    // Например, создать несколько пользователей, постов, комментариев и т.д.

    return true
  } catch (error) {
    console.error("Ошибка при добавлении демо-данных:", error)
    return false
  }
}
