"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"
import { useSupabase } from "@/lib/supabase-provider"

export default function Home() {
  const router = useRouter()
  const { supabase, session } = useSupabase()

  useEffect(() => {
    if (session) {
      router.push("/feed")
    }
  }, [session, router])

  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 w-24 h-24 relative">
            <Image src="/rollr-logo.png" alt="Rollr Logo" width={96} height={96} className="rounded-full" />
          </div>
          <CardTitle className="text-3xl font-bold">Rollr</CardTitle>
          <CardDescription>Социальная сеть для скейтеров и роллеров</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-center text-muted-foreground">
            Делитесь своими маршрутами, находите новые места для катания и общайтесь с единомышленниками.
          </p>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <Button className="w-full" onClick={() => router.push("/auth")}>
            Войти
          </Button>
          <Button variant="outline" className="w-full" onClick={() => router.push("/auth?mode=signup")}>
            Зарегистрироваться
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
