"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"
import { useSupabase } from "@/lib/supabase-provider"

type User = {
  id: string
  username: string
  full_name?: string
  avatar_url?: string
  bio?: string
  is_following: boolean
}

type Spot = {
  id: string
  name: string
  description: string
  image_url?: string
  location: string
  rating: number
}

export default function ExplorePage() {
  const router = useRouter()
  const { session } = useSupabase()
  const { toast } = useToast()
  const [users, setUsers] = useState<User[]>([])
  const [spots, setSpots] = useState<Spot[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("users")

  useEffect(() => {
    if (!session) {
      router.push("/auth")
      return
    }

    fetchData()
  }, [session, router])

  const fetchData = async () => {
    setLoading(true)
    try {
      // В реальном приложении здесь будет запрос к Supabase
      // Для демонстрации используем моковые данные
      setTimeout(() => {
        const mockUsers: User[] = [
          {
            id: "2",
            username: "roller_girl",
            full_name: "Мария Роллер",
            avatar_url: "/pandora-ocean-scene.png",
            bio: "Роллер с 5-летним стажем. Люблю скорость и трюки.",
            is_following: false
          },
          {
            id: "3",
            username: "city_rider",
            full_name: "Иван Городской",
            avatar_url: "/diverse-group-futuristic-setting.png",
            bio: "Катаюсь по городу каждый день. Ищу компанию для совместных покатушек.",
            is_following: true
          },
          {
            id: "4",
            username: "skate_master",
            full_name: "Павел Мастер",
            avatar_url: "/placeholder.svg?height\
