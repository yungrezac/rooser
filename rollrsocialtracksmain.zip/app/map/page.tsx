"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { BottomNav } from "@/components/layout/bottom-nav"
import { TopHeader } from "@/components/layout/top-header"
import { MapPin, Route, Save } from "lucide-react"

export default function MapPage() {
  const router = useRouter()
  const { session } = useSupabase()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!session) {
      router.push("/auth")
      return
    }

    // Имитация загрузки карты
    setTimeout(() => {
      setLoading(false)
    }, 1000)
  }, [session, router])

  const handleSaveRoute = () => {
    toast({
      title: "Маршрут сохранен",
      description: "Ваш маршрут успешно сохранен",
    })
  }

  return (
    <div className="app-container">
      <TopHeader title="Карта" />

      <div className="content-area">
        <div className="relative h-full w-full">
          {/* Здесь будет карта, но для демонстрации используем заглушку */}
          <div className="h-[calc(100vh-130px)] w-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center">
            {loading ? (
              <p>Загрузка карты...</p>
            ) : (
              <div className="text-center p-4">
                <p className="mb-2">Карта будет отображаться здесь</p>
                <p className="text-sm text-muted-foreground">
                  В реальном приложении здесь будет интерактивная карта с маршрутами и точками интереса
                </p>
              </div>
            )}
          </div>

          {/* Панель управления картой */}
          <div className="absolute bottom-4 left-0 right-0 px-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Текущий маршрут</h3>
                    <p className="text-sm text-muted-foreground">0.0 км</p>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="icon">
                      <MapPin className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon">
                      <Route className="h-4 w-4" />
                    </Button>
                    <Button onClick={handleSaveRoute}>
                      <Save className="h-4 w-4 mr-2" />
                      Сохранить
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  )
}
