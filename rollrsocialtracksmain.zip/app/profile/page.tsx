"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { TopHeader } from "@/components/layout/top-header"
import { PostItem } from "@/components/posts/post-item"
import { Skeleton } from "@/components/ui/skeleton"
import { Settings, MapPin, Calendar, Edit } from "lucide-react"

type Profile = {
  id: string
  username: string
  full_name?: string
  avatar_url?: string
  bio?: string
  location?: string
  followers_count: number
  following_count: number
  joined_date: string
}

type Post = {
  id: string
  created_at: string
  content: string
  image_url?: string
  user_id: string
  likes_count: number
  comments_count: number
  user: {
    id: string
    username: string
    avatar_url?: string
    full_name?: string
  }
}

export default function ProfilePage() {
  const router = useRouter()
  const { supabase, session } = useSupabase()
  const { toast } = useToast()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("posts")

  useEffect(() => {
    if (!session) {
      router.push("/auth")
      return
    }

    fetchProfile()
    fetchUserPosts()
  }, [session, router])

  const fetchProfile = async () => {
    setLoading(true)
    try {
      // В реальном приложении здесь будет запрос к Supabase
      // Для демонстрации используем моковые данные
      setTimeout(() => {
        const mockProfile: Profile = {
          id: "1",
          username: "skater_pro",
          full_name: "Алексей Скейтер",
          avatar_url: "/avatar-profile.png",
          bio: "Скейтер с 10-летним стажем. Люблю городские споты и парки.",
          location: "Москва, Россия",
          followers_count: 245,
          following_count: 132,
          joined_date: "Январь 2023",
        }
        setProfile(mockProfile)
        setLoading(false)
      }, 1000)
    } catch (error) {
      console.error("Error fetching profile:", error)
      toast({
        variant: "destructive",
        title: "Ошибка загрузки",
        description: "Не удалось загрузить профиль. Попробуйте позже.",
      })
      setLoading(false)
    }
  }

  const fetchUserPosts = async () => {
    try {
      // В реальном приложении здесь будет запрос к Supabase
      // Для демонстрации используем моковые данные
      setTimeout(() => {
        const mockPosts: Post[] = [
          {
            id: "1",
            created_at: new Date().toISOString(),
            content: "Сегодня отличный день для катания! Нашел новый спот в парке.",
            image_url: "/vibrant-skate-park.png",
            user_id: "1",
            likes_count: 24,
            comments_count: 5,
            user: {
              id: "1",
              username: "skater_pro",
              avatar_url: "/diverse-group-avatars.png",
              full_name: "Алексей Скейтер",
            },
          },
          {
            id: "4",
            created_at: new Date(Date.now() - 86400000).toISOString(),
            content: "Вчерашняя тренировка была огонь! Выучил новый трюк.",
            image_url: "/skateboard-trick.png",
            user_id: "1",
            likes_count: 36,
            comments_count: 7,
            user: {
              id: "1",
              username: "skater_pro",
              avatar_url: "/diverse-group-avatars.png",
              full_name: "Алексей Скейтер",
            },
          },
        ]
        setPosts(mockPosts)
      }, 1000)
    } catch (error) {
      console.error("Error fetching user posts:", error)
      toast({
        variant: "destructive",
        title: "Ошибка загрузки",
        description: "Не удалось загрузить посты. Попробуйте позже.",
      })
    }
  }

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut()
      router.push("/")
    } catch (error) {
      console.error("Error signing out:", error)
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Не удалось выйти из аккаунта. Попробуйте позже.",
      })
    }
  }

  return (
    <div className="app-container">
      <TopHeader 
        title="Профиль" 
        rightElement={
          <Button variant="ghost" size="icon" onClick={() => router.push("/settings")}>
            <Settings className="h-5 w-5" />
          </Button>
        } 
      />
      
      <div className="content-area">
        {loading ? (
          <div className="p-4 space-y-4">
            <div className="flex justify-center">
              <Skeleton className="h-24 w-24 rounded-full" />
            </div>
            <div className="space-y-2 text-center">
              <Skeleton className="h-6 w-40 mx-auto" />
              <Skeleton className="h-4 w-60 mx-auto" />
            </div>
            <div className="flex justify-center space-x-8">
              <Skeleton className="h-12 w-20" />
              <Skeleton className="h-12 w-20" />
            </div>
          </div>
        ) : profile ? (
          <div className="p-4">
            <div className="relative mb-6">
              <div className="flex justify-center">
                <div className="relative h-24 w-24">
                  <Image 
                    src={profile.avatar_url || "/placeholder.svg?height=96&width=96&query=avatar default"} 
                    alt={profile.username} 
                    width={96} 
                    height={96} 
                    className="rounded-full object-cover"
                  />
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="absolute bottom-0 right-0 rounded-full h-8 w-8 bg-background"
                    onClick={() => router.push("/edit-profile")}
                  >
                    <Edit className="h-4 w-4" />
                    <span className="sr-only">Редактировать профиль</span>
                  </Button>
                </div>
              </div>
              
              <div className="text-center mt-4">
                <h2 className="text-xl font-bold">{profile.full_name}</h2>
                <p className="text-muted-foreground">@{profile.username}</p>
                
                {profile.bio && (
                  <p className="mt-2">{profile.bio}</p>
                )}
                
                <div className="flex items-center justify-center mt-2 text-sm text-muted-foreground">
                  {profile.location && (
                    <div className="flex items-center mr-4">
                      <MapPin className="h-3 w-3 mr-1" />
                      <span>{profile.location}</span>
                    </div>
                  )}
                  <div className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    <span>Присоединился: {profile.joined_date}</span>
                  </div>
                </div>  />
                    <span>Присоединился: {profile.joined_date}</span>
                  </div>
                </div>
                
                <div className="flex justify-center space-x-8 mt-4">
                  <div className="text-center">
                    <p className="font-bold">{profile.followers_count}</p>
                    <p className="text-sm text-muted-foreground">Подписчики</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold">{profile.following_count}</p>
                    <p className="text-sm text-muted-foreground">Подписки</p>
                  </div>
                </div>
              </div>
            </div>
            
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="posts">Посты</TabsTrigger>
                <TabsTrigger value="routes">Маршруты</TabsTrigger>
                <TabsTrigger value="saved">Сохраненные</TabsTrigger>
              </TabsList>
              <TabsContent value="posts" className="mt-2">
                {posts.length > 0 ? (
                  <div className="space-y-1">
                    {posts.map((post) => (
                      <PostItem key={post.id} post={post} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">У вас пока нет постов</p>
                    <Button 
                      variant="outline" 
                      className="mt-2"
                      onClick={() => router.push("/create")}
                    >
                      Создать первый пост
                    </Button>
                  </div>
                )}
              </TabsContent>
              <TabsContent value="routes" className="mt-2">
                <div className="text-center py-8">
                  <p className="text-muted-foreground">У вас пока нет сохраненных маршрутов</p>
                  <Button 
                    variant="outline" 
                    className="mt-2"
                    onClick={() => router.push("/map")}
                  >
                    Создать маршрут
                  </Button>
                </div>
              </TabsContent>
              <TabsContent value="saved" className="mt-2">
                <div className="text-center py-8">
                  <p className="text-muted-foreground">У вас пока нет сохраненных постов</p>
                  <Button 
                    variant="outline" 
                    className="mt-2"
                    onClick={() => router.push("/feed")}
                  >
                    Перейти в ленту
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )
  : (
          <div className="flex flex-col items-center justify-center p-8">
            <p className="text-muted-foreground mb-4">Профиль не найден</p>
            <Button onClick=
  ;() => router.push("/")
  >Вернуться на главную</Button>
          </div>
        )
}
</div>
      
      <BottomNav />
    </div>
  )
}
