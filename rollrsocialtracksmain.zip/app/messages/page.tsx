"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { formatDistanceToNow } from "date-fns"
import { ru } from "date-fns/locale"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useSupabase } from "@/lib/supabase-provider"
import { BottomNav } from "@/components/layout/bottom-nav"
import { TopHeader } from "@/components/layout/top-header"

type Chat = {
  id: string
  user: {
    id: string
    username: string
    avatar_url?: string
    full_name?: string
  }
  last_message: {
    content: string
    created_at: string
    is_read: boolean
  }
}

export default function MessagesPage() {
  const router = useRouter()
  const { session } = useSupabase()
  const [chats, setChats] = useState<Chat[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    if (!session) {
      router.push("/auth")
      return
    }

    fetchChats()
  }, [session, router])

  const fetchChats = async () => {
    setLoading(true)
    try {
      // В реальном приложении здесь будет запрос к Supabase
      // Для демонстрации используем моковые данные
      setTimeout(() => {
        const mockChats: Chat[] = [
          {
            id: "1",
            user: {
              id: "2",
              username: "roller_girl",
              avatar_url: "/pandora-ocean-scene.png",
              full_name: "Мария Роллер",
            },
            last_message: {
              content: "Привет! Как насчет покататься сегодня вечером?",
              created_at: new Date(Date.now() - 3600000).toISOString(),
              is_read: false,
            },
          },
          {
            id: "2",
            user: {
              id: "3",
              username: "city_rider",
              avatar_url: "/diverse-group-futuristic-setting.png",
              full_name: "Иван Городской",
            },
            last_message: {
              content: "Спасибо за совет по маршруту!",
              created_at: new Date(Date.now() - 86400000).toISOString(),
              is_read: true,
            },
          },
          {
            id: "3",
            user: {
              id: "4",
              username: "skate_master",
              avatar_url: "/diverse-group-futuristic-avatars.png",
              full_name: "Павел Мастер",
            },
            last_message: {
              content: "Видел твое новое видео, круто!",
              created_at: new Date(Date.now() - 172800000).toISOString(),
              is_read: true,
            },
          },
        ]
        setChats(mockChats)
        setLoading(false)
      }, 1000)
    } catch (error) {
      console.error("Error fetching chats:", error)
      setLoading(false)
    }
  }

  const filteredChats = chats.filter(
    (chat) =>
      chat.user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (chat.user.full_name && chat.user.full_name.toLowerCase().includes(searchQuery.toLowerCase())) ||
      chat.last_message.content.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleChatClick = (chatId: string) => {
    router.push(`/messages/${chatId}`)
  }

  return (
    <div className="app-container">
      <TopHeader title="Сообщения" />

      <div className="content-area">
        <div className="p-4">
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Поиск сообщений"
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center space-x-4 p-3 animate-pulse">
                  <div className="h-12 w-12 rounded-full bg-gray-200 dark:bg-gray-700" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 w-1/3 bg-gray-200 dark:bg-gray-700 rounded" />
                    <div className="h-3 w-2/3 bg-gray-200 dark:bg-gray-700 rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : filteredChats.length > 0 ? (
            <div className="space-y-1">
              {filteredChats.map((chat) => {
                const formattedDate = formatDistanceToNow(new Date(chat.last_message.created_at), {
                  addSuffix: true,
                  locale: ru,
                })

                return (
                  <div
                    key={chat.id}
                    className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
                    onClick={() => handleChatClick(chat.id)}
                  >
                    <div className="relative">
                      <Image
                        src={chat.user.avatar_url || "/placeholder.svg?height=48&width=48&query=avatar default"}
                        alt={chat.user.username}
                        width={48}
                        height={48}
                        className="rounded-full"
                      />
                      {!chat.last_message.is_read && (
                        <div className="absolute top-0 right-0 h-3 w-3 rounded-full bg-primary" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline">
                        <h3 className="font-medium truncate">{chat.user.full_name || chat.user.username}</h3>
                        <span className="text-xs text-muted-foreground">{formattedDate}</span>
                      </div>
                      <p
                        className={`text-sm truncate ${!chat.last_message.is_read ? "font-medium" : "text-muted-foreground"}`}
                      >
                        {chat.last_message.content}
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Нет сообщений</p>
            </div>
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  )
}
