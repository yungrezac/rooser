import type React from "react"
import "@/app/globals.css"
import { Inter } from "next/font/google"
import { Toaster } from "@/components/ui/toaster"
import { SupabaseProvider } from "@/lib/supabase-provider"

const inter = Inter({ subsets: ["latin"] })

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <SupabaseProvider>
          <main className="min-h-screen bg-gray-50 dark:bg-gray-900">
            {children}
            <Toaster />
          </main>
        </SupabaseProvider>
      </body>
    </html>
  )
}

export const metadata = {
      generator: 'v0.dev'
    };
