"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { useSupabase } from "@/lib/supabase-provider"
import { BottomNav } from "@/components/layout/bottom-nav"
import { TopHeader } from "@/components/layout/top-header"
import { PostItem } from "@/components/posts/post-item"
import { Skeleton } from "@/components/ui/skeleton"
import { PlusCircle } from "lucide-react"

type Post = {
  id: string
  created_at: string
  content: string
  image_url?: string
  user_id: string
  likes_count: number
  comments_count: number
  user: {
    id: string
    username: string
    avatar_url?: string
    full_name?: string
  }
}

export default function FeedPage() {
  const router = useRouter()
  const { supabase, session } = useSupabase()
  const { toast } = useToast()
  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("for-you")

  useEffect(() => {
    if (!session) {
      router.push("/auth")
      return
    }

    fetchPosts()
  }, [session, router, activeTab])

  const fetchPosts = async () => {
    setLoading(true)
    try {
      // В реальном приложении здесь будет запрос к Supabase
      // Для демонстрации используем моковые данные
      setTimeout(() => {
        const mockPosts: Post[] = [
          {
            id: "1",
            created_at: new Date().toISOString(),
            content: "Сегодня отличный день для катания! Нашел новый спот в парке.",
            image_url: "/vibrant-skate-park.png",
            user_id: "1",
            likes_count: 24,
            comments_count: 5,
            user: {
              id: "1",
              username: "skater_pro",
              avatar_url: "/diverse-group-avatars.png",
              full_name: "Алексей Скейтер",
            },
          },
          {
            id: "2",
            created_at: new Date(Date.now() - 3600000).toISOString(),
            content: "Новые трюки на роликах. Что думаете?",
            image_url: "/roller-skating-tricks.png",
            user_id: "2",
            likes_count: 42,
            comments_count: 8,
            user: {
              id: "2",
              username: "roller_girl",
              avatar_url: "/pandora-ocean-scene.png",
              full_name: "Мария Роллер",
            },
          },
          {
            id: "3",
            created_at: new Date(Date.now() - 7200000).toISOString(),
            content: "Маршрут на сегодня: центр города - набережная - парк. Кто со мной?",
            user_id: "3",
            likes_count: 15,
            comments_count: 12,
            user: {
              id: "3",
              username: "city_rider",
              avatar_url: "/diverse-group-futuristic-setting.png",
              full_name: "Иван Городской",
            },
          },
        ]
        setPosts(mockPosts)
        setLoading(false)
      }, 1000)
    } catch (error) {
      console.error("Error fetching posts:", error)
      toast({
        variant: "destructive",
        title: "Ошибка загрузки",
        description: "Не удалось загрузить посты. Попробуйте позже.",
      })
      setLoading(false)
    }
  }

  return (
    <div className="app-container">
      <TopHeader title="Лента" />

      <div className="content-area">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="for-you">Для вас</TabsTrigger>
            <TabsTrigger value="following">Подписки</TabsTrigger>
          </TabsList>
          <TabsContent value="for-you" className="mt-0">
            {loading ? (
              <div className="space-y-4 p-4">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="p-4">
                    <div className="flex items-center space-x-4 mb-4">
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-[100px]" />
                        <Skeleton className="h-3 w-[80px]" />
                      </div>
                    </div>
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-3/4 mb-4" />
                    <Skeleton className="h-[200px] w-full mb-4" />
                    <div className="flex justify-between">
                      <Skeleton className="h-8 w-20" />
                      <Skeleton className="h-8 w-20" />
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="space-y-1">
                {posts.map((post) => (
                  <PostItem key={post.id} post={post} />
                ))}
              </div>
            )}
          </TabsContent>
          <TabsContent value="following" className="mt-0">
            <div className="flex flex-col items-center justify-center p-8 text-center">
              <p className="text-muted-foreground mb-4">
                Здесь будут отображаться посты от пользователей, на которых вы подписаны.
              </p>
              <Button variant="outline" onClick={() => router.push("/explore")}>
                Найти пользователей
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <div className="fixed bottom-20 right-4 z-50">
        <Button size="icon" className="h-14 w-14 rounded-full shadow-lg" onClick={() => router.push("/create")}>
          <PlusCircle className="h-8 w-8" />
          <span className="sr-only">Создать пост</span>
        </Button>
      </div>

      <BottomNav />
    </div>
  )
}
