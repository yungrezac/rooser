-- Создаем таблицу уведомлений
CREATE TABLE IF NOT EXISTS public.notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    actor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    type TEXT NOT NULL,
    message TEXT,
    reference_id TEXT,
    icon TEXT,
    read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Включаем Row Level Security
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Создаем политики безопасности
CREATE POLICY "Users can view their own notifications" ON public.notifications
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications" ON public.notifications
    FOR UPDATE USING (auth.uid() = user_id);

-- Создаем функцию для автоматического создания уведомлений
CREATE OR REPLACE FUNCTION public.create_notification()
RETURNS TRIGGER AS $$
BEGIN
    -- Уведомление о лайке поста
    IF TG_TABLE_NAME = 'post_likes' AND TG_OP = 'INSERT' THEN
        INSERT INTO public.notifications (user_id, actor_id, type, reference_id)
        SELECT 
            p.user_id, 
            NEW.user_id, 
            'like', 
            NEW.post_id
        FROM public.posts p
        WHERE p.id = NEW.post_id AND p.user_id != NEW.user_id;
    
    -- Уведомление о комментарии
    ELSIF TG_TABLE_NAME = 'comments' AND TG_OP = 'INSERT' THEN
        INSERT INTO public.notifications (user_id, actor_id, type, reference_id)
        SELECT 
            p.user_id, 
            NEW.user_id, 
            'comment', 
            NEW.post_id
        FROM public.posts p
        WHERE p.id = NEW.post_id AND p.user_id != NEW.user_id;
    
    -- Уведомление о подписке
    ELSIF TG_TABLE_NAME = 'follows' AND TG_OP = 'INSERT' THEN
        INSERT INTO public.notifications (user_id, actor_id, type, reference_id)
        VALUES (NEW.following_id, NEW.follower_id, 'follow', NEW.follower_id);
    
    -- Уведомление о достижении
    ELSIF TG_TABLE_NAME = 'user_achievements' AND TG_OP = 'UPDATE' AND NEW.unlocked = TRUE AND OLD.unlocked = FALSE THEN
        INSERT INTO public.notifications (user_id, type, message, reference_id, icon)
        SELECT 
            NEW.user_id, 
            'achievement', 
            'Вы получили достижение: ' || a.title, 
            NEW.achievement_id,
            a.icon
        FROM public.achievements a
        WHERE a.id = NEW.achievement_id;
    END IF;
    
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Создаем триггеры для автоматического создания уведомлений
CREATE TRIGGER create_notification_on_post_like
AFTER INSERT ON public.post_likes
FOR EACH ROW EXECUTE FUNCTION public.create_notification();

CREATE TRIGGER create_notification_on_comment
AFTER INSERT ON public.comments
FOR EACH ROW EXECUTE FUNCTION public.create_notification();

CREATE TRIGGER create_notification_on_follow
AFTER INSERT ON public.follows
FOR EACH ROW EXECUTE FUNCTION public.create_notification();

CREATE TRIGGER create_notification_on_achievement
AFTER UPDATE ON public.user_achievements
FOR EACH ROW EXECUTE FUNCTION public.create_notification();
