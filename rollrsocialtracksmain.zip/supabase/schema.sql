-- Включаем расширения
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Таблица профилей пользователей
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    username TEXT UNIQUE,
    name TEXT,
    avatar_url TEXT,
    bio TEXT,
    city TEXT,
    country TEXT,
    experience TEXT,
    style TEXT,
    model TEXT,
    followers INTEGER DEFAULT 0,
    following INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Таблица постов
CREATE TABLE IF NOT EXISTS public.posts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    content TEXT,
    likes INTEGER DEFAULT 0,
    comments INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Таблица изображений постов
CREATE TABLE IF NOT EXISTS public.post_images (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
    image_url TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Таблица лайков постов
CREATE TABLE IF NOT EXISTS public.post_likes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
    UNIQUE(post_id, user_id)
);

-- Таблица комментариев
CREATE TABLE IF NOT EXISTS public.comments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    likes INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Таблица лайков комментариев
CREATE TABLE IF NOT EXISTS public.comment_likes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    comment_id UUID NOT NULL REFERENCES public.comments(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
    UNIQUE(comment_id, user_id)
);

-- Таблица подписок
CREATE TABLE IF NOT EXISTS public.follows (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    follower_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    following_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
    UNIQUE(follower_id, following_id)
);

-- Таблица активностей
CREATE TABLE IF NOT EXISTS public.activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    distance NUMERIC NOT NULL,
    duration INTEGER NOT NULL,
    avg_speed NUMERIC NOT NULL,
    elevation NUMERIC,
    post_id UUID REFERENCES public.posts(id) ON DELETE SET NULL,
    timestamp TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Таблица маршрутов
CREATE TABLE IF NOT EXISTS public.routes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    points JSONB NOT NULL,
    distance NUMERIC NOT NULL,
    is_public BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Таблица точек на карте
CREATE TABLE IF NOT EXISTS public.location_points (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    type TEXT NOT NULL,
    location JSONB NOT NULL,
    rating NUMERIC,
    difficulty INTEGER,
    created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    amenities TEXT[],
    open_hours TEXT,
    surface TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Таблица изображений локаций
CREATE TABLE IF NOT EXISTS public.location_images (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    location_id UUID NOT NULL REFERENCES public.location_points(id) ON DELETE CASCADE,
    image_url TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Таблица отзывов о локациях
CREATE TABLE IF NOT EXISTS public.location_reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    location_id UUID NOT NULL REFERENCES public.location_points(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    rating INTEGER NOT NULL,
    comment TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Таблица достижений
CREATE TABLE IF NOT EXISTS public.achievements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    icon TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Таблица достижений пользователей
CREATE TABLE IF NOT EXISTS public.user_achievements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    achievement_id UUID NOT NULL REFERENCES public.achievements(id) ON DELETE CASCADE,
    progress INTEGER DEFAULT 0,
    max_progress INTEGER NOT NULL,
    unlocked BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
    UNIQUE(user_id, achievement_id)
);

-- Таблица чатов
CREATE TABLE IF NOT EXISTS public.chats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Таблица участников чатов
CREATE TABLE IF NOT EXISTS public.chat_participants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chat_id UUID NOT NULL REFERENCES public.chats(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
    UNIQUE(chat_id, user_id)
);

-- Таблица сообщений
CREATE TABLE IF NOT EXISTS public.messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chat_id UUID NOT NULL REFERENCES public.chats(id) ON DELETE CASCADE,
    sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Функция для проверки, лайкнул ли пользователь пост
CREATE OR REPLACE FUNCTION public.check_post_liked(user_id UUID, post_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.post_likes
        WHERE post_likes.user_id = $1 AND post_likes.post_id = $2
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Функция для проверки, лайкнул ли пользователь комментарий
CREATE OR REPLACE FUNCTION public.check_comment_liked(user_id UUID, comment_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.comment_likes
        WHERE comment_likes.user_id = $1 AND comment_likes.comment_id = $2
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Функция для проверки, подписан ли пользователь на другого пользователя
CREATE OR REPLACE FUNCTION public.check_is_following(follower UUID, following UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.follows
        WHERE follows.follower_id = $1 AND follows.following_id = $2
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Функция для получения количества подписчиков
CREATE OR REPLACE FUNCTION public.get_followers_count(user_id UUID)
RETURNS INTEGER AS $$
BEGIN
    RETURN (
        SELECT COUNT(*) FROM public.follows
        WHERE follows.following_id = $1
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Функция для получения количества подписок
CREATE OR REPLACE FUNCTION public.get_following_count(user_id UUID)
RETURNS INTEGER AS $$
BEGIN
    RETURN (
        SELECT COUNT(*) FROM public.follows
        WHERE follows.follower_id = $1
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Триггер для обновления счетчика лайков поста
CREATE OR REPLACE FUNCTION public.update_post_likes_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE public.posts SET likes = likes + 1 WHERE id = NEW.post_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE public.posts SET likes = likes - 1 WHERE id = OLD.post_id;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER post_likes_count_trigger
AFTER INSERT OR DELETE ON public.post_likes
FOR EACH ROW EXECUTE FUNCTION public.update_post_likes_count();

-- Триггер для обновления счетчика комментариев поста
CREATE OR REPLACE FUNCTION public.update_post_comments_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE public.posts SET comments = comments + 1 WHERE id = NEW.post_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE public.posts SET comments = comments - 1 WHERE id = OLD.post_id;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER post_comments_count_trigger
AFTER INSERT OR DELETE ON public.comments
FOR EACH ROW EXECUTE FUNCTION public.update_post_comments_count();

-- Триггер для обновления счетчика лайков комментария
CREATE OR REPLACE FUNCTION public.update_comment_likes_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE public.comments SET likes = likes + 1 WHERE id = NEW.comment_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE public.comments SET likes = likes - 1 WHERE id = OLD.comment_id;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER comment_likes_count_trigger
AFTER INSERT OR DELETE ON public.comment_likes
FOR EACH ROW EXECUTE FUNCTION public.update_comment_likes_count();

-- Триггер для обновления счетчика подписчиков и подписок
CREATE OR REPLACE FUNCTION public.update_follow_counts()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE public.profiles SET followers = followers + 1 WHERE id = NEW.following_id;
        UPDATE public.profiles SET following = following + 1 WHERE id = NEW.follower_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE public.profiles SET followers = followers - 1 WHERE id = OLD.following_id;
        UPDATE public.profiles SET following = following - 1 WHERE id = OLD.follower_id;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER follow_counts_trigger
AFTER INSERT OR DELETE ON public.follows
FOR EACH ROW EXECUTE FUNCTION public.update_follow_counts();

-- Создаем политики безопасности (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.post_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comment_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.location_points ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.location_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.location_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- Политики для профилей
CREATE POLICY "Profiles are viewable by everyone" ON public.profiles
    FOR SELECT USING (true);

CREATE POLICY "Users can update their own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = id);

-- Политики для постов
CREATE POLICY "Posts are viewable by everyone" ON public.posts
    FOR SELECT USING (true);

CREATE POLICY "Users can insert their own posts" ON public.posts
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own posts" ON public.posts
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own posts" ON public.posts
    FOR DELETE USING (auth.uid() = user_id);

-- Политики для изображений постов
CREATE POLICY "Post images are viewable by everyone" ON public.post_images
    FOR SELECT USING (true);

CREATE POLICY "Users can insert images to their own posts" ON public.post_images
    FOR INSERT WITH CHECK (
        auth.uid() IN (
            SELECT user_id FROM public.posts WHERE id = post_id
        )
    );

CREATE POLICY "Users can delete images from their own posts" ON public.post_images
    FOR DELETE USING (
        auth.uid() IN (
            SELECT user_id FROM public.posts WHERE id = post_id
        )
    );

-- Политики для лайков постов
CREATE POLICY "Post likes are viewable by everyone" ON public.post_likes
    FOR SELECT USING (true);

CREATE POLICY "Users can like posts" ON public.post_likes
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unlike posts" ON public.post_likes
    FOR DELETE USING (auth.uid() = user_id);

-- Политики для комментариев
CREATE POLICY "Comments are viewable by everyone" ON public.comments
    FOR SELECT USING (true);

CREATE POLICY "Users can insert their own comments" ON public.comments
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own comments" ON public.comments
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own comments" ON public.comments
    FOR DELETE USING (auth.uid() = user_id);

-- Политики для лайков комментариев
CREATE POLICY "Comment likes are viewable by everyone" ON public.comment_likes
    FOR SELECT USING (true);

CREATE POLICY "Users can like comments" ON public.comment_likes
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unlike comments" ON public.comment_likes
    FOR DELETE USING (auth.uid() = user_id);

-- Политики для подписок
CREATE POLICY "Follows are viewable by everyone" ON public.follows
    FOR SELECT USING (true);

CREATE POLICY "Users can follow others" ON public.follows
    FOR INSERT WITH CHECK (auth.uid() = follower_id);

CREATE POLICY "Users can unfollow others" ON public.follows
    FOR DELETE USING (auth.uid() = follower_id);

-- Политики для активностей
CREATE POLICY "Activities are viewable by everyone" ON public.activities
    FOR SELECT USING (true);

CREATE POLICY "Users can insert their own activities" ON public.activities
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own activities" ON public.activities
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own activities" ON public.activities
    FOR DELETE USING (auth.uid() = user_id);

-- Политики для маршрутов
CREATE POLICY "Public routes are viewable by everyone" ON public.routes
    FOR SELECT USING (is_public OR auth.uid() = user_id);

CREATE POLICY "Users can insert their own routes" ON public.routes
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own routes" ON public.routes
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own routes" ON public.routes
    FOR DELETE USING (auth.uid() = user_id);

-- Политики для точек на карте
CREATE POLICY "Location points are viewable by everyone" ON public.location_points
    FOR SELECT USING (true);

CREATE POLICY "Users can insert location points" ON public.location_points
    FOR INSERT WITH CHECK (auth.uid() = created_by OR created_by IS NULL);

CREATE POLICY "Users can update their own location points" ON public.location_points
    FOR UPDATE USING (auth.uid() = created_by OR created_by IS NULL);

CREATE POLICY "Users can delete their own location points" ON public.location_points
    FOR DELETE USING (auth.uid() = created_by OR created_by IS NULL);

-- Политики для изображений локаций
CREATE POLICY "Location images are viewable by everyone" ON public.location_images
    FOR SELECT USING (true);

CREATE POLICY "Users can insert images to their own locations" ON public.location_images
    FOR INSERT WITH CHECK (
        auth.uid() IN (
            SELECT created_by FROM public.location_points WHERE id = location_id
        ) OR EXISTS (
            SELECT 1 FROM public.location_points WHERE id = location_id AND created_by IS NULL
        )
    );

CREATE POLICY "Users can delete images from their own locations" ON public.location_images
    FOR DELETE USING (
        auth.uid() IN (
            SELECT created_by FROM public.location_points WHERE id = location_id
        ) OR EXISTS (
            SELECT 1 FROM public.location_points WHERE id = location_id AND created_by IS NULL
        )
    );

-- Политики для отзывов о локациях
CREATE POLICY "Location reviews are viewable by everyone" ON public.location_reviews
    FOR SELECT USING (true);

CREATE POLICY "Users can insert their own reviews" ON public.location_reviews
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own reviews" ON public.location_reviews
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own reviews" ON public.location_reviews
    FOR DELETE USING (auth.uid() = user_id);

-- Политики для достижений
CREATE POLICY "Achievements are viewable by everyone" ON public.achievements
    FOR SELECT USING (true);

-- Только администраторы могут изменять достижения (через сервисную роль)

-- Политики для достижений пользователей
CREATE POLICY "User achievements are viewable by everyone" ON public.user_achievements
    FOR SELECT USING (true);

CREATE POLICY "Users can see their own achievements" ON public.user_achievements
    FOR SELECT USING (auth.uid() = user_id);

-- Обновление достижений происходит через сервисную роль или триггеры

-- Политики для чатов
CREATE POLICY "Users can see chats they participate in" ON public.chats
    FOR SELECT USING (
        auth.uid() IN (
            SELECT user_id FROM public.chat_participants WHERE chat_id = id
        )
    );

CREATE POLICY "Users can create chats" ON public.chats
    FOR INSERT WITH CHECK (true);

-- Политики для участников чатов
CREATE POLICY "Users can see chat participants for their chats" ON public.chat_participants
    FOR SELECT USING (
        auth.uid() IN (
            SELECT user_id FROM public.chat_participants WHERE chat_id = chat_id
        )
    );

CREATE POLICY "Users can add themselves to chats" ON public.chat_participants
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove themselves from chats" ON public.chat_participants
    FOR DELETE USING (auth.uid() = user_id);

-- Политики для сообщений
CREATE POLICY "Users can see messages in chats they participate in" ON public.messages
    FOR SELECT USING (
        auth.uid() IN (
            SELECT user_id FROM public.chat_participants WHERE chat_id = chat_id
        )
    );

CREATE POLICY "Users can send messages to chats they participate in" ON public.messages
    FOR INSERT WITH CHECK (
        auth.uid() = sender_id AND
        auth.uid() IN (
            SELECT user_id FROM public.chat_participants WHERE chat_id = chat_id
        )
    );

CREATE POLICY "Users can update their own messages" ON public.messages
    FOR UPDATE USING (auth.uid() = sender_id);

CREATE POLICY "Users can delete their own messages" ON public.messages
    FOR DELETE USING (auth.uid() = sender_id);

-- Создаем хранилища для файлов
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('post_images', 'post_images', true) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('location_images', 'location_images', true) ON CONFLICT DO NOTHING;

-- Политики для хранилища аватаров
CREATE POLICY "Avatar images are publicly accessible" ON storage.objects
    FOR SELECT USING (bucket_id = 'avatars');

CREATE POLICY "Users can upload their own avatar" ON storage.objects
    FOR INSERT WITH CHECK (
        bucket_id = 'avatars' AND
        (storage.foldername(name))[1] = auth.uid()::text
    );

CREATE POLICY "Users can update their own avatar" ON storage.objects
    FOR UPDATE USING (
        bucket_id = 'avatars' AND
        (storage.foldername(name))[1] = auth.uid()::text
    );

CREATE POLICY "Users can delete their own avatar" ON storage.objects
    FOR DELETE USING (
        bucket_id = 'avatars' AND
        (storage.foldername(name))[1] = auth.uid()::text
    );

-- Политики для хранилища изображений постов
CREATE POLICY "Post images are publicly accessible" ON storage.objects
    FOR SELECT USING (bucket_id = 'post_images');

CREATE POLICY "Users can upload images to their own posts" ON storage.objects
    FOR INSERT WITH CHECK (
        bucket_id = 'post_images' AND
        (storage.foldername(name))[1] = auth.uid()::text
    );

CREATE POLICY "Users can delete images from their own posts" ON storage.objects
    FOR DELETE USING (
        bucket_id = 'post_images' AND
        (storage.foldername(name))[1] = auth.uid()::text
    );

-- Политики для хранилища изображений локаций
CREATE POLICY "Location images are publicly accessible" ON storage.objects
    FOR SELECT USING (bucket_id = 'location_images');

CREATE POLICY "Users can upload location images" ON storage.objects
    FOR INSERT WITH CHECK (bucket_id = 'location_images');

CREATE POLICY "Users can delete their own location images" ON storage.objects
    FOR DELETE USING (
        bucket_id = 'location_images' AND
        auth.uid()::text IN (
            SELECT created_by::text FROM public.location_points
            WHERE id::text = (storage.foldername(name))[1]
        )
    );

-- Создаем начальные достижения
INSERT INTO public.achievements (title, description, icon) VALUES
('Первые шаги', 'Пройдите свой первый километр', 'award'),
('Марафонец', 'Пройдите 42 километра в общей сложности', 'award'),
('Социальная бабочка', 'Подпишитесь на 10 пользователей', 'users'),
('Популярность', 'Наберите 10 подписчиков', 'trending-up'),
('Фотограф', 'Опубликуйте 5 постов с фотографиями', 'camera'),
('Комментатор', 'Оставьте 10 комментариев', 'message-square'),
('Исследователь', 'Посетите 5 разных мест', 'map-pin'),
('Скоростной', 'Достигните средней скорости 20 км/ч', 'zap'),
('Постоянство', 'Катайтесь 7 дней подряд', 'calendar'),
('Ночной гонщик', 'Совершите поездку после 22:00', 'moon')
ON CONFLICT DO NOTHING;

-- Создаем функцию для автоматического создания профиля при регистрации
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, username, avatar_url)
    VALUES (NEW.id, NEW.email, 'https://api.dicebear.com/7.x/avataaars/svg?seed=' || NEW.email);
    
    -- Создаем начальные достижения для пользователя
    INSERT INTO public.user_achievements (user_id, achievement_id, max_progress)
    SELECT NEW.id, id, 
        CASE 
            WHEN title = 'Первые шаги' THEN 1
            WHEN title = 'Марафонец' THEN 42
            WHEN title = 'Социальная бабочка' THEN 10
            WHEN title = 'Популярность' THEN 10
            WHEN title = 'Фотограф' THEN 5
            WHEN title = 'Комментатор' THEN 10
            WHEN title = 'Исследователь' THEN 5
            WHEN title = 'Скоростной' THEN 20
            WHEN title = 'Постоянство' THEN 7
            WHEN title = 'Ночной гонщик' THEN 1
            ELSE 1
        END
    FROM public.achievements;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Создаем триггер для автоматического создания профиля
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Создаем функцию для обновления достижений
CREATE OR REPLACE FUNCTION public.update_achievements()
RETURNS TRIGGER AS $$
BEGIN
    -- Обновляем достижение "Первые шаги"
    IF TG_TABLE_NAME = 'activities' AND TG_OP = 'INSERT' THEN
        UPDATE public.user_achievements
        SET progress = 1, unlocked = TRUE
        WHERE user_id = NEW.user_id
        AND achievement_id IN (SELECT id FROM public.achievements WHERE title = 'Первые шаги')
        AND NOT unlocked;
        
        -- Обновляем достижение "Марафонец"
        UPDATE public.user_achievements ua
        SET progress = (
            SELECT COALESCE(SUM(distance), 0)
            FROM public.activities
            WHERE user_id = NEW.user_id
        ),
        unlocked = (
            SELECT COALESCE(SUM(distance), 0) >= ua.max_progress
            FROM public.activities
            WHERE user_id = NEW.user_id
        )
        WHERE user_id = NEW.user_id
        AND achievement_id IN (SELECT id FROM public.achievements WHERE title = 'Марафонец');
        
        -- Обновляем достижение "Скоростной"
        IF NEW.avg_speed >= 20 THEN
            UPDATE public.user_achievements
            SET progress = 20, unlocked = TRUE
            WHERE user_id = NEW.user_id
            AND achievement_id IN (SELECT id FROM public.achievements WHERE title = 'Скоростной')
            AND NOT unlocked;
        END IF;
        
        -- Обновляем достижение "Ночной гонщик"
        IF EXTRACT(HOUR FROM NEW.created_at) >= 22 OR EXTRACT(HOUR FROM NEW.created_at) < 5 THEN
            UPDATE public.user_achievements
            SET progress = 1, unlocked = TRUE
            WHERE user_id = NEW.user_id
            AND achievement_id IN (SELECT id FROM public.achievements WHERE title = 'Ночной гонщик')
            AND NOT unlocked;
        END IF;
    END IF;
    
    -- Обновляем достижение "Социальная бабочка"
    IF TG_TABLE_NAME = 'follows' AND TG_OP = 'INSERT' THEN
        UPDATE public.user_achievements ua
        SET progress = (
            SELECT COUNT(*)
            FROM public.follows
            WHERE follower_id = NEW.follower_id
        ),
        unlocked = (
            SELECT COUNT(*) >= ua.max_progress
            FROM public.follows
            WHERE follower_id = NEW.follower_id
        )
        WHERE user_id = NEW.follower_id
        AND achievement_id IN (SELECT id FROM public.achievements WHERE title = 'Социальная бабочка');
    END IF;
    
    -- Обновляем достижение "Популярность"
    IF TG_TABLE_NAME = 'follows' AND TG_OP = 'INSERT' THEN
        UPDATE public.user_achievements ua
        SET progress = (
            SELECT COUNT(*)
            FROM public.follows
            WHERE following_id = NEW.following_id
        ),
        unlocked = (
            SELECT COUNT(*) >= ua.max_progress
            FROM public.follows
            WHERE following_id = NEW.following_id
        )
        WHERE user_id = NEW.following_id
        AND achievement_id IN (SELECT id FROM public.achievements WHERE title = 'Популярность');
    END IF;
    
    -- Обновляем достижение "Фотограф"
    IF TG_TABLE_NAME = 'post_images' AND TG_OP = 'INSERT' THEN
        UPDATE public.user_achievements ua
        SET progress = (
            SELECT COUNT(DISTINCT pi.post_id)
            FROM public.post_images pi
            JOIN public.posts p ON pi.post_id = p.id
            WHERE p.user_id = (
                SELECT user_id FROM public.posts WHERE id = NEW.post_id
            )
        ),
        unlocked = (
            SELECT COUNT(DISTINCT pi.post_id) >= ua.max_progress
            FROM public.post_images pi
            JOIN public.posts p ON pi.post_id = p.id
            WHERE p.user_id = (
                SELECT user_id FROM public.posts WHERE id = NEW.post_id
            )
        )
        WHERE user_id = (
            SELECT user_id FROM public.posts WHERE id = NEW.post_id
        )
        AND achievement_id IN (SELECT id FROM public.achievements WHERE title = 'Фотограф');
    END IF;
    
    -- Обновляем достижение "Комментатор"
    IF TG_TABLE_NAME = 'comments' AND TG_OP = 'INSERT' THEN
        UPDATE public.user_achievements ua
        SET progress = (
            SELECT COUNT(*)
            FROM public.comments
            WHERE user_id = NEW.user_id
        ),
        unlocked = (
            SELECT COUNT(*) >= ua.max_progress
            FROM public.comments
            WHERE user_id = NEW.user_id
        )
        WHERE user_id = NEW.user_id
        AND achievement_id IN (SELECT id FROM public.achievements WHERE title = 'Комментатор');
    END IF;
    
    -- Обновляем достижение "Исследователь"
    IF TG_TABLE_NAME = 'location_reviews' AND TG_OP = 'INSERT' THEN
        UPDATE public.user_achievements ua
        SET progress = (
            SELECT COUNT(DISTINCT location_id)
            FROM public.location_reviews
            WHERE user_id = NEW.user_id
        ),
        unlocked = (
            SELECT COUNT(DISTINCT location_id) >= ua.max_progress
            FROM public.location_reviews
            WHERE user_id = NEW.user_id
        )
        WHERE user_id = NEW.user_id
        AND achievement_id IN (SELECT id FROM public.achievements WHERE title = 'Исследователь');
    END IF;
    
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Создаем триггеры для обновления достижений
CREATE TRIGGER update_achievements_on_activity
AFTER INSERT ON public.activities
FOR EACH ROW EXECUTE FUNCTION public.update_achievements();

CREATE TRIGGER update_achievements_on_follow
AFTER INSERT ON public.follows
FOR EACH ROW EXECUTE FUNCTION public.update_achievements();

CREATE TRIGGER update_achievements_on_post_image
AFTER INSERT ON public.post_images
FOR EACH ROW EXECUTE FUNCTION public.update_achievements();

CREATE TRIGGER update_achievements_on_comment
AFTER INSERT ON public.comments
FOR EACH ROW EXECUTE FUNCTION public.update_achievements();

CREATE TRIGGER update_achievements_on_location_review
AFTER INSERT ON public.location_reviews
FOR EACH ROW EXECUTE FUNCTION public.update_achievements();

-- Создаем функцию для проверки достижения "Постоянство"
CREATE OR REPLACE FUNCTION public.check_consistency_achievement()
RETURNS VOID AS $$
DECLARE
    user_record RECORD;
    consecutive_days INTEGER;
BEGIN
    FOR user_record IN SELECT DISTINCT user_id FROM public.activities
    LOOP
        -- Проверяем количество последовательных дней с активностями
        WITH days AS (
            SELECT DISTINCT DATE(created_at) as activity_date
            FROM public.activities
            WHERE user_id = user_record.user_id
            ORDER BY activity_date
        ),
        gaps AS (
            SELECT 
                activity_date,
                LAG(activity_date, 1) OVER (ORDER BY activity_date) as prev_date,
                activity_date - LAG(activity_date, 1) OVER (ORDER BY activity_date) as day_diff
            FROM days
        ),
        sequences AS (
            SELECT 
                activity_date,
                SUM(CASE WHEN day_diff = 1 THEN 0 ELSE 1 END) OVER (ORDER BY activity_date) as seq_group
            FROM gaps
        ),
        seq_length AS (
            SELECT 
                seq_group,
                COUNT(*) as seq_length
            FROM sequences
            GROUP BY seq_group
        )
        SELECT MAX(seq_length) INTO consecutive_days FROM seq_length;
        
        -- Обновляем достижение "Постоянство"
        UPDATE public.user_achievements
        SET progress = GREATEST(COALESCE(progress, 0), consecutive_days),
            unlocked = consecutive_days >= max_progress
        WHERE user_id = user_record.user_id
        AND achievement_id IN (SELECT id FROM public.achievements WHERE title = 'Постоянство');
    END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Создаем функцию для ежедневной проверки достижения "Постоянство"
CREATE OR REPLACE FUNCTION public.daily_achievement_check()
RETURNS VOID AS $$
BEGIN
    PERFORM public.check_consistency_achievement();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
